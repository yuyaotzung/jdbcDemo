/*
 * ===========================================================================
 * IBM Confidential
 * AIS Source Materials
 *
 *
 * (C) Copyright IBM Corp. 2011.
 *
 * ===========================================================================
 */
package com.cosmos.file.ext;

/**
 * <p>
 * ACH提出提回電子檔檔案規格_NEW
 * </p>
 *
 * @author KK
 * @version 1.0, 2020/1/30
 * @see
 * @since
 */
public enum Ach02FooterFileSectionNew implements IAchFileDefinition {

	/** 欄位代號(類型, 是否必填 ,長度, 資料庫欄位, 欄位名稱(說明)) */
	EOF(1,0, 3, "", "尾錄別"),
	TCOUNT(1,0, 8, "", "總筆數"),
	FILLER(1,0, 209, "Filler", "備用");

	/** 資料類型 */
	private int type;
	
	/** 是否必填 */
	private int required;

	/** 檔案格式長度 */
	private int length;

	/** 資料庫存放欄位 */
	private String columnName;

	/** 欄位名稱 說明 */
	private String name;

	/**
	 * Constructor
	 *
	 * @param code
	 * @param memo
	 */
	Ach02FooterFileSectionNew(int type, int required, int length, String columnName, String name) {
		this.type = type;
		this.length = length;
		this.required = required;
		this.columnName = columnName;
		this.name = name;
	}

	/**
	 * 取得id
	 *
	 * @return
	 */
	@Override
	public String getId() {
		return name();
	}

	/**
	 * 取得 type
	 *
	 * @return 傳回 type
	 */
	@Override
	public int getType() {
		return type;
	}

	/**
	 * 取得 length
	 *
	 * @return 傳回 length
	 */
	@Override
	public int getLength() {
		return length;
	}

	/**
	 * 取得 name
	 *
	 * @return 傳回 name
	 */
	@Override
	public String getName() {
		return name;
	}
	
	/**
	 * 取得 length
	 * 
	 * @return 傳回 length
	 */
	public int getRequired() {
		return required;
	}
}
