/*
 * ===========================================================================
 * IBM Confidential
 * AIS Source Materials
 * 
 * 
 * (C) Copyright IBM Corp. 2018.
 *
 * ===========================================================================
 */
package com.cosmos.file.ext;

import com.cosmos.file.bo.FileField;
import com.cosmos.file.bo.FileSection;
import com.cosmos.file.def.DbperpcTxFileDefinition;
import com.cosmos.file.def.IFileDefinition;
import com.cosmos.type.FieldGroup;
import com.ibm.tw.commons.util.StringUtils;

/**
 * <p>
 * 整批匯款界面檔案規Tx格式
 * </p>
 * 
 * @author Bear
 * @version 1.0, 2018/4/10
 * @see
 * @since
 */
public class DbperpcTxFileSection {

	/** 檔案區段 */
	private FileSection fileSection;

	public DbperpcTxFileSection() {
		fileSection = new FileSection();
		fileSection.setFieldGroup(FieldGroup.TX);
	}

	public DbperpcTxFileSection(FileSection fileSection) {
		this.fileSection = fileSection;
	}

	public FileSection getFileSection() {
		return fileSection;
	}

	// 解款行代號
	public String getPayeeBankId() {
		return getValue(DbperpcTxFileDefinition.payeeBankId);
	}

	public void setPayeeBankId(String value) {
		setValue(DbperpcTxFileDefinition.payeeBankId, value);
	}

	// 轉入帳號
	public String getPayeeAccountNo() {
		return getValue(DbperpcTxFileDefinition.payeeAccountNo);
	}

	public void setPayeeAccountNo(String value) {
		setValue(DbperpcTxFileDefinition.payeeAccountNo, value);
	}

	// 交易金額
	public String getTxAmt() {
		return getValue(DbperpcTxFileDefinition.txAmt);
	}

	public void setTxAmt(String value) {
		setValue(DbperpcTxFileDefinition.txAmt, value);
	}

	/**
	 * 收款人戶名
	 * 
	 * @return
	 */
	public String getPayeeName() {
		return getValue(DbperpcTxFileDefinition.payeeName);

	}

	public void setPayeeName(String value) {
		setValue(DbperpcTxFileDefinition.payeeName, value);
	}

	/**
	 * 付款人戶名
	 * 
	 * @return
	 */
	public String getPayerName() {
		return getValue(DbperpcTxFileDefinition.payerName);

	}

	public void setPayerName(String value) {
		setValue(DbperpcTxFileDefinition.payerName, value);
	}

	/**
	 * 附 言
	 * 
	 * @return
	 */
	public String getPayeeMemo() {
		return getValue(DbperpcTxFileDefinition.payeeMemo);

	}

	public void setPayeeMemo(String value) {
		setValue(DbperpcTxFileDefinition.payeeMemo, value);
	}

	// ========================================================
	// 以下可共用

	/**
	 * 
	 * @param fileDefinition
	 * @return
	 */
	private String getValue(IFileDefinition fileDefinition) {

		FileField fileField = fileSection.getField(fileDefinition.getId());
		if (fileField == null) {
			return null;
		}
		else {
			return StringUtils.trim(fileField.getValue());
		}
	}

	/**
	 * 
	 * @param fileDefinition
	 * @param value
	 */
	private void setValue(IFileDefinition fileDefinition, String value) {

		if (fileSection == null) {
			fileSection = new FileSection();
		}

		FileField field = fileSection.getField(fileDefinition.getId());
		if (field == null) {
			field = new FileField();
			field.setFieldId(fileDefinition.getId());
			field.setValue(value);
			fileSection.addField(field);
		}
		else {
			field.setValue(value);
		}
	}

	// 以上可共用
	// ========================================================
}
