/*
 * ===========================================================================
 * IBM Confidential
 * AIS Source Materials
 *
 *
 * (C) Copyright IBM Corp. 2011.
 *
 * ===========================================================================
 */
package com.cosmos.file.ext;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;

import com.cosmos.file.FileFormatDetail;
import com.cosmos.file.FileFormatNew;
import com.cosmos.file.bo.FileDetail;
import com.cosmos.file.bo.FileDoc;
import com.cosmos.file.bo.FileSection;
import com.cosmos.persistence.b2c.entity.FileFormatDetailEntity;
import com.cosmos.persistence.b2c.entity.FileFormatFieldEntity;
import com.cosmos.tx.FiscAuthDetailDoc;
import com.cosmos.type.FieldGroup;
import com.cosmos.type.TaskType;
import com.cosmos.type.TxBatchType;
import com.ibm.tw.commons.exception.ActionException;
import com.ibm.tw.commons.util.ConvertUtils;
import com.ibm.tw.commons.util.time.DateUtils;

/**
 * <p>
 * FISC核印檔案解析
 * </p>
 * 
 * @author BearChen
 * @version 1.0, 2013/9/14
 * @see
 * @since
 */
public class Fisc02FileFormat extends FileFormatNew {

	public Fisc02FileFormat(String taskId) {
		super(0, taskId, TxBatchType.UNKNOWN.getCode());
		detailGroup = loadDetailGroup();
	}

	private final TaskType taskType = TaskType.FISC01;

	/** 明細錄資料 */
	private List<FiscAuthDetailDoc> details = new ArrayList<FiscAuthDetailDoc>();

	/** 明細錄資料 */

	/**
	 * 載入檔案定義
	 * 
	 * @return
	 */
	private Map<FieldGroup, List<FileFormatDetail>> loadDetailGroup() {
		Map<FieldGroup, List<FileFormatDetail>> detailGroup = new HashMap<FieldGroup, List<FileFormatDetail>>();

		// Header
		FieldGroup fieldGroup = FieldGroup.HEADER;
		detailGroup.put(fieldGroup, toFileFormatDetails(taskType, fieldGroup, Fisc02MasterFileSection.values()));

		// Tx
		fieldGroup = FieldGroup.TX;
		detailGroup.put(fieldGroup, toFileFormatDetails(taskType, fieldGroup, Fisc02TxFileSection.values()));

		// Footer
		fieldGroup = FieldGroup.FOOTER;
		detailGroup.put(fieldGroup, toFileFormatDetails(taskType, fieldGroup, Fisc02FooterFileSection.values()));

		return detailGroup;
	}

	/**
	 * 轉換為FileFormatDetail
	 * 
	 * @param taskType
	 * @param fieldGroup
	 * @param sections
	 * @return
	 */
	private List<FileFormatDetail> toFileFormatDetails(TaskType taskType, FieldGroup fieldGroup, IFiscAuthFileDefinition[] sections) {
		List<FileFormatDetail> fileFormatDetails = new ArrayList<FileFormatDetail>();

		int orderNo = 1;
		int startPosition = 0;
		for (IFiscAuthFileDefinition section : sections) {
			FileFormatDetail fileFormatDetail = toFileFormatDetail(taskType, fieldGroup, section.getId(), section.getName(), orderNo++, section.getType(), section.getRequired(), section.getLength(), startPosition);
			fileFormatDetails.add(fileFormatDetail);
			startPosition += section.getLength();
		}

		return fileFormatDetails;
	}

	/**
	 * 轉換為FileFormatDetail
	 * 
	 * @param taskType
	 * @param fieldGroup
	 * @param fieldId
	 * @param fieldName
	 * @param orderNo
	 * @param type
	 * @param length
	 * @param startPosition
	 * @return
	 */
	private FileFormatDetail toFileFormatDetail(TaskType taskType, FieldGroup fieldGroup, String fieldId, String fieldName, int orderNo, int type, int required, int length, int startPosition) {
		// detail
		FileFormatDetailEntity detail = new FileFormatDetailEntity();
		detail.setFieldId(fieldId);
		detail.setFieldName(fieldName);
		detail.setOrderNo(orderNo);
		detail.setLength(length);
		detail.setStartPosition(startPosition);
		detail.setEndPosition(startPosition + detail.getLength() - 1);

		// field
		FileFormatFieldEntity field = new FileFormatFieldEntity();
		field.setFieldGroup(fieldGroup.getCode());
		field.setFieldId(fieldId);
		field.setTaskType(taskType.getCode());
		field.setType(type);
		field.setDefaultLength(length);
		field.setRequired(required);

		FileFormatDetail fileFormatDetail = new FileFormatDetail(taskType, detail, field);
		return fileFormatDetail;
	}

	/**
	 * 判斷是否為資料頭一筆
	 * 
	 * @param rowNo
	 * @return
	 */
	@Override
	public FieldGroup getFormatHead(int rowNo) {

		if (rowNo == 1) {
			return FieldGroup.HEADER;
		}
		else if (rowNo == getRows()) {
			return FieldGroup.FOOTER;
		}
		else {
			return FieldGroup.TX;
		}
	}

	@Override
	public FieldGroup getFormatCycle(int rowNo) {
		return null;
	}

	@Override
	public TaskType getTaskType() {
		return taskType;
	}

	@Override
	protected void validateDetailSize(FileDoc fileDoc) throws ActionException {

	}

	@Override
	protected void validateCustom(FileDoc fileDoc) throws ActionException {

	}

	@Override
	protected void validateDetailContent(FileDetail fileDetail) throws ActionException {

	}

	@Override
	protected void putData(FileDoc fileDoc) {

		// 將檔案資料轉為整批多扣多入明細資料 ,i為行號
		logger.info("fileDoc.rows()=" + fileDoc.rows());

		for (int i = 2; i < fileDoc.rows(); i++) {
			// logger.info("fileDoc.rows()=" + fileDoc.getDetail(i).getRowNo());
			// for (int i = 2; i < fileDoc.rows(); i++) {
			FiscAuthDetailDoc detail = new FiscAuthDetailDoc();
			putDetail(detail, fileDoc.getDetail(i));
			details.add(detail);
		}

	}

	private void putDetail(FiscAuthDetailDoc txDetailDoc, FileDetail fileDetail) {

		putDocDetail(txDetailDoc, fileDetail.getFirstSection());

	}

	private void putDocDetail(FiscAuthDetailDoc detail, FileSection section) {

		// 資料來源
		String dataSrcFieldValue = section.getField(Fisc02TxFileSection.DATASRC.getId()).getStringValue();
		if (StringUtils.isNotBlank(dataSrcFieldValue)) {
			detail.setDataSrc(ConvertUtils.str2Int(dataSrcFieldValue));
		}

		// 檔案批號
		String filwBatchNoFieldValue = section.getField(Fisc02TxFileSection.FILEBATCHNO.getId()).getStringValue();
		if (StringUtils.isNotBlank(filwBatchNoFieldValue)) {
			detail.setFileBatchNo(filwBatchNoFieldValue);
		}

		// 帳務代理銀行 -總行代號
		String agentBankIdFieldValue = section.getField(Fisc02TxFileSection.AGENTBANKID.getId()).getStringValue();
		if (StringUtils.isNotBlank(agentBankIdFieldValue)) {
			detail.setAgentBankId(agentBankIdFieldValue);
		}

		// 帳務代理銀行 -分行代號
		String agentBranchIdFieldValue = section.getField(Fisc02TxFileSection.AGENTBRANCHID.getId()).getStringValue();
		if (StringUtils.isNotBlank(agentBranchIdFieldValue)) {
			detail.setAgentBranchId(agentBranchIdFieldValue);
		}

		// 委託單位代號
		String punitFieldValue = section.getField(Fisc02TxFileSection.PUNIT.getId()).getStringValue();
		if (StringUtils.isNotBlank(punitFieldValue)) {
			detail.setPUnit(punitFieldValue);
		}

		// 編碼單位
		String agentUnitFieldValue = section.getField(Fisc02TxFileSection.AGENTUNIT.getId()).getStringValue();
		if (StringUtils.isNotBlank(agentUnitFieldValue)) {
			detail.setAgentUnit(agentUnitFieldValue);
		}

		// 編碼年度
		String agentYearFieldValue = section.getField(Fisc02TxFileSection.AGENTYEAR.getId()).getStringValue();
		if (StringUtils.isNotBlank(agentYearFieldValue)) {
			detail.setAgentYear(agentYearFieldValue);
		}

		// 交易序號
		String txNoFieldValue = section.getField(Fisc02TxFileSection.TXNO.getId()).getStringValue();
		if (StringUtils.isNotBlank(txNoFieldValue)) {
			detail.setTxNo(txNoFieldValue);
		}

		// 費用類別
		String paymentTypeFieldValue = section.getField(Fisc02TxFileSection.PAYMENTTYPE.getId()).getStringValue();
		if (StringUtils.isNotBlank(paymentTypeFieldValue)) {
			detail.setPaymentType(paymentTypeFieldValue);
		}

		// 核印行 -總行代號
		String authBankIdFieldValue = section.getField(Fisc02TxFileSection.AUTHBANKID.getId()).getStringValue();
		if (StringUtils.isNotBlank(authBankIdFieldValue)) {
			detail.setAuthBankId(authBankIdFieldValue);
		}

		// 核印行 -分行代號
		String authBranchIdFieldValue = section.getField(Fisc02TxFileSection.AUTHBRANCHID.getId()).getStringValue();
		if (StringUtils.isNotBlank(authBranchIdFieldValue)) {
			detail.setAuthBranchId(authBranchIdFieldValue);
		}

		// 帳號
		String accountNoFieldValue = section.getField(Fisc02TxFileSection.ACCOUNTNO.getId()).getStringValue();
		if (StringUtils.isNotBlank(accountNoFieldValue)) {
			detail.setAccountNo(accountNoFieldValue);
		}

		// 帳戶 ID (身份證統一 編號 )
		String uidFieldValue = section.getField(Fisc02TxFileSection.UID.getId()).getStringValue();
		if (StringUtils.isNotBlank(uidFieldValue)) {
			detail.setAccountNo(uidFieldValue);
		}

		// 委託單位提出日期
		String reqDateFieldValue = section.getField(Fisc02TxFileSection.REQDATE.getId()).getStringValue();
		if (StringUtils.isNotBlank(reqDateFieldValue)) {
			detail.setReqDate(DateUtils.getROCDate(uidFieldValue));
		}

		// 核印行 回應日期
		String rspDateFieldValue = section.getField(Fisc02TxFileSection.RSPDATE.getId()).getStringValue();
		if (StringUtils.isNotBlank(rspDateFieldValue)) {
			detail.setRspDate(DateUtils.getROCDate(rspDateFieldValue));
		}

		// 回覆訊息
		String statusCodeFieldValue = section.getField(Fisc02TxFileSection.STATUSCODE.getId()).getStringValue();
		if (StringUtils.isNotBlank(statusCodeFieldValue)) {
			detail.setStatusCode(statusCodeFieldValue);
		}

		// 交易類別
		String txTypeFieldValue = section.getField(Fisc02TxFileSection.TXTYPE.getId()).getStringValue();
		if (StringUtils.isNotBlank(txTypeFieldValue)) {
			detail.setTxType(ConvertUtils.str2Int(txTypeFieldValue));
		}

		// 核印費
		String authAmtFieldValue = section.getField(Fisc02TxFileSection.AUTHAMT.getId()).getStringValue();
		if (StringUtils.isNotBlank(authAmtFieldValue)) {
			detail.setAuthAmt(ConvertUtils.str2BigDecimal(authAmtFieldValue));
		}

		// Memo
		String memoFieldValue = section.getField(Fisc02TxFileSection.MEMO.getId()).getStringValue();
		if (StringUtils.isNotBlank(memoFieldValue)) {
			detail.setMemo(memoFieldValue);
		}

		// FILLER
		String reMarkFieldValue = section.getField(Fisc02TxFileSection.FILLER.getId()).getStringValue();
		if (StringUtils.isNotBlank(reMarkFieldValue)) {
			detail.setReMark(reMarkFieldValue);
		}
	}

	public List<FiscAuthDetailDoc> getDetails() {
		return details;
	}

	public void setDetails(List<FiscAuthDetailDoc> details) {
		this.details = details;
	}

}
