package com.cosmos.file.ext;

import com.cosmos.file.bo.FileSection;
import com.cosmos.file.ext.fx.FileSectionWrapperBase;
import com.cosmos.type.PayerKind;

/**
 * <p>
 * FrCommonPayee File Section
 * </p>
 * 
 * @author monica
 * @version 1.0, 2013/9/30
 * @see
 * @since
 */
public class FrCommonPayeeFileSection extends FileSectionWrapperBase {

	public FrCommonPayeeFileSection(FileSection fileSection) {

		super(fileSection);
	}

	/**
	 * 取得自行或跨行
	 * 
	 * @return
	 */
	public PayerKind getPayerKind() {

		String payeeBankName1 = getPayeeBankName1();

		String payeeSwiftCode = getPayeeSwiftCode();

		return isIntraBank(payeeBankName1, payeeSwiftCode);
	}

	/**
	 * 收款帳號
	 * 
	 * @return
	 */
	public String getPayeeAccountNo() {
		return getFieldValue("payeeAccountNo");
	}

	/**
	 * 收款人戶名-1
	 * 
	 * @return
	 */
	public String getPayeeName1() {
		return getFieldValue("payeeName1");
	}

	/**
	 * 收款人戶名-2
	 * 
	 * @return
	 */
	public String getPayeeName2() {
		return getFieldValue("payeeName2");
	}

	/**
	 * 收款人地址/電話-1
	 * 
	 * @return
	 */
	public String getPayeeAddrPhone1() {
		return getFieldValue("payeeAddrPhone1");
	}

	/**
	 * 收款人地址/電話-2
	 * 
	 * @return
	 */
	public String getPayeeAddrPhone2() {
		return getFieldValue("payeeAddrPhone2");
	}

	/**
	 * 收款銀行 Swift Code
	 * 
	 * @return
	 */
	public String getPayeeSwiftCode() {
		String code = getFieldValue("payeeSwiftCode");
		// 若為 8 碼，直接幫它加上 XXX
		if (code.length() == 8) {
			code = code + "XXX";
		}
		return code;
	}

	/**
	 * 收款銀行名稱-1
	 * 
	 * @return
	 */
	public String getPayeeBankName1() {
		return getFieldValue("payeeBankName1");
	}

	public void setPayeeBankName1(String value) {
		setFieldValue("payeeBankName1", value);
	}

	/**
	 * 收款銀行名稱-2
	 * 
	 * @return
	 */
	public String getPayeeBankName2() {
		return getFieldValue("payeeBankName2");
	}

	public void setPayeeBankName2(String value) {
		setFieldValue("payeeBankName2", value);
	}

	/**
	 * 收款銀行地址-1
	 * 
	 * @return
	 */
	public String getPayeeBankAddr1() {
		return getFieldValue("payeeBankAddr1");
	}

	/**
	 * 收款銀行地址-2
	 * 
	 * @return
	 */
	public String getPayeeBankAddr2() {
		return getFieldValue("payeeBankAddr2");
	}

	/**
	 * CNAPS (收款銀行清算代碼)
	 * 
	 * @return
	 */
	public String getCnaps() {
		return getFieldValue("cnaps");
	}

	/**
	 * 中間銀行 Swift Code
	 * 
	 * @return
	 */
	public String getMiddleSwiftCode() {
		String code = getFieldValue("middleSwiftCode");
		// 若為 8 碼，直接幫它加上 XXX
		if (code.length() == 8) {
			code = code + "XXX";
		}
		return code;
	}

	/**
	 * 收款銀行國別
	 * 
	 * @return
	 */
	public String getPayeeBankNation() {
		return getFieldValue("payeeBankNation");
	}

	/**
	 * 匯出匯款方式 N-不全額到行，Y-全額到行 (允許空白，系統預設為N)
	 * 
	 * @return
	 */
	public String getRemitType() {
		// 允許空白，系統預設為 N
		// return StringUtils.isBlank(getFieldValue("remitType")) ? "N" :
		// getFieldValue("remitType");
		// 2016/3/9: 改成由檔案設定的識別字元判斷，此處不解析
		return getFieldValue("remitType");
	}

	/**
	 * 匯款附言-1
	 * 
	 * @return
	 */
	public String getMemo1() {
		return getFieldValue("memo1");
	}

	// /**
	// * 匯款附言-2
	// *
	// * @return
	// */
	// public String getMemo2() {
	// return getFieldValue("memo2");
	// }
	//
	// /**
	// * 匯款附言-3
	// *
	// * @return
	// */
	// public String getMemo3() {
	// return getFieldValue("memo3");
	// }
	//
	// /**
	// * 匯款附言-4
	// *
	// * @return
	// */
	// public String getMemo4() {
	// return getFieldValue("memo4");
	// }

	/**
	 * 收款人Email
	 * 
	 * @return
	 */
	public String getPayeeEmail() {
		return getFieldValue("payeeEmail");
	}

	/**
	 * 帳戶別名
	 * 
	 * @return
	 */
	public String getPayeeAccountAlias() {
		return getFieldValue("payeeAccountAlias");
	}

	/**
	 * 手續費負擔
	 * 
	 * @return
	 */
	public String getChargeAmtType() {
		return getFieldValue("chargeAmtTypeFr");
	}

	/**
	 * 收款人統編
	 * 
	 * @return
	 */
	public String getPayeeId() {
		return getFieldValue("payeeId");
	}
}
