/*
 * ===========================================================================
 * IBM Confidential
 * AIS Source Materials
 * 
 * 
 * (C) Copyright IBM Corp. 2018.
 *
 * ===========================================================================
 */
package com.cosmos.file.ext;

import com.cosmos.file.bo.FileField;
import com.cosmos.file.bo.FileSection;
import com.cosmos.file.def.IFileDefinition;
import com.cosmos.file.def.StockTxFileDefinition;
import com.cosmos.type.FieldGroup;
import com.ibm.tw.commons.util.StringUtils;

/**
 * <p>
 * 臨櫃證券Tx格式
 * </p>
 * 
 * @author Bear
 * @version 1.0, 2018/4/10
 * @see
 * @since
 */
public class StockTxFileSection {

	/** 檔案區段 */
	private FileSection fileSection;

	public StockTxFileSection() {
		fileSection = new FileSection();
		fileSection.setFieldGroup(FieldGroup.TX);
	}

	public StockTxFileSection(FileSection fileSection) {
		this.fileSection = fileSection;
	}

	public FileSection getFileSection() {
		return fileSection;
	}

	// 轉入帳號
	public String getPayerAccountNo() {
		return getValue(StockTxFileDefinition.payerAccountNo);
	}

	public void setPayerAccountNo(String value) {
		setValue(StockTxFileDefinition.payerAccountNo, value);
	}

	/**
	 * 付款款人統編
	 * 
	 * @return
	 */
	public String getPayerUid() {
		return getValue(StockTxFileDefinition.payerUid);

	}

	public void setPayerUid(String value) {
		setValue(StockTxFileDefinition.payerUid, value);
	}

	/**
	 * 轉帳代碼 B
	 * 
	 * @return
	 */
	public String getPayeeTransId() {
		return getValue(StockTxFileDefinition.payeeTransId);

	}

	public void setPayeeTransId(String value) {
		setValue(StockTxFileDefinition.payeeTransId, value);
	}

	/**
	 * 交易日期
	 * 
	 * @return
	 */
	public String getTxDate() {
		return getValue(StockTxFileDefinition.txDate);

	}

	public void setTxDate(String value) {
		setValue(StockTxFileDefinition.txDate, value);
	}

	/**
	 * 轉帳類別
	 * 
	 * @return
	 */
	public String getPayeeAccountTypeId() {
		return getValue(StockTxFileDefinition.payeeAccountTypeId);

	}

	public void setPayeeAccountTypeId(String value) {
		setValue(StockTxFileDefinition.payeeAccountTypeId, value);
	}

	// 交易金額
	public String getTxAmt() {
		return getValue(StockTxFileDefinition.txAmt);
	}

	public void setTxAmt(String value) {
		setValue(StockTxFileDefinition.txAmt, value);
	}

	/**
	 * 收款人統編
	 * 
	 * @return
	 */
	public String getPayeeUid() {
		return getValue(StockTxFileDefinition.payeeUid);

	}

	public void setPayeeUid(String value) {
		setValue(StockTxFileDefinition.payeeUid, value);
	}

	/**
	 * 客戶證券戶號
	 * 
	 * @return
	 */
	public String getPbsOwnerId() {
		return getValue(StockTxFileDefinition.pbsOwnerId);

	}

	public void setPbsOwnerId(String value) {
		setValue(StockTxFileDefinition.pbsOwnerId, value);
	}

	/**
	 * 營業員代號
	 * 
	 * @return
	 */
	public String getShopId() {
		return getValue(StockTxFileDefinition.shopId);

	}

	public void setShopId(String value) {
		setValue(StockTxFileDefinition.shopId, value);
	}

	/**
	 * 電話號碼
	 * 
	 * @return
	 */
	public String getTel() {
		return getValue(StockTxFileDefinition.tel);

	}

	public void setTel(String value) {
		setValue(StockTxFileDefinition.tel, value);
	}

	/**
	 * 股票代碼
	 * 
	 * @return
	 */
	public String getStocksId() {
		return getValue(StockTxFileDefinition.stocksId);

	}

	public void setStocksId(String value) {
		setValue(StockTxFileDefinition.stocksId, value);
	}

	// ========================================================
	// 以下可共用

	/**
	 * 
	 * @param fileDefinition
	 * @return
	 */
	private String getValue(IFileDefinition fileDefinition) {

		FileField fileField = fileSection.getField(fileDefinition.getId());
		if (fileField == null) {
			return null;
		}
		else {
			return StringUtils.trim(fileField.getValue());
		}
	}

	/**
	 * 
	 * @param fileDefinition
	 * @param value
	 */
	private void setValue(IFileDefinition fileDefinition, String value) {

		if (fileSection == null) {
			fileSection = new FileSection();
		}

		FileField field = fileSection.getField(fileDefinition.getId());
		if (field == null) {
			field = new FileField();
			field.setFieldId(fileDefinition.getId());
			field.setValue(value);
			fileSection.addField(field);
		}
		else {
			field.setValue(value);
		}
	}

	// 以上可共用
	// ========================================================
}
