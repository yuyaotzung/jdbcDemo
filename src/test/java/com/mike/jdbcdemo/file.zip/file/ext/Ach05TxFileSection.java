/*
 * ===========================================================================
 * IBM Confidential
 * AIS Source Materials
 * 
 * 
 * (C) Copyright IBM Corp. 2017.
 *
 * ===========================================================================
 */
package com.cosmos.file.ext;

/**
 * <p>
 * ACH代付扣帳結果提回電子檔檔案規格-明細
 * </p>
 * 
 * @author monica
 * @version 1.0, Nov 27, 2017
 * @see
 * @since
 */
public enum Ach05TxFileSection implements IAchFileDefinition {

	/** 欄位代號(類型, 是否必填 ,長度, 資料庫欄位, 欄位名稱(說明)) */
	PTXNDATE(1, 0, 7, "PTXNDATE", "處理日期"), 
	PTXNTYPE(1, 0, 1, "PTXNTYPE", "交易型態"),  //N:提出 R:提回
	PTDATE(1, 0, 7, "PTDATE", "入扣帳日期"), 
	PCID(1, 0, 10, "CID", "發動者統一編號"), 
	PNO(1, 0, 3, "PNO", "批號"), 
	PTXID(1, 0, 3, "PTXID", "交易代號"), 
	PCODE(1, 0, 1, "PCODE", "交易狀態"), // N:提出,1 上傳轉檔中,2 轉檔成功已授權,3 扣款失敗,4 已提交,R:提回,5已回覆
	PMEMO(1, 0, 32, "PMEMO", "中文備註"), 
	PRCODE(1, 0, 2, "PRCODE", "成功失敗回應代碼"), //00 成功, 99其他
	PTCOUNT(1, 0, 6, "PTCOUNT", "總筆數"),
	PTAMT(1, 0, 12, "PTAMT", "總金額"),
	PPCLNO(1, 0, 12, "PPCLNO", "發動者扣款帳號"),
	PNOTE(1, 0, 20, "PNOTE", "發動者專區") //achSeqKey
	;
	
	/** 資料類型 */
	private int type;
	
	/** 是否必填 */
	private int required;

	/** 檔案格式長度 */
	private int length;

	/** 資料庫存放欄位 */
	private String columnName;

	/** 欄位名稱 說明 */
	private String name;
	
	/**
	 * Constructor
	 *
	 * @param code
	 * @param memo
	 */
	Ach05TxFileSection(int type, int required , int length, String columnName, String name) {
		this.type = type;
		this.length = length;
		this.required = required;
		this.columnName = columnName;
		this.name = name;
	}
	
	/**
	 * 取得id
	 *
	 * @return
	 */
	@Override
	public String getId() {
		return name();
	}

	/**
	 * 取得 type
	 *
	 * @return 傳回 type
	 */
	@Override
	public int getType() {
		return type;
	}

	/**
	 * 取得 length
	 *
	 * @return 傳回 length
	 */
	@Override
	public int getLength() {
		return length;
	}

	/**
	 * 取得 name
	 *
	 * @return 傳回 name
	 */
	@Override
	public String getName() {
		return name;
	}
	
	/**
	 * 取得 length
	 * 
	 * @return 傳回 length
	 */
	public int getRequired() {
		return required;
	}

}
