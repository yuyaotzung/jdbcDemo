/*
 * ===========================================================================
 * IBM Confidential
 * AIS Source Materials
 * 
 * 
 * (C) Copyright IBM Corp. 2018.
 *
 * ===========================================================================
 */
package com.cosmos.file.ext;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.security.DigestInputStream;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Date;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;

import org.apache.commons.io.FileUtils;
import org.apache.commons.net.ftp.FTPClient;

import com.cosmos.code.CibErrorCode;
import com.cosmos.file.bo.FileDetail;
import com.cosmos.file.bo.FileDoc;
import com.cosmos.file.bo.FileSection;
import com.cosmos.param.ISystemParam;
import com.cosmos.param.ext.CibParam;
import com.cosmos.persistence.CosmosDaoFactory;
import com.cosmos.persistence.b2c.dao.B2CSequenceDao;
import com.cosmos.persistence.b2c.dao.IB2CSequenceDao;
import com.cosmos.persistence.b2c.dao.ISystemParamDao;
import com.cosmos.persistence.b2c.entity.SystemParamEntity;
import com.cosmos.persistence.b2c.entity.pk.SystemParamEntityPk;
import com.cosmos.type.FieldGroup;
import com.cosmos.util.CosmosUtils;
import com.cosmos.util.FTPUtils;
import com.cosmos.util.SFTPUtils;
import com.ibm.tw.commons.aop.AOPProxyFactory;
import com.ibm.tw.commons.exception.ActionException;
import com.ibm.tw.commons.exception.CryptException;
import com.ibm.tw.commons.persistence.exception.DatabaseException;
import com.ibm.tw.commons.util.ConvertUtils;
import com.ibm.tw.commons.util.DESUtils;
import com.ibm.tw.commons.util.StringUtils;
import com.ibm.tw.commons.util.time.DateUtils;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.SftpException;

/**
 * <p>
 * 整批一扣多入
 * </p>
 * 
 * @author Bear
 * @version 1.0, 2018/4/10
 * @see
 * @since
 */
public class Cactx102Result12NFileFormatTest {

	// 一扣多入資料夾
	private static final String WORDKING_DIR = "0003";

	// Server
	static String server;

	// Port
	static int port;

	// 帳號
	static String user_put;

	// 密碼
	static String password_put;

	// 帳號
	static String user_get;

	// 密碼
	static String password_get;

	public static void main(String[] args) throws Throwable {

		testMd5();
		
//		init();

//		testExportFile();

//		String fileName = "0003000110072018000000000001806260043593.TMP";
//		testImportFile(fileName);

	}

	private static void init() {
		// Server
		server = "10.86.18.57";
		// Port
		port = ConvertUtils.str2Int("21");
		// 帳號
		user_put = "common";
		// 密碼
		password_put = "common";
		// 帳號
		user_get = "common";
		// 密碼
		password_get = "common";
		
	}
	
	private static void testMd5() throws NoSuchAlgorithmException, IOException {
		
		MessageDigest md = MessageDigest.getInstance("MD5");
		byte[] hashInBytes = checksum("d:\\182\\md5-906\\0014096031102018201810310010000803642000.20181031174417", md);
        System.out.println(bytesToHex(hashInBytes));

	}
	
	private static byte[] checksum(String filePath, MessageDigest md) throws IOException{
		
		DigestInputStream dis = new DigestInputStream(new FileInputStream(filePath), md);
		
		while(dis.read() != -1){
			md= dis.getMessageDigest();
		}
		
		return md.digest();
	}
	
	private static String bytesToHex(byte[] hashInBytes) {

        StringBuilder sb = new StringBuilder();
        for (byte b : hashInBytes) {
            sb.append(String.format("%02x", b));
        }
        return sb.toString();
    }

	

	private static void testExportFile() throws JSchException, SftpException, IOException, DatabaseException, ActionException, NoSuchAlgorithmException {
		Cactx102Result12NFileFormat fileFormat = new Cactx102Result12NFileFormat("CACTX102");

		// 案件序號
		String flowDocId = generateCaseNo();

		// 交易日期
		Date txDate = new Date();

		prepareHeaders(fileFormat, flowDocId, txDate);
		prepareDetails(fileFormat, flowDocId);
		prepareFooters(fileFormat);
		byte[] data = new byte[0];

		
		
		data = fileFormat.toFile();
		
		// md5
		MessageDigest md = MessageDigest.getInstance("MD5");
		md.update(data);
		byte[] hashInBytes = md.digest();
		
		System.out.println("md5 checksum:" + bytesToHex(hashInBytes));
		

		String fileName = getFileName(txDate, flowDocId);

		System.out.println("fileName:" + fileName);

		// TODO 備份路徑??
		// 備份檔案
		FileUtils.writeByteArrayToFile(new File("C:/ACHBACKUP/" + fileName + ".TXT"), data);
		
		FTPClient ftpClient = null;

		try {
			ByteArrayInputStream is = new ByteArrayInputStream(data);
			ftpClient = FTPUtils.connect(server, port, user_put, password_put, "");
			boolean result = false;
			// result = ftpClient.deleteFile(fileName);
			// System.err.println("replyCode=" + ftpClient.getReplyCode());
			result = ftpClient.storeFile(fileName, is);
			System.out.println("是否上傳成功 =" + result);
			is.close();

			if (!result) {
				System.out.println("上傳失敗");
			}
		}
		catch (IOException e) {
			e.printStackTrace();
		}
		catch (Throwable e) {
			e.printStackTrace();
		}
		finally {
			try {
				FTPUtils.disconnect(ftpClient);
			}
			catch (Throwable e) {
				e.printStackTrace();
			}
		}
		

	}

	private static void prepareHeaders(Cactx102Result12NFileFormat fileFormat, String flowDocId, Date txDate) {

		Cactx102Result12NHeaderFileSection section = new Cactx102Result12NHeaderFileSection();
		// 交易使用的分行號碼
		// TRANS_BRANCH
		section.setBranchNo(StringUtils.leftPad("0001", 5, "0"));
		// 交易使用的行員號碼
		section.setTellerNo(StringUtils.leftPad("90002535", 8, "0"));
		// 交易使用的端末機號
		section.setTermNo(StringUtils.leftPad("999", 3, "0"));
		// 交易日期
		section.setTxDate(DateUtils.formatDate(txDate, "ddMMyyyy"));
		// 為了與畫面parse一致,讀入資料的secNo由1開始
		section.getFileSection().setSectionNo(1);
		section.setPayAcct(StringUtils.leftPad("60010100008208", 14, "0"));// 付款人帳號
		section.setPayName(StringUtils.rightPad("開立聯屬存款有限公司", 76, " "));// 付款人戶名

		section.setPayerUid(StringUtils.rightPad("00021407", 10, " "));// 付款人統編
		section.setPayerResultSysId(StringUtils.rightPad("", 6, " "));// 
		section.setPayerResult(StringUtils.rightPad("", 8, " "));// 

		fileFormat.addHeader(section);
	}

	private static void prepareDetails(Cactx102Result12NFileFormat fileFormat, String flowDocId) {
		// 第一筆
		Cactx102Result12NTxFileSection section = new Cactx102Result12NTxFileSection();
		section.setBatchNo(StringUtils.leftPad(flowDocId, 24, "0"));
		section.setSerno(StringUtils.leftPad("00001", 5, "0"));
		section.setPayChanel(StringUtils.rightPad("1", 1, " ")); // 1：自行轉帳,2：跨行匯款
		section.setReceiveBankCode(StringUtils.leftPad("8100364", 7, "0"));// 收款銀行代號
		section.setRollInAcct(StringUtils.leftPad("60090100000268", 16, "0"));// 轉入帳號
		section.setAmount(StringUtils.leftPad("1000000", 17, "0"));// 交易金額=1000
		section.setPromoCode(StringUtils.leftPad("00", 2, " "));// 提示碼? TODO
		section.setRemarks(StringUtils.rightPad("remarks", 16, " "));// 存摺附註??
		// TODO
		// 對應DB哪個欄位
		section.setCheckId(StringUtils.leftPad("", 10, " "));// 檢核ID
		section.setCheckName(StringUtils.leftPad("", 60, " "));// 檢核戶名
		section.setFee(StringUtils.leftPad("00000", 5, "0"));// 櫃員手續費/匯款手續費
		section.setPostScript(StringUtils.rightPad("memo", 76, " "));// 附言
		section.setBancsStat(StringUtils.rightPad("9999", 4, "0"));// BaNCS中心執行結果
		section.setFepResult(StringUtils.rightPad("", 4, " "));// 匯款處理結果
		section.setFepNo(StringUtils.rightPad("", 7, " "));// 匯款編號
		section.setJrnlNo(StringUtils.rightPad("000000000", 9, "0"));// 交易序號
		// 為了與畫面parse一致,讀入資料的secNo由1開始
		section.getFileSection().setSectionNo(1);

		fileFormat.addDetails(section);

		// 第二筆
		Cactx102Result12NTxFileSection section2 = new Cactx102Result12NTxFileSection();
		section2.setBatchNo(StringUtils.leftPad(flowDocId, 24, "0"));
		section2.setSerno(StringUtils.leftPad("00002", 5, "0"));
		section2.setPayChanel(StringUtils.rightPad("1", 1, " ")); // 1：自行轉帳,2：跨行匯款
		section2.setReceiveBankCode(StringUtils.leftPad("8100364", 7, "0"));// 收款銀行代號
		section2.setRollInAcct(StringUtils.leftPad("60090100000251", 16, "0"));// 轉入帳號
		section2.setAmount(StringUtils.leftPad("1000000", 17, "0"));// 交易金額=1000
		section2.setPromoCode(StringUtils.leftPad("00", 2, " "));// 提示碼
		section2.setRemarks(StringUtils.rightPad("remarks2", 16, " "));// 存摺附註
		section2.setCheckId(StringUtils.leftPad("", 10, " "));// 檢核ID
		section2.setCheckName(StringUtils.rightPad("", 60, " "));// 檢核戶名
		section2.setFee(StringUtils.leftPad("00000", 5, "0"));// 櫃員手續費/匯款手續費
		section2.setPostScript(StringUtils.rightPad("memo2", 76, " "));// 附言
		section2.setBancsStat(StringUtils.rightPad("9999", 4, "0"));// BaNCS中心執行結果
		section2.setFepResult(StringUtils.rightPad("", 4, " "));// 匯款處理結果
		section2.setFepNo(StringUtils.rightPad("", 7, " "));// 匯款編號
		section2.setJrnlNo(StringUtils.leftPad("000000000", 9, "0"));// 交易序號
		// 為了與畫面parse一致,讀入資料的secNo由1開始
		section2.getFileSection().setSectionNo(1);

		fileFormat.addDetails(section2);

		// 第三筆
		Cactx102Result12NTxFileSection section3 = new Cactx102Result12NTxFileSection();
		section3.setBatchNo(StringUtils.leftPad(flowDocId, 24, "0"));
		section3.setSerno(StringUtils.leftPad("00003", 5, "0"));
		section3.setPayChanel(StringUtils.rightPad("1", 1, " ")); // 1：自行轉帳,2：跨行匯款
		section3.setReceiveBankCode(StringUtils.leftPad("8100364", 7, "0"));// 收款銀行代號
		section3.setRollInAcct(StringUtils.leftPad("60090100000219", 16, "0"));// 轉入帳號
		section3.setAmount(StringUtils.leftPad("1000000", 17, "0"));// 交易金額=3000
		section3.setPromoCode(StringUtils.leftPad("00", 2, " "));// 提示碼
		section3.setRemarks(StringUtils.rightPad("remarks2", 16, " "));// 存摺附註
		section3.setCheckId(StringUtils.leftPad("", 10, " "));// 檢核ID
		section3.setCheckName(StringUtils.rightPad("", 60, " "));// 檢核戶名
		section3.setFee(StringUtils.leftPad("00000", 5, "0"));// 櫃員手續費/匯款手續費
		section3.setPostScript(StringUtils.rightPad("memo2", 76, " "));// 附言
		section3.setBancsStat(StringUtils.rightPad("9999", 4, "0"));// BaNCS中心執行結果
		section3.setFepResult(StringUtils.rightPad("", 4, " "));// 匯款處理結果
		section3.setFepNo(StringUtils.rightPad("", 7, " "));// 匯款編號
		section3.setJrnlNo(StringUtils.leftPad("000000000", 9, "0"));// 交易序號
		// 為了與畫面parse一致,讀入資料的secNo由1開始
		section3.getFileSection().setSectionNo(1);

		fileFormat.addDetails(section3);

		// 第四筆
		Cactx102Result12NTxFileSection section4 = new Cactx102Result12NTxFileSection();
		section4.setBatchNo(StringUtils.leftPad(flowDocId, 24, "0"));
		section4.setSerno(StringUtils.leftPad("00004", 5, "0"));
		section4.setPayChanel(StringUtils.rightPad("1", 1, " ")); // 1：自行轉帳,2：跨行匯款
		section4.setReceiveBankCode(StringUtils.leftPad("8100364", 7, "0"));// 收款銀行代號
		section4.setRollInAcct(StringUtils.leftPad("60090100000206", 16, "0"));// 轉入帳號
		section4.setAmount(StringUtils.leftPad("1000000", 17, "0"));// 交易金額=3000
		section4.setPromoCode(StringUtils.leftPad("00", 2, " "));// 提示碼
		section4.setRemarks(StringUtils.rightPad("remarks2", 16, " "));// 存摺附註
		section4.setCheckId(StringUtils.leftPad("", 10, " "));// 檢核ID
		section4.setCheckName(StringUtils.rightPad("", 60, " "));// 檢核戶名
		section4.setFee(StringUtils.leftPad("00000", 5, "0"));// 櫃員手續費/匯款手續費
		section4.setPostScript(StringUtils.rightPad("memo2", 76, " "));// 附言
		section4.setBancsStat(StringUtils.rightPad("9999", 4, "0"));// BaNCS中心執行結果
		section4.setFepResult(StringUtils.rightPad("", 4, " "));// 匯款處理結果
		section4.setFepNo(StringUtils.rightPad("", 7, " "));// 匯款編號
		section4.setJrnlNo(StringUtils.leftPad("000000000", 9, "0"));// 交易序號
		// 為了與畫面parse一致,讀入資料的secNo由1開始
		section4.getFileSection().setSectionNo(1);

		fileFormat.addDetails(section4);

		// 第五筆
		Cactx102Result12NTxFileSection section5 = new Cactx102Result12NTxFileSection();
		section5.setBatchNo(StringUtils.leftPad(flowDocId, 24, "0"));
		section5.setSerno(StringUtils.leftPad("00005", 5, "0"));
		section5.setPayChanel(StringUtils.rightPad("1", 1, " ")); // 1：自行轉帳,2：跨行匯款
		section5.setReceiveBankCode(StringUtils.leftPad("8100364", 7, "0"));// 收款銀行代號
		section5.setRollInAcct(StringUtils.leftPad("60090100000222", 16, "0"));// 轉入帳號
		section5.setAmount(StringUtils.leftPad("1000000", 17, "0"));// 交易金額=1000
		section5.setPromoCode(StringUtils.leftPad("00", 2, " "));// 提示碼
		section5.setRemarks(StringUtils.rightPad("remarks2", 16, " "));// 存摺附註
		section5.setCheckId(StringUtils.leftPad("", 10, " "));// 檢核ID
		section5.setCheckName(StringUtils.rightPad("", 60, " "));// 檢核戶名
		section5.setFee(StringUtils.leftPad("00000", 5, "0"));// 櫃員手續費/匯款手續費
		section5.setPostScript(StringUtils.rightPad("memo2", 76, " "));// 附言
		section5.setBancsStat(StringUtils.rightPad("9999", 4, "0"));// BaNCS中心執行結果
		section5.setFepResult(StringUtils.rightPad("", 4, " "));// 匯款處理結果
		section5.setFepNo(StringUtils.rightPad("", 7, " "));// 匯款編號
		section5.setJrnlNo(StringUtils.leftPad("000000000", 9, "0"));// 交易序號
		// 為了與畫面parse一致,讀入資料的secNo由1開始
		section5.getFileSection().setSectionNo(1);

		fileFormat.addDetails(section5);

		// 第六筆
		Cactx102Result12NTxFileSection section6 = new Cactx102Result12NTxFileSection();
		section6.setBatchNo(StringUtils.leftPad(flowDocId, 24, "0"));
		section6.setSerno(StringUtils.leftPad("00006", 5, "0"));
		section6.setPayChanel(StringUtils.rightPad("2", 1, " ")); // 1：自行轉帳,2：跨行匯款
		// section6.setReceiveBankCode(StringUtils.leftPad("0210018", 7,
		// " "));// 收款銀行代號
		section6.setReceiveBankCode(StringUtils.leftPad("8100364", 7, " "));// 收款銀行代號
		section6.setRollInAcct(StringUtils.leftPad("00123456789012", 16, "0"));// 轉入帳號
		section6.setAmount(StringUtils.leftPad("1000000", 17, "0"));// 交易金額=3000
		section6.setPromoCode(StringUtils.leftPad("00", 2, " "));// 提示碼
		section6.setRemarks(StringUtils.rightPad("remarks2", 16, " "));// 存摺附註
		section6.setCheckId(StringUtils.leftPad("", 10, " "));// 檢核ID
		section6.setCheckName(StringUtils.rightPad("謝美美", 60, " "));// 檢核戶名
		section6.setFee(StringUtils.leftPad("00000", 5, "0"));// 櫃員手續費/匯款手續費
		section6.setPostScript(StringUtils.rightPad("memo2", 76, " "));// 附言
		section6.setBancsStat(StringUtils.rightPad("9999", 4, "0"));// BaNCS中心執行結果
		section6.setFepResult(StringUtils.rightPad("", 4, " "));// 匯款處理結果
		section6.setFepNo(StringUtils.rightPad("", 7, " "));// 匯款編號
		section6.setJrnlNo(StringUtils.leftPad("000000000", 9, "0"));// 交易序號
		// 為了與畫面parse一致,讀入資料的secNo由1開始
		section6.getFileSection().setSectionNo(1);

		fileFormat.addDetails(section6);

		// 第七筆
		Cactx102Result12NTxFileSection section7 = new Cactx102Result12NTxFileSection();
		section7.setBatchNo(StringUtils.leftPad(flowDocId, 24, "0"));
		section7.setSerno(StringUtils.leftPad("00007", 5, "0"));
		section7.setPayChanel(StringUtils.rightPad("2", 1, " ")); // 1：自行轉帳,2：跨行匯款
		section7.setReceiveBankCode(StringUtils.leftPad("8100364", 7, "0"));// 收款銀行代號
		section7.setRollInAcct(StringUtils.leftPad("00123456789012", 16, "0"));// 轉入帳號
		section7.setAmount(StringUtils.leftPad("1000000", 17, "0"));// 交易金額=3000
		section7.setPromoCode(StringUtils.leftPad("00", 2, " "));// 提示碼
		section7.setRemarks(StringUtils.rightPad("remarks2", 16, " "));// 存摺附註
		section7.setCheckId(StringUtils.leftPad("", 10, " "));// 檢核ID
		section7.setCheckName(StringUtils.rightPad("謝美美", 60, " "));// 檢核戶名
		section7.setFee(StringUtils.leftPad("00000", 5, "0"));// 櫃員手續費/匯款手續費
		section7.setPostScript(StringUtils.rightPad("memo2", 76, " "));// 附言
		section7.setBancsStat(StringUtils.rightPad("9999", 4, "0"));// BaNCS中心執行結果
		section7.setFepResult(StringUtils.rightPad("", 4, " "));// 匯款處理結果
		section7.setFepNo(StringUtils.rightPad("", 7, " "));// 匯款編號
		section7.setJrnlNo(StringUtils.leftPad("000000000", 9, "0"));// 交易序號
		// 為了與畫面parse一致,讀入資料的secNo由1開始
		section7.getFileSection().setSectionNo(1);

		fileFormat.addDetails(section7);

		// 第八筆
		Cactx102Result12NTxFileSection section8 = new Cactx102Result12NTxFileSection();
		section8.setBatchNo(StringUtils.leftPad(flowDocId, 24, "0"));
		section8.setSerno(StringUtils.leftPad("00008", 5, "0"));
		section8.setPayChanel(StringUtils.rightPad("2", 1, " ")); // 1：自行轉帳,2：跨行匯款
		section8.setReceiveBankCode(StringUtils.leftPad("8100364", 7, " "));// 收款銀行代號
		section8.setRollInAcct(StringUtils.leftPad("00123456789012", 16, "0"));// 轉入帳號
		section8.setAmount(StringUtils.leftPad("1000000", 17, "0"));// 交易金額=3000
		section8.setPromoCode(StringUtils.leftPad("00", 2, " "));// 提示碼
		section8.setRemarks(StringUtils.rightPad("remarks2", 16, " "));// 存摺附註
		section8.setCheckId(StringUtils.leftPad("", 10, " "));// 檢核ID
		section8.setCheckName(StringUtils.rightPad("謝美美", 60, " "));// 檢核戶名
		section8.setFee(StringUtils.leftPad("00000", 5, "0"));// 櫃員手續費/匯款手續費
		section8.setPostScript(StringUtils.rightPad("memo2", 76, " "));// 附言
		section8.setBancsStat(StringUtils.rightPad("9999", 4, "0"));// BaNCS中心執行結果
		section8.setFepResult(StringUtils.rightPad("", 4, " "));// 匯款處理結果
		section8.setFepNo(StringUtils.rightPad("", 7, " "));// 匯款編號
		section8.setJrnlNo(StringUtils.leftPad("000000000", 9, "0"));// 交易序號
		// 為了與畫面parse一致,讀入資料的secNo由1開始
		section8.getFileSection().setSectionNo(1);

		fileFormat.addDetails(section8);

		// 第九筆
		Cactx102Result12NTxFileSection section9 = new Cactx102Result12NTxFileSection();
		section9.setBatchNo(StringUtils.leftPad(flowDocId, 24, "0"));
		section9.setSerno(StringUtils.leftPad("00009", 5, "0"));
		section9.setPayChanel(StringUtils.rightPad("2", 1, " ")); // 1：自行轉帳,2：跨行匯款
		section9.setReceiveBankCode(StringUtils.leftPad("8100364", 7, "0"));// 收款銀行代號
		section9.setRollInAcct(StringUtils.leftPad("00123456789012", 16, "0"));// 轉入帳號
		section9.setAmount(StringUtils.leftPad("1000000", 17, "0"));// 交易金額=3000
		section9.setPromoCode(StringUtils.leftPad("00", 2, " "));// 提示碼
		section9.setRemarks(StringUtils.rightPad("remarks2", 16, " "));// 存摺附註
		section9.setCheckId(StringUtils.leftPad("", 10, " "));// 檢核ID
		section9.setCheckName(StringUtils.rightPad("謝美美", 60, " "));// 檢核戶名
		section9.setFee(StringUtils.leftPad("00000", 5, "0"));// 櫃員手續費/匯款手續費
		section9.setPostScript(StringUtils.rightPad("memo2", 76, " "));// 附言
		section9.setBancsStat(StringUtils.rightPad("9999", 4, "0"));// BaNCS中心執行結果
		section9.setFepResult(StringUtils.rightPad("", 4, " "));// 匯款處理結果
		section9.setFepNo(StringUtils.rightPad("", 7, " "));// 匯款編號
		section9.setJrnlNo(StringUtils.leftPad("000000000", 9, "0"));// 交易序號
		// 為了與畫面parse一致,讀入資料的secNo由1開始
		section9.getFileSection().setSectionNo(1);

		fileFormat.addDetails(section9);

		// 第十筆
		Cactx102Result12NTxFileSection section10 = new Cactx102Result12NTxFileSection();
		section10.setBatchNo(StringUtils.leftPad(flowDocId, 24, "0"));
		section10.setSerno(StringUtils.leftPad("00010", 5, "0"));
		section10.setPayChanel(StringUtils.rightPad("2", 1, " ")); // 1：自行轉帳,2：跨行匯款
		section10.setReceiveBankCode(StringUtils.leftPad("8100364", 7, "0"));// 收款銀行代號
		section10.setRollInAcct(StringUtils.leftPad("00123456789012", 16, "0"));// 轉入帳號
		section10.setAmount(StringUtils.leftPad("1000000", 17, "0"));// 交易金額=3000
		section10.setPromoCode(StringUtils.leftPad("00", 2, " "));// 提示碼
		section10.setRemarks(StringUtils.rightPad("remarks2", 16, " "));// 存摺附註
		section10.setCheckId(StringUtils.leftPad("", 10, " "));// 檢核ID
		section10.setCheckName(StringUtils.rightPad("謝美美", 60, " "));// 檢核戶名
		section10.setFee(StringUtils.leftPad("00000", 5, "0"));// 櫃員手續費/匯款手續費
		section10.setPostScript(StringUtils.rightPad("memo2", 76, " "));// 附言
		section10.setBancsStat(StringUtils.rightPad("9999", 4, "0"));// BaNCS中心執行結果
		section10.setFepResult(StringUtils.rightPad("", 4, " "));// 匯款處理結果
		section10.setFepNo(StringUtils.rightPad("", 7, " "));// 匯款編號
		section10.setJrnlNo(StringUtils.leftPad("000000000", 9, "0"));// 交易序號
		// 為了與畫面parse一致,讀入資料的secNo由1開始
		section10.getFileSection().setSectionNo(1);

		fileFormat.addDetails(section10);

	}

	private static void prepareFooters(Cactx102Result12NFileFormat fileFormat) {
		Cactx102Result12NFooterFileSection section = new Cactx102Result12NFooterFileSection();
		section.setTotalAmt(StringUtils.leftPad("10000000", 17, "0"));
		section.setTotalCount(StringUtils.leftPad("3", 6, "0"));
		section.getFileSection().setSectionNo(1);
		fileFormat.addFooter(section);
	}

	private static void testImportFile(String fileName) throws JSchException, SftpException, IOException, ActionException {

		// byte[] fileContent = FileUtils.readFileToByteArray(new
		// File("C:/ACHBACKUP/"+fileName));

		byte[] fileContent = null;
		ChannelSftp sftp = null;
		ByteArrayOutputStream os = new ByteArrayOutputStream();
		try {
			sftp = SFTPUtils.connect(server, port, user_get, password_get, "/");

			sftp.get(fileName, os);

			fileContent = os.toByteArray();

			if (fileContent == null) {
				System.err.println("sftp download file Error, fileName:" + fileName);
			}

		}
		catch (JSchException e) {
			System.err.println("SFTP連線失敗");
			e.printStackTrace();
			throw e;
		}
		catch (SftpException e) {
			e.printStackTrace();
			throw e;
		}
		finally {
			try {
				os.close();
				SFTPUtils.disconnect(sftp);
			}
			catch (JSchException e) {
				System.err.println("SFTP離線失敗");
				e.printStackTrace();
			}
			catch (IOException e) {
				System.err.println("ByteArrayOutputStream close failed , fileName:" + fileName);
				e.printStackTrace();
			}
		}

		Cactx102Result12NFileFormat fileFormat = new Cactx102Result12NFileFormat("CACTX102");
		boolean result = fileFormat.parseFile(fileContent);

		System.out.println("result:" + result);

		FileDoc fileDoc = fileFormat.getFileDoc();

		for (FileDetail fileDetail : fileDoc.getDetails()) {
			System.out.println("=================== " + fileDetail.getRowNo() + " ====================");

			FileSection fileSection = fileDetail.getFirstSection();
			if (fileDetail.getFirstSection().getFieldGroup() == FieldGroup.HEADER) {
				Cactx102Result12NHeaderFileSection header = new Cactx102Result12NHeaderFileSection(fileSection);
				System.out.println("==========Header==========");
				System.out.println("getBranchNo:" + header.getBranchNo());
				System.out.println("getPayerAccountNo:" + header.getPayAcct());
				System.out.println("getPayerName:" + header.getPayName());
				System.out.println("getPayerUid:" + header.getPayerUid());

			}
			else if (fileDetail.getFirstSection().getFieldGroup() == FieldGroup.FOOTER) {
				Cactx102Result12NFooterFileSection footer = new Cactx102Result12NFooterFileSection(fileSection);
				System.out.println("==========Footer==========");
				System.out.println("getTotalCount:" + footer.getTotalCount());
				System.out.println("getTotalAmt:" + footer.getTotalAmt());

			}
			else {
				Cactx102Result12NTxFileSection detail = new Cactx102Result12NTxFileSection(fileSection);
				System.out.println("==========Tx==========");
				System.out.println("getBatchNo:" + detail.getBatchNo());
				System.out.println("getSerno:" + detail.getSerno());
				System.out.println("getPayChanel:" + detail.getPayChanel());

				System.out.println("getReceiveBankCode:" + detail.getReceiveBankCode());
				System.out.println("getTxAmt:" + detail.getAmount());
				System.out.println("getRemarks:" + detail.getRemarks());
				System.out.println("BaNCS中心執行結果getBancsStat:" + detail.getBancsStat());
				System.out.println("匯款處理結果getFepResult:" + detail.getFepResult());
				System.out.println("匯款編號getFepNo:" + detail.getFepNo());
				System.out.println("交易序號getJournalNo:" + detail.getJrnlNo());
			}

		}

	}

	/*
	 * 來源檔檔案名稱：9999(流程識別碼)+9999(主辦分行代碼)+交易日期(西元年DDMMYYYY)+999999999999999999999999
	 * (批號).TXT
	 */
	private static String getFileName(Date txDate, String batchNo) {

		return WORDKING_DIR + "0001" + DateUtils.formatDate(txDate, "ddMMyyyy") + StringUtils.leftPad(batchNo, 24, "0");
	}

	public static String generateCaseNo() throws DatabaseException {
		String value = "";
		IB2CSequenceDao dao = (IB2CSequenceDao) AOPProxyFactory.getDao(IB2CSequenceDao.class, B2CSequenceDao.class);
		String caseNoSeq = StringUtils.leftPad(String.valueOf(dao.getCaseNoSeq() % 10000000), 7, "0");
		value = DateUtils.getSimpleISODateStr(new Date()).substring(2) + caseNoSeq;
		return value;
	}

	/** 系統參數代碼表 */
	private static Map<SystemParamEntityPk, String> systemParamMap = null;

	/**
	 * 載入系統參數
	 */
	synchronized private static void loadSystemParamMap() {

		if (systemParamMap != null) {
			return;
		}

		systemParamMap = new Hashtable<SystemParamEntityPk, String>();

		ISystemParamDao dao = CosmosDaoFactory.getSystemParamDao();

		try {

			// System.err.println("loadSystemParamMap");

			List<SystemParamEntity> entities = dao.findAll();

			for (SystemParamEntity entity : entities) {

				SystemParamEntityPk pk = new SystemParamEntityPk(entity.getCategory(), entity.getKey());

				String value = StringUtils.trimToEmpty(entity.getValue());

				// 加入密碼 DECRYPT 的功能
				if (1 == entity.getPasswordFlag()) {
					value = DESUtils.decrypt(value);
				}

				systemParamMap.put(pk, value);

			}
		}
		catch (DatabaseException e) {
			throw new RuntimeException("cannot load SystemParam ", e);
		}
		catch (CryptException e) {
			throw new RuntimeException("cannot load SystemParam ", e);
		}

	}

	public static Map<SystemParamEntityPk, String> getSystemParamMap() {

		if (null == systemParamMap) {
			loadSystemParamMap();
		}
		return systemParamMap;
	}

	/**
	 * 取得參數值
	 * 
	 * @param param
	 * @return
	 */
	public static String getSystemParamValue(ISystemParam param) {

		SystemParamEntityPk pk = new SystemParamEntityPk(param.getCategory().getCode(), param.getKey());

		return getSystemParamMap().get(pk);
	}

}
