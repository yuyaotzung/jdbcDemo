/*
 * ===========================================================================
 * IBM Confidential
 * AIS Source Materials
 * 
 * 
 * (C) Copyright IBM Corp. 2011.
 *
 * ===========================================================================
 */
package com.cosmos.file.ext;

import com.cosmos.file.bo.FileField;
import com.cosmos.file.bo.FileSection;
import com.ibm.tw.commons.util.StringUtils;

/**
 * <p>
 * Salary Item File Section
 * </p>
 * 
 * @author hank
 * @version 1.0, 2016/4/28
 * @see
 * @since
 */
public class SalaryItemFileSection {

	/** 檔案區段 */
	private FileSection fileSection;

	public SalaryItemFileSection(FileSection fileSection) {
		this.fileSection = fileSection;
	}

	/**
	 * 取得順序
	 * 
	 * @return
	 */
	public int getOrderNo() {
		return fileSection.getSectionNo() - 1;
	}

	/**
	 * 取得項目種類
	 * 
	 * @return
	 */
	public String getItemType() {
		FileField fileField = fileSection.getField("salaryItemType");
		if (fileField == null) {
			return null;
		}
		return StringUtils.trim(fileField.getValue());
	}

	/**
	 * 取得項目說明
	 * 
	 * @return
	 */
	public String getItemTxt() {
		FileField fileField = fileSection.getField("salaryItemTxt");
		if (fileField == null) {
			return null;
		}
		return StringUtils.trimAllBigSpace(StringUtils.trim(fileField.getValue()));
	}

	/**
	 * 取得項目內容
	 * 
	 * @return
	 */
	public String getItemValue() {
		FileField fileField = fileSection.getField("salaryItemValue");
		if (fileField == null) {
			return null;
		}
		return StringUtils.trimAllBigSpace(StringUtils.trim(fileField.getValue()));
	}

}
