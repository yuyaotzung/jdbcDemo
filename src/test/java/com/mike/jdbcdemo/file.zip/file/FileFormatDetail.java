/*
 * ===========================================================================
 * IBM Confidential
 * AIS Source Materials
 * 
 * 
 * (C) Copyright IBM Corp. 2011.
 *
 * ===========================================================================
 */
package com.cosmos.file;

import com.cosmos.persistence.CosmosDaoFactory;
import com.cosmos.persistence.b2c.dao.IFileFormatDetailDao;
import com.cosmos.persistence.b2c.dao.IFileFormatFieldDao;
import com.cosmos.persistence.b2c.entity.FileFormatDetailEntity;
import com.cosmos.persistence.b2c.entity.FileFormatFieldEntity;
import com.cosmos.type.FieldGroup;
import com.cosmos.type.TaskType;
import com.ibm.tw.commons.persistence.exception.DatabaseException;

/**
 * <p>
 * TODO description
 * </p>
 * 
 * @author Leo
 * @version 1.0, 2011/6/8
 * @see
 * @since
 */
public class FileFormatDetail {

	/** 所屬交易 */
	private TaskType taskType;

	/** 檔案格式明細檔 */
	private FileFormatDetailEntity detail;

	/** 檔案格式定義檔 */
	private FileFormatFieldEntity field;

	/**
	 * Constructor
	 * 
	 * @throws DatabaseException
	 */
	public FileFormatDetail(TaskType taskType, String fieldId, String fieldName, int length, int orderNo) throws DatabaseException {
		this(taskType, getNewEntity(fieldId, fieldName, length, orderNo));
	}

	/**
	 * Constructor
	 * 
	 * @throws DatabaseException
	 */
	public FileFormatDetail(TaskType taskType, FileFormatDetailEntity detail) throws DatabaseException {
		this.taskType = taskType;
		this.detail = detail;

		// 載入定義
		FileFormatFieldEntity field = loadField(detail);

		if (field != null) {
			this.field = field;
		}
	}

	/**
	 * Constructor
	 * 
	 */
	public FileFormatDetail(TaskType taskType, FileFormatDetailEntity detail, FileFormatFieldEntity field) {
		this.taskType = taskType;
		this.detail = detail;
		this.field = field;
	}

	/**
	 * 載入定義
	 * 
	 * @param detail
	 * @throws DatabaseException
	 */
	private FileFormatFieldEntity loadField(FileFormatDetailEntity detail) throws DatabaseException {

		String fieldId = detail.getFieldId();

		IFileFormatFieldDao dao = CosmosDaoFactory.getFileFormatFieldDao();

		field = dao.findByFieldId(fieldId, taskType.getCode());

		return field;
	}

	/**
	 * 移除交易明細檔
	 * 
	 * @return
	 * @throws DatabaseException
	 */
	public void remove() throws DatabaseException {

		IFileFormatDetailDao dao = CosmosDaoFactory.getFileFormatDetailDao();

		dao.remove(detail);
	}

	/**
	 * 新增交易明細檔
	 * 
	 * @throws DatabaseException
	 */
	public void insert() throws DatabaseException {

		IFileFormatDetailDao dao = CosmosDaoFactory.getFileFormatDetailDao();

		dao.insert(detail);
	}

	/**
	 * 更新交易明細檔
	 * 
	 * @throws DatabaseException
	 */
	public void update() throws DatabaseException {

		IFileFormatDetailDao dao = CosmosDaoFactory.getFileFormatDetailDao();

		dao.update(detail);
	}

	/**
	 * 依據Input產生FileFormatDetailEntity
	 * 
	 * @param fieldId
	 * @param fieldName
	 * @param length
	 * @param orderNo
	 * @return
	 */
	private static FileFormatDetailEntity getNewEntity(String fieldId, String fieldName, int length, int orderNo) {
		FileFormatDetailEntity detail = new FileFormatDetailEntity();

		detail.setFieldId(fieldId);
		detail.setFieldName(fieldName);
		detail.setLength(length);
		detail.setOrderNo(orderNo);

		return detail;
	}

	/**
	 * 取得 所屬群組
	 * 
	 * @return
	 */
	public FieldGroup getFieldGroup() {
		if (field == null) {
			return FieldGroup.UNKNOWN;
		}
		else {
			FieldGroup fieldGroup = FieldGroup.valueOf(field.getFieldGroup());
			return fieldGroup;
		}
	}

	/**
	 * 設定 主檔鍵值
	 * 
	 * @param fileFormatKey
	 */
	public void setFileFormatKey(long fileFormatKey) {
		detail.setFileFormatKey(fileFormatKey);
	}

	/**
	 * 取得 次序
	 * 
	 * @return
	 */
	public int getOrderNo() {
		return detail.getOrderNo();
	}

	/**
	 * 取得 長度
	 * 
	 * @return
	 */
	public int getLength() {
		return detail.getLength();
	}

	/**
	 * 取得 欄位Id
	 * 
	 * @return
	 */
	public String getFieldId() {
		return detail.getFieldId();
	}

	/**
	 * 是否為文字
	 * 
	 * @return
	 */
	public boolean isText() {
		return field.getType() == 1;
	}

	/**
	 * 是否為整數
	 * 
	 * @return
	 */
	public boolean isInteger() {
		return field.getType() == 2;
	}

	/**
	 * 是否為小數
	 * 
	 * @return
	 */
	public boolean isDouble() {
		return field.getType() == 3;
	}

	/**
	 * 是否為日期
	 * 
	 * @return
	 */
	public boolean isDate() {
		return field.getType() == 4;
	}

	/**
	 * 文字(不允許中文及不允許特殊字元)
	 * 
	 * @return
	 */
	public boolean isNotChineseAndSpecialCharText() {
		return field.getType() == 5;
	}

	/**
	 * 文字(允許中文及允許特殊字元)
	 * 
	 * @return
	 */
	public boolean isChineseAndSpecialCharText() {
		return field.getType() == 6;
	}

	/**
	 * 取得開始位置
	 * 
	 * @return
	 */
	public int getStartPos() {
		return detail.getStartPosition();
	}

	/**
	 * 是否為必填
	 * 
	 * @return
	 */
	public boolean isRequired() {

		return 1 == field.getRequired();
	}

	public FileFormatDetailEntity getDetail() {
		return detail;
	}

	public void setDetail(FileFormatDetailEntity detail) {
		this.detail = detail;
	}

	public FileFormatFieldEntity getField() {
		return field;
	}

	public void setField(FileFormatFieldEntity field) {
		this.field = field;
	}

	public int getAmtType() {
		return detail.getAmtType();
	}

	public int getDecLength() {
		return detail.getDecLength();
	}
	
	public int getTextType() {
		return detail.getTextType();
	}

	public String getTextContent() {
		return detail.getTextContent();
	}

}
