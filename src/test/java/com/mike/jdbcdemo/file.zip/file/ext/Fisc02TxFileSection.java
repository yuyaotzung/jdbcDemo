/*
 * ===========================================================================
 * IBM Confidential
 * AIS Source Materials
 *
 *
 * (C) Copyright IBM Corp. 2011.
 *
 * ===========================================================================
 */
package com.cosmos.file.ext;

/**
 * <p>
 * FISC核印電子檔檔案規格-明細
 * </p>
 * 
 * @author shawn
 * @version 1.0, 2013/9/26
 * @see
 * @since
 */
public enum Fisc02TxFileSection implements IFiscAuthFileDefinition {

	/** 欄位代號(類型, 是否必填 ,長度, 資料庫欄位, 欄位名稱(說明)) */
	SECNO(1, 0, 1, "SECNO", "2明細錄"),
	DATASRC(1, 0, 1, "DATASRC", "資料來源"),
	FILEBATCHNO(1, 0, 8, "FILEBATCHNO", "檔案批號"),
	AGENTBANKID(1, 0, 3, "AGENTBANKID", "帳務代理銀行 -總行代號"),
	AGENTBRANCHID(1, 0, 4, "AGENTBRANCHID", "帳務代理銀行 -分行代號"),
	PUNIT(1, 0, 8, "PUNIT", "委託單位代號"),
	AGENTUNIT(1, 0, 8, "AGENTUNIT", "編碼單位（備註 1）"),
	AGENTYEAR(1, 0, 3, "AGENTYEAR", "編碼年度（備註 1）"),
	TXNO(1, 0, 7, "TXNO", "交易序號（備註 1）"),
	PAYMENTTYPE(1, 0, 5, "PAYMENTTYPE", "費用類別"),
	AUTHBANKID(1, 0, 3, "AUTHBANKID", "核印行 -總行代號"),
	AUTHBRANCHID(1, 0, 4, "AUTHBRANCHID", "核印行 -分行代號"),
	ACCOUNTNO(1, 0, 16, "ACCOUNTNO", "帳號"),
	UID(1, 0, 10, "UID", "帳戶 ID (身份證統一 編號 )"),
	REQDATE(1, 0, 7, "REQDATE", "委託單位提出日期"),
	RSPDATE(1, 0, 7, "RSPDATE", "核印行 回應日期（備 回應日期（備註 2）"),
	STATUSCODE(1, 0, 2, "STATUSCODE", "回覆訊息(備註2)"),
	TXTYPE(1, 0, 1, "TXTYPE", "交易類別"),
	AUTHAMT(1, 0, 3, "AUTHAMT", "核印費"),
	MEMO(1, 0, 10, "MEMO", "Memo"),
	FILLER(1, 0, 39, "FILLER", "保留欄位");

	/** 資料類型 */
	private int type;

	/** 是否必填 */
	private int required;

	/** 檔案格式長度 */
	private int length;

	/** 資料庫存放欄位 */
	private String columnName;

	/** 欄位名稱 說明 */
	private String name;

	/**
	 * Constructor
	 * 
	 * @param code
	 * @param memo
	 */
	Fisc02TxFileSection(int type, int required, int length, String columnName, String name) {
		this.type = type;
		this.length = length;
		this.required = required;
		this.columnName = columnName;
		this.name = name;
	}

	/**
	 * 取得id
	 * 
	 * @return
	 */
	@Override
	public String getId() {
		return name();
	}

	/**
	 * 取得 type
	 * 
	 * @return 傳回 type
	 */
	@Override
	public int getType() {
		return type;
	}

	/**
	 * 取得 length
	 * 
	 * @return 傳回 length
	 */
	@Override
	public int getLength() {
		return length;
	}

	/**
	 * 取得 name
	 * 
	 * @return 傳回 name
	 */
	@Override
	public String getName() {
		return name;
	}

	/**
	 * 取得 length
	 * 
	 * @return 傳回 length
	 */
	public int getRequired() {
		return required;
	}

}
