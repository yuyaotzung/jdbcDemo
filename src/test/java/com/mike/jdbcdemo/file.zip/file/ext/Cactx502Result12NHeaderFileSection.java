/*
 * ===========================================================================
 * IBM Confidential
 * AIS Source Materials
 * 
 * 
 * (C) Copyright IBM Corp. 2018.
 *
 * ===========================================================================
 */
package com.cosmos.file.ext;

import com.cosmos.file.bo.FileField;
import com.cosmos.file.bo.FileSection;
import com.cosmos.file.def.Cactx502Result12NHeaderFileDefinition;
import com.cosmos.file.def.IFileDefinition;
import com.cosmos.type.FieldGroup;
import com.ibm.tw.commons.util.StringUtils;

/**
 * <p>
 * 外幣整批一扣多入 Header格式
 * </p>
 * 
 * @author monica
 * @version 1.0, Jul 10, 2018
 * @see
 * @since
 */
public class Cactx502Result12NHeaderFileSection {

	/** 檔案區段 */
	private FileSection fileSection;

	public Cactx502Result12NHeaderFileSection() {
		fileSection = new FileSection();
		fileSection.setFieldGroup(FieldGroup.HEADER);
		// 為了與畫面parse一致,讀入資料的secNo由1開始
		fileSection.setSectionNo(1);
	}

	public Cactx502Result12NHeaderFileSection(FileSection fileSection) {
		this.fileSection = fileSection;
	}

	public FileSection getFileSection() {
		return fileSection;
	}

	// 交易使用的分行號碼
	public String getBranchNo() {
		return getValue(Cactx502Result12NHeaderFileDefinition.BRANCH_NO);
	}

	public void setBranchNo(String value) {
		setValue(Cactx502Result12NHeaderFileDefinition.BRANCH_NO, value);
	}

	// 交易使用的行員號碼
	public String getTellerNo() {
		return getValue(Cactx502Result12NHeaderFileDefinition.TELLER_NO);
	}

	public void setTellerNo(String value) {
		setValue(Cactx502Result12NHeaderFileDefinition.TELLER_NO, value);
	}

	// 交易使用的端末機號
	public String getTermNo() {
		return getValue(Cactx502Result12NHeaderFileDefinition.TERM_NO);
	}

	public void setTermNo(String value) {
		setValue(Cactx502Result12NHeaderFileDefinition.TERM_NO, value);
	}

	// 交易日期
	public String getTxDate() {
		return getValue(Cactx502Result12NHeaderFileDefinition.TX_DATE);
	}

	public void setTxDate(String value) {
		setValue(Cactx502Result12NHeaderFileDefinition.TX_DATE, value);
	}

	// 付款人帳號
	public String getPayAcct() {
		return getValue(Cactx502Result12NHeaderFileDefinition.PAY_ACCT);
	}

	public void setPayAcct(String value) {
		setValue(Cactx502Result12NHeaderFileDefinition.PAY_ACCT, value);
	}

	// 付款帳號幣別
	public String getPayAcctCurrcode() {
		return getValue(Cactx502Result12NHeaderFileDefinition.PAY_ACCT_CURRCODE);
	}

	public void setPayAcctCurrcode(String value) {
		setValue(Cactx502Result12NHeaderFileDefinition.PAY_ACCT_CURRCODE, value);
	}

	// 轉出匯率類型
	public String getRateType1() {
		return getValue(Cactx502Result12NHeaderFileDefinition.RateType1);
	}

	public void setRateType1(String value) {
		setValue(Cactx502Result12NHeaderFileDefinition.RateType1, value);
	}

	// 付款人戶名
	public String getPayName() {
		return getValue(Cactx502Result12NHeaderFileDefinition.PAY_NAME);
	}

	public void setPayName(String value) {
		setValue(Cactx502Result12NHeaderFileDefinition.PAY_NAME, value);
	}

	// 一扣結果系統代碼
	public String getPayerResultSysId() {
		return getValue(Cactx502Result12NHeaderFileDefinition.PAYER_RESULTSYSID);
	}

	public void setPayerResultSysId(String value) {
		setValue(Cactx502Result12NHeaderFileDefinition.PAYER_RESULTSYSID, value);
	}

	// 一扣結果
	public String getPayerResult() {
		return getValue(Cactx502Result12NHeaderFileDefinition.PAYER_RESULT);
	}

	public void setPayerResult(String value) {
		setValue(Cactx502Result12NHeaderFileDefinition.PAYER_RESULT, value);
	}
	
	// 付款人手續費帳號
	public String getChgAcno() {
		return getValue(Cactx502Result12NHeaderFileDefinition.CHG_ACNO);
	}

	public void setChgAcno(String value) {
		setValue(Cactx502Result12NHeaderFileDefinition.CHG_ACNO, value);
	}

	// 付款人手續費帳號幣別
	public String getChgCcy() {
		return getValue(Cactx502Result12NHeaderFileDefinition.CHGCCY);
	}

	public void setChgCcy(String value) {
		setValue(Cactx502Result12NHeaderFileDefinition.CHGCCY, value);
	}

	// ========================================================
	// 以下可共用

	/**
	 * 
	 * @param fileDefinition
	 * @return
	 */
	private String getValue(IFileDefinition fileDefinition) {
		FileField fileField = fileSection.getField(fileDefinition.getId());
		if (fileField == null) {
			return null;
		}
		else {
			return StringUtils.trim(fileField.getValue());
		}
	}

	/**
	 * 
	 * @param fileDefinition
	 * @param value
	 */
	private void setValue(IFileDefinition fileDefinition, String value) {

		if (fileSection == null) {
			fileSection = new FileSection();
		}

		FileField field = fileSection.getField(fileDefinition.getId());
		if (field == null) {
			field = new FileField();
			field.setFieldId(fileDefinition.getId());
			field.setValue(value);
			fileSection.addField(field);
		}
		else {
			field.setValue(value);
		}
	}

	// 以上可共用
	// ========================================================

}
