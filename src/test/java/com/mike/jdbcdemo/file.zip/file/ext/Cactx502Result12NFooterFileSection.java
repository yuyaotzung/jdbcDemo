/*
 * ===========================================================================
 * IBM Confidential
 * AIS Source Materials
 * 
 * 
 * (C) Copyright IBM Corp. 2018.
 *
 * ===========================================================================
 */
package com.cosmos.file.ext;

import com.cosmos.file.bo.FileField;
import com.cosmos.file.bo.FileSection;
import com.cosmos.file.def.Cactx502Result12NFooterFileDefinition;
import com.cosmos.file.def.IFileDefinition;
import com.cosmos.type.FieldGroup;
import com.ibm.tw.commons.util.StringUtils;



/**
 * <p> 外幣整批一扣多入 Footer格式</p>
 *
 * @author  monica
 * @version 1.0, Jul 10, 2018
 * @see	    
 * @since 
 */
public class Cactx502Result12NFooterFileSection {
	
	/** 檔案區段 */
	private FileSection fileSection;
	
	public Cactx502Result12NFooterFileSection() {
		fileSection = new FileSection();
		fileSection.setFieldGroup(FieldGroup.FOOTER);
		// 為了與畫面parse一致,讀入資料的secNo由1開始
		fileSection.setSectionNo(1);
	}

	public Cactx502Result12NFooterFileSection(FileSection fileSection) {
		this.fileSection = fileSection;
	}

	public FileSection getFileSection() {
		return fileSection;
	}
	
	//上傳總筆數
	public String getTotalCount() {
		return getValue(Cactx502Result12NFooterFileDefinition.TOTAL_COUNT);
	}
	
	public void setTotalCount(String value) {
		setValue(Cactx502Result12NFooterFileDefinition.TOTAL_COUNT, value);
	}
	
	//上傳總金額
	public String getTotalAmt() {
		return getValue(Cactx502Result12NFooterFileDefinition.TOTAL_AMT);
	}
	
	public void setTotalAmt(String value) {
		setValue(Cactx502Result12NFooterFileDefinition.TOTAL_AMT, value);
	}
	
	//========================================================
	// 以下可共用
	
	
	/**
	 * 
	 * @param fileDefinition
	 * @return
	 */
	private String getValue(IFileDefinition fileDefinition) {
		FileField fileField = fileSection.getField(fileDefinition.getId());
		if (fileField == null) {
			return null;
		}
		else {
			return StringUtils.trim(fileField.getValue());
		}
	}
	
	
	/**
	 * 
	 * @param fileDefinition
	 * @param value
	 */
	private void setValue(IFileDefinition fileDefinition, String value) {

		if (fileSection == null) {
			fileSection = new FileSection();
		}

		FileField field = fileSection.getField(fileDefinition.getId());
		if (field == null) {
			field = new FileField();
			field.setFieldId(fileDefinition.getId());
			field.setValue(value);
			fileSection.addField(field);
		}
		else {
			field.setValue(value);
		}
	}
	
	// 以上可共用
	//========================================================

}



 