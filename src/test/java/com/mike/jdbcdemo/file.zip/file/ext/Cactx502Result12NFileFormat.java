/*
 * ===========================================================================
 * IBM Confidential
 * AIS Source Materials
 * 
 * 
 * (C) Copyright IBM Corp. 2018.
 *
 * ===========================================================================
 */
package com.cosmos.file.ext;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.cosmos.code.CibErrorCode;
import com.cosmos.file.FileFormatDetail;
import com.cosmos.file.FileFormatNew;
import com.cosmos.file.bo.FileDetail;
import com.cosmos.file.bo.FileDoc;
import com.cosmos.file.bo.FileSection;
import com.cosmos.file.def.Cactx502Result12NFooterFileDefinition;
import com.cosmos.file.def.Cactx502Result12NHeaderFileDefinition;
import com.cosmos.file.def.Cactx502Result12NTxFileDefinition;
import com.cosmos.file.def.IFileDefinition;
import com.cosmos.persistence.b2c.entity.FileFormatDetailEntity;
import com.cosmos.persistence.b2c.entity.FileFormatFieldEntity;
import com.cosmos.tx.FxDetailDoc;
import com.cosmos.type.FieldGroup;
import com.cosmos.type.TaskType;
import com.cosmos.type.TxBatchType;
import com.ibm.tw.commons.exception.ActionException;
import com.ibm.tw.commons.util.ConvertUtils;




/**
 * <p> 外幣整批一扣多入</p>
 *
 * @author  monica
 * @version 1.0, Jul 10, 2018
 * @see	    
 * @since 
 */
public class Cactx502Result12NFileFormat extends FileFormatNew{
	
	private final TaskType taskType = TaskType.FXB12N;
	
	/** 明細資料 */
	private List<FxDetailDoc> details = new ArrayList<FxDetailDoc>();
	
	public Cactx502Result12NFileFormat(String taskId){
		super(0, taskId, TxBatchType.UNKNOWN.getCode());
		detailGroup = loadDetailGroup();
	}
	
	/**
	 * 載入檔案定義
	 * 
	 * @return
	 */
	private Map<FieldGroup, List<FileFormatDetail>> loadDetailGroup() {
		Map<FieldGroup, List<FileFormatDetail>> detailGroup = new HashMap<FieldGroup, List<FileFormatDetail>>();

		// Header
		detailGroup.put(FieldGroup.HEADER, toFileFormatDetails(taskType, FieldGroup.HEADER, Cactx502Result12NHeaderFileDefinition.values()));

		// Tx
		detailGroup.put(FieldGroup.TX, toFileFormatDetails(taskType, FieldGroup.TX, Cactx502Result12NTxFileDefinition.values()));
		
		// Footer
		detailGroup.put(FieldGroup.FOOTER, toFileFormatDetails(taskType, FieldGroup.FOOTER, Cactx502Result12NFooterFileDefinition.values()));

		return detailGroup;
	}
	
	/**
	 * 加入首筆
	 * 
	 * @param detail
	 */
	public void addHeader(Cactx502Result12NHeaderFileSection detail) {
		FileDetail fileDetail = new FileDetail();
		fileDetail.addSection(detail.getFileSection());
		getFileDoc().getDetails().add(0, fileDetail); // 加入首筆
	}
	
	/**
	 * 加入明細
	 * 
	 * @param detail
	 */
	public void addDetails(Cactx502Result12NTxFileSection detail) {
		FileDetail fileDetail = new FileDetail();
		fileDetail.addSection(detail.getFileSection());
		getFileDoc().addDetail(fileDetail); // ?? 是否需要
	}
	
	/**
	 * 加入Footer
	 * 
	 * @param detail
	 */
	public void addFooter(Cactx502Result12NFooterFileSection detail) {
		FileDetail fileDetail = new FileDetail();
		fileDetail.addSection(detail.getFileSection());
		getFileDoc().addDetail(fileDetail);
	}
	
	
	/**
	 * 轉換為FileFormatDetail
	 * 
	 * @param taskType
	 * @param fieldGroup
	 * @param sections
	 * @return
	 */
	private List<FileFormatDetail> toFileFormatDetails(TaskType taskType, FieldGroup fieldGroup, IFileDefinition[] sections) {
		List<FileFormatDetail> fileFormatDetails = new ArrayList<FileFormatDetail>();

		int orderNo = 1;
		// 對應DB讀取資料,需由1開始
		int startPosition = 1;
		for (IFileDefinition section : sections) {
			FileFormatDetail fileFormatDetail = toFileFormatDetail(taskType, fieldGroup, section.getId(), section.getName(), orderNo++, section.getType(), section.getRequired(), section.getLength(), startPosition);
			fileFormatDetails.add(fileFormatDetail);
			startPosition += section.getLength();
		}

		return fileFormatDetails;
	}
	
	/**
	 * 轉換為FileFormatDetail
	 * 
	 * @param taskType
	 * @param fieldGroup
	 * @param fieldId
	 * @param fieldName
	 * @param orderNo
	 * @param type
	 * @param length
	 * @param startPosition
	 * @return
	 */
	private FileFormatDetail toFileFormatDetail(TaskType taskType, FieldGroup fieldGroup, String fieldId, String fieldName, int orderNo, int type, int required, int length, int startPosition) {
		// detail
		FileFormatDetailEntity detail = new FileFormatDetailEntity();
		detail.setFieldId(fieldId);
		detail.setFieldName(fieldName);
		detail.setOrderNo(orderNo);
		detail.setLength(length);
		detail.setStartPosition(startPosition);
		detail.setEndPosition(startPosition + detail.getLength() - 1);

		// field
		FileFormatFieldEntity field = new FileFormatFieldEntity();
		field.setFieldGroup(fieldGroup.getCode());
		field.setFieldId(fieldId);
		field.setTaskType(taskType.getCode());
		field.setType(type);
		field.setDefaultLength(length);
		field.setRequired(required);

		FileFormatDetail fileFormatDetail = new FileFormatDetail(taskType, detail, field);
		return fileFormatDetail;
	} 
	

	@Override
	public FieldGroup getFormatCycle(int rowNo) {
		// TODO 自動產生方法 Stub
		return null;
	}

	@Override
	public FieldGroup getFormatHead(int rowNo) {
		if (rowNo == 1) {
			return FieldGroup.HEADER;
		}
		else if (rowNo == getRows()) {
			return FieldGroup.FOOTER;
		}
		else {
			return FieldGroup.TX;
		}
	}

	@Override
	public TaskType getTaskType() {
		return taskType;
	}

	@Override
	protected void putData(FileDoc fileDoc) {
		// 將檔案資料轉為整批一扣多入明細資料 ,i為行號
		// 第一行為header,所以由i=2開始
		for (int i = 2; i <= fileDoc.rows(); i++) {
			if(i != fileDoc.rows()){//最後一行為footer
				FxDetailDoc detail = new FxDetailDoc();
				putDetail(detail, fileDoc.getDetail(i), i);
				details.add(detail);
			}
			
		}	
	}
	
	protected void putDetail(FxDetailDoc FxDetailDoc, FileDetail fileDetail, int i) {
		putDocDetail(FxDetailDoc, fileDetail.getFirstSection(), i);
	}
	
	protected void putDocDetail(FxDetailDoc detail, FileSection section, int row) {
		Cactx502Result12NTxFileSection fileSection = new Cactx502Result12NTxFileSection(section);
		
		// 批號
		detail.setLastPmtId(fileSection.getPbmtBatchNo());
		// 流水號
		detail.setTxNo(Integer.valueOf(fileSection.getPbmtSerno()));
		// 付款通路
		detail.setPayerKind(Integer.valueOf(fileSection.getPayChanel()));
		// TODO 收款銀行代號
		//detail.setPayeeBankId(fileSection.getReceiveBankCode());
		// 轉入帳號
		detail.setPayeeAccountNo(fileSection.getRollInAcct());
		// 轉入帳號幣別
		detail.setPayeeCcy(fileSection.getRollInAcctCurrcode());
		// 交易金額
		detail.setTxAmt(ConvertUtils.str2BigDecimal(fileSection.getAmount(), 0));
	
//		PROMO_CODE(1, 0, 2, "", "提示碼"),
//		REMARKS(1, 0, 16, "", "存摺附註"),
//		CHECK_ID(1, 0, 10, "", "檢核ID"),
//		CHECK_NAME(1, 0, 60, "", "檢核戶名"),
//		FEE(1, 0, 5, "", "櫃員手續費/匯款手續費"),
		
//		CBRClass1(1, 0, 3, "", "匯款分類一1"),
//		sourceOfFundSub(1, 0, 1, "", "匯款分類細項"),
//		CBRSubCode1(1, 0, 1, "", "匯款分類69x細分類1"),
//		CBRREQ1(1, 0, 1, "", "申報註記1"),
//		CBRTxnType1(1, 0, 1, "", "交易類型1"),
//		CBRCountry2(1, 0, 2, "", "匯款地國別2"),
//		CBRREQ2(1, 0, 1, "", "申報註記2"),
//		POST_SCRIPT(1, 0, 76, "", "附言"),
//		BANCS_STAT(1, 0, 4, "", "BaNCS中心執行結果BANCS-STAT"),
//		FRN56U_STAT(1, 0, 4, "", "匯款處理結果(他行)"),
//		ForexTradingNo(1, 0, 12, "", "外匯交易編號"),
//		JRNL_NO(1, 0, 9, "", "交易序號"),
		//受款銀行名稱
		detail.setPayeeBankName1(fileSection.getPayeeBankName());
		//受款銀行地址
		detail.setPayeeBankAddr1(fileSection.getPayeeBankAddr());
	    //手續費扣款幣金額
		detail.setCommission(ConvertUtils.str2BigDecimal(fileSection.getCommission(), 0));
		//手續費本位幣金額
		detail.setCommissionBcu(ConvertUtils.str2BigDecimal(fileSection.getCommissionBcu(), 0));
		//郵電費扣款幣金額
		detail.setPostage(ConvertUtils.str2BigDecimal(fileSection.getPostage(), 0));
		//郵電費本位幣金額
		detail.setPostageBcu(ConvertUtils.str2BigDecimal(fileSection.getPostageBcu(), 0));
		//費用總金額
		detail.setTotChg(ConvertUtils.str2BigDecimal(fileSection.getTotChg(), 0));
		//總扣款金額
		detail.setTotalAmt(ConvertUtils.str2BigDecimal(fileSection.getTotPayAmt(), 0));
		//等值美金金額
		detail.setEquUsdAmt(ConvertUtils.str2BigDecimal(fileSection.getEquUsdAmt(), 0));
		//等值台幣金額
		detail.setEquTwdAmt(ConvertUtils.str2BigDecimal(fileSection.getEquTwdAmt(), 0));
		//收款人Email
		detail.setPayeeEmail(fileSection.getPayeeEmail());
		//受款人地址
		detail.setPayeeAddr1(fileSection.getPayeeAddr());
		//受款人電話
		detail.setPayeePhone(fileSection.getPayeeTel());
		//大陸現代化支付系統帳號
		detail.setCnaps(fileSection.getCnaps());
		//附言
		detail.setPaymentdetails1(fileSection.getPaymentDetails());
//	TODO	cbTradeType(1, 0, 1, "", "外匯性質"),
		//受款人身份別
		detail.setSelfFlag(fileSection.getOppoKind());
		//受款銀行SWIFT 
		detail.setPayeeSwiftCode(fileSection.getPayeeBankSwift());				 
//	TODO	payeeBankAcno(1, 0, 34, "", "受款銀行清算代碼,與CNAPS只能其中一個有值。"),
		//中間銀行SWIFT
		detail.setMiddleSwiftCode(fileSection.getIntrBankSwift());
		//內扣外繳,Y：內扣。非Y：外繳 
//	TODO	deductFeeFlag(1, 0, 1, "", "內扣外繳,Y：內扣。非Y：外繳"),
//	TODO	applicationId(1, 0, 4, "", "發動端平台代號"),//CB:企網銀
		//客戶英文名稱
		detail.setPayerEngName(fileSection.getCustName());
		//客戶英文地址
		detail.setPayerEngAddress(fileSection.getCustAddr());
		 
//	TODO	txntType(1, 0, 1, "", "交易類型"),//1.	即時自行匯款,2.	即時跨行匯款,3.	預約自行匯款,4.	預約跨行匯款,5.	整批自行匯款
//	TODO	bsnUnit(1, 0, 4, "", "客戶所屬分行別"),
//	TODO	validDate(1, 0, 8, "", "交易生效日"),
		
		//匯款幣別
		detail.setTxAmtCcy(fileSection.getRemitCcy());
		//付款幣別
		detail.setPayerCcy(fileSection.getPayCcy());
		//議價編號
		detail.setExCntrNo(fileSection.getExCntrno());
		//成交匯率
		detail.setExRate(ConvertUtils.str2BigDecimal(fileSection.getExrate(), 0));
		
//	TODO	spreadBSpot(1, 0, 13, "", "買匯匯率優惠"),//9(05).9(07)
//	TODO	spreadSSpot(1, 0, 13, "", "賣匯匯率優惠"),//9(05).9(07)
		//匯款分類
		detail.setSourceOfFund(fileSection.getSourceOfFund());
		//匯出匯款方式 Y: 需全額到行,I: 間接匯款,R: 國內匯款RTGS
		detail.setFullPayment(fileSection.getFullPayment());
		
//	TODO	custTel(1, 0, 14, "", "客戶聯絡電話"),
//	TODO	custBirthday(1, 0, 8, "", "客戶生日"),
//	TODO	custKindCbMemo(1, 0, 2, "", "客戶身份別"),
//	TODO	rsdntIssueDate(1, 0, 8, "", "居留證核發日期"),
//	TODO	rsdntValidDate(1, 0, 8, "", "居留證有效期限");
	}
	
	/**
	 * DATA TO FILE
	 * @return
	 * @throws ActionException
	 */
	public byte[] toFile() throws ActionException {

		byte[] dataBuff = new byte[0];

		// 取得首筆
		FileDetail header = getFileDoc().getDetails().get(0);
		FileDetail footer = fetchFooter();
		try {

			// 首筆
			if (header != null) {
				dataBuff = detailStringData(header);
			}

			// 明細
			for (FileDetail detail : fileDoc.getDetails()) {
				if(detail.getFirstSection().getFieldGroup().compareTo(FieldGroup.HEADER) == 0 || 
						detail.getFirstSection().getFieldGroup().compareTo(FieldGroup.FOOTER) == 0) {
					// 如果是header或footer則略過
					continue;
				}
				
				if (dataBuff.length > 0) {
					dataBuff = concat(dataBuff, getLineSeparator().getBytes(ENCODING));
				}
				
				dataBuff = concat(dataBuff, detailStringData(detail));
			}
			
			// 尾筆
			if (footer != null) {

				// dataBuff = detailStringData(footer);

				if (dataBuff.length > 0)
					dataBuff = concat(dataBuff, getLineSeparator().getBytes(ENCODING));
				dataBuff = concat(dataBuff, detailStringData(footer));
			}
			
			return dataBuff;
		}
		catch (UnsupportedEncodingException e) {

			ActionException ex = getActionException(CibErrorCode.VALIDATE_SIZE_ERROR);

			throw ex;
		}
	}
	
	/**
	 * 取得尾筆
	 * 
	 * @return
	 */
	private FileDetail fetchFooter() {

//		if (fileDoc == null) {
//
//			System.err.println("===fileDoc is null=========");
//
//		}
//		else {
//
//			System.err.println("===fileDoc is not null=========");
//		}
//
//		if (fileDoc.getDetails() == null) {
//
//			System.err.println("===fileDoc.getDetails() is null=========");
//
//		}
//		else {
//
//			System.err.println("===fileDoc.getDetails() is not null=========");
//		}

		for (FileDetail detail : fileDoc.getDetails()) {
			if (detail.isFooter()) {
				return detail;
			}
		}
		return null;
	}

	@Override
	protected void validateCustom(FileDoc fileDoc) throws ActionException {
		// TODO 自動產生方法 Stub
		
	}

	@Override
	protected void validateDetailContent(FileDetail fileDetail) throws ActionException {
		// TODO 自動產生方法 Stub
		
	}

	@Override
	protected void validateDetailSize(FileDoc fileDoc) throws ActionException {
		// TODO 自動產生方法 Stub
		
	}

}



 