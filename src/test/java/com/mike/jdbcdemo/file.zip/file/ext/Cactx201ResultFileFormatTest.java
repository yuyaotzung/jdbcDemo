/*
 * ===========================================================================
 * IBM Confidential
 * AIS Source Materials
 * 
 * 
 * (C) Copyright IBM Corp. 2018.
 *
 * ===========================================================================
 */
package com.cosmos.file.ext;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.util.Date;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;

import org.apache.commons.io.FileUtils;

import com.cosmos.file.bo.FileDetail;
import com.cosmos.file.bo.FileDoc;
import com.cosmos.file.bo.FileSection;
import com.cosmos.param.ISystemParam;
import com.cosmos.param.ext.CibParam;
import com.cosmos.persistence.CosmosDaoFactory;
import com.cosmos.persistence.b2c.dao.B2CSequenceDao;
import com.cosmos.persistence.b2c.dao.IB2CSequenceDao;
import com.cosmos.persistence.b2c.dao.ISystemParamDao;
import com.cosmos.persistence.b2c.entity.SystemParamEntity;
import com.cosmos.persistence.b2c.entity.pk.SystemParamEntityPk;
import com.cosmos.type.FieldGroup;
import com.cosmos.util.SFTPUtils;
import com.ibm.tw.commons.aop.AOPProxyFactory;
import com.ibm.tw.commons.exception.ActionException;
import com.ibm.tw.commons.exception.CryptException;
import com.ibm.tw.commons.persistence.exception.DatabaseException;
import com.ibm.tw.commons.util.ConvertUtils;
import com.ibm.tw.commons.util.DESUtils;
import com.ibm.tw.commons.util.StringUtils;
import com.ibm.tw.commons.util.time.DateUtils;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.SftpException;

/**
 * <p>
 * TODO description
 * </p>
 * 
 * @author Bear
 * @version 1.0, 2018/4/26
 * @see
 * @since
 */
public class Cactx201ResultFileFormatTest {

	// 企網薪資資料夾
	private static final String WORDKING_DIR = "0001";

	// Server
	static String server;

	// Port
	static int port;

	// 帳號
	static String user_put;

	// 密碼
	static String password_put;

	// 帳號
	static String user_get;

	// 密碼
	static String password_get;

	public static void main(String[] args) throws ActionException, IOException, JSchException, SftpException, DatabaseException {

		init();

		testExportFile();

		// String fileName = "00010096008052018000000000001805080042975.txt";
		// testImportFile(fileName);

	}

	private static void init() {
		// Server
		server = getSystemParamValue(CibParam.FCS_SFTP_SERVER);
		// Port
		port = ConvertUtils.str2Int(getSystemParamValue(CibParam.FCS_SFTP_PORT));
		// 帳號
		user_put = getSystemParamValue(CibParam.FCS_SFTP_USER_PUT);
		// 密碼
		password_put = getSystemParamValue(CibParam.FCS_SFTP_PASSWORD_PUT);
		// 帳號
		user_get = getSystemParamValue(CibParam.FCS_SFTP_USER_GET);
		// 密碼
		password_get = getSystemParamValue(CibParam.FCS_SFTP_PASSWORD_GET);

	}

	private static void testExportFile() throws JSchException, SftpException, IOException, DatabaseException, ActionException {
		Cactx201ResultFileFormat fileFormat = new Cactx201ResultFileFormat("CACTX201");

		// 案件序號
		String flowDocId = generateCaseNo();

		// 交易日期
		Date txDate = new Date();

		prepareHeaders(fileFormat, txDate);
		prepareDetails(fileFormat, flowDocId);
		prepareFooters(fileFormat);
		byte[] data = new byte[0];

		data = fileFormat.toFile();

		String fileName = getFileName(txDate, flowDocId);

		System.out.println("fileName:" + fileName);

		// 備份檔案
		FileUtils.writeByteArrayToFile(new File("C:/ACHBACKUP/" + fileName + ".TXT"), data);

		ChannelSftp sftp = null;

		boolean result = false;
		ByteArrayInputStream is = new ByteArrayInputStream(data);

		try {
			sftp = SFTPUtils.connect(server, port, user_put, password_put, WORDKING_DIR);

			sftp.put(is, fileName + ".tmp");

			result = true;
			System.out.println("是否上傳成功 =" + result);
			is.close();

			if (!result) {
				System.err.println("上傳失敗");
			}

			try {
				if (result) {
					sftp.rename(fileName + ".tmp", fileName + ".TXT");
				}
			}
			catch (SftpException e) {
				e.printStackTrace();
				System.err.println("rename失敗, fileName:" + fileName);

			}

		}
		catch (JSchException e) {
			System.err.println("SFTP連線失敗");
			e.printStackTrace();
			throw e;
		}
		catch (SftpException e) {
			e.printStackTrace();
			throw e;
		}
		catch (IOException e) {
			e.printStackTrace();
			throw e;
		}
		finally {
			try {
				is.close();
				SFTPUtils.disconnect(sftp);
			}
			catch (JSchException e) {
				System.err.println("SFTP離線失敗");
				e.printStackTrace();
			}
			catch (IOException e) {
				System.err.println("ByteArrayInputStream close failed , fileName:" + fileName);
				e.printStackTrace();
			}
		}
	}

	private static void prepareHeaders(Cactx201ResultFileFormat fileFormat, Date txDate) {

		Cactx201ResultHeaderFileSection section = new Cactx201ResultHeaderFileSection();
		// 主辦行
		section.setBranchNo(StringUtils.leftPad("00660", 5, "0"));
		// 交易使用的行員號碼
		section.setTellerNo(StringUtils.leftPad("90002535", 8, "0"));
		// 交易使用的端末機號
		section.setTermNo(StringUtils.leftPad("999", 3, "0"));
		// 交易日期
		section.setTxDate(DateUtils.formatDate(txDate, "ddMMyyyy"));
		// 發薪單位統編
		section.setPayCompanyId(StringUtils.rightPad("23111915", 10, " "));
		// 付款人帳號
		section.setPayAcct(StringUtils.leftPad("60090100000109", 14, "0"));
		// 付款人戶名
		section.setPayName(StringUtils.rightPad("凱基證券", 76, " "));
		// 清算帳號
		section.setBglAcct(StringUtils.leftPad("9043000182514003", 16, "0"));
		// 發薪單位委託單位代號
		section.setPayrolCode(StringUtils.leftPad("11191", 5, "0"));
		// 存摺附註
		section.setRemarks(StringUtils.rightPad("", 16, " "));
		// 付款人統編
		section.setPayerUid(StringUtils.rightPad("23111915", 10, " "));

		section.setPayerResultSysId(StringUtils.rightPad("", 6, " "));// 
		section.setPayerResult(StringUtils.rightPad("", 8, " "));// 

		// 為了與畫面parse一致,讀入資料的secNo由1開始
		section.getFileSection().setSectionNo(1);

		fileFormat.addHeader(section);

	}

	private static void prepareDetails(Cactx201ResultFileFormat fileFormat, String flowDocId) {

		// 第一筆
		Cactx201ResultTxFileSection section = new Cactx201ResultTxFileSection();
		section.setBatchNo(StringUtils.leftPad(flowDocId, 24, "0"));// 批號
		section.setSerno(StringUtils.leftPad("00001", 5, "0"));// 流水號
		section.setPayChanel(StringUtils.rightPad("1", 1, " "));// 付款通路
		section.setReceiveBankCode(StringUtils.leftPad("8090000", 7, "0"));// 收款銀行代號
		section.setPayeeAcctNo(StringUtils.leftPad("60090400001293", 14, "0"));// 入薪員工入帳帳號
		section.setPayeeUid(StringUtils.leftPad("A107399403", 10, " "));// 入薪員工身分證號
		section.setPayeeName(StringUtils.rightPad("", 20, " "));// 入薪員工戶名
		// section.setTxnAmt(StringUtils.leftPad("3000000", 11, "0"));//
		// 入帳金額30000.00
		section.setTxnAmt(StringUtils.leftPad("3000", 11, "0"));// 入帳金額30.00

		// ?? TODO
		section.setFee(StringUtils.leftPad("000", 5, "0"));// 櫃員手續費/匯款手續費

		section.setPostScript(StringUtils.rightPad("TEST", 76, " "));// 附言
		section.setRetCode(StringUtils.rightPad(" ", 4, " "));// 薪資入帳回覆代碼
		section.setFepResult(StringUtils.rightPad(" ", 4, " "));// 匯款處理結果
		section.setFepNo(StringUtils.rightPad(" ", 7, " "));// 匯款編號
		section.setJrnlNo(StringUtils.leftPad("000000000", 9, "0"));// 交易序號
		// 為了與畫面parse一致,讀入資料的secNo由1開始
		section.getFileSection().setSectionNo(1);

		fileFormat.addDetails(section);

		// 第二筆
		Cactx201ResultTxFileSection section2 = new Cactx201ResultTxFileSection();
		section2.setBatchNo(StringUtils.leftPad(flowDocId, 24, "0"));// 批號
		section2.setSerno(StringUtils.leftPad("00002", 5, "0"));// 流水號
		section2.setPayChanel(StringUtils.rightPad("2", 1, " "));// 付款通路
		section2.setReceiveBankCode(StringUtils.leftPad("0210000", 7, "0"));// 收款銀行代號
		section2.setPayeeAcctNo(StringUtils.leftPad("00123456789012", 14, "0"));// 入薪員工入帳帳號
		section2.setPayeeUid(StringUtils.leftPad("H147815527", 10, " "));// 入薪員工身分證號
		section2.setPayeeName(StringUtils.rightPad("謝美美", 20, " "));// 入薪員工戶名
		section2.setTxnAmt(StringUtils.leftPad("4000000", 11, "0"));// 入帳金額40000.00
		// ?? TODO
		section2.setFee(StringUtils.leftPad("000", 5, "0"));// 櫃員手續費/匯款手續費

		section2.setPostScript(StringUtils.rightPad("TEST2", 76, " "));// 附言
		section2.setRetCode(StringUtils.rightPad(" ", 4, " "));// 薪資入帳回覆代碼
		section2.setFepResult(StringUtils.rightPad(" ", 4, " "));// 匯款處理結果
		section2.setFepNo(StringUtils.rightPad(" ", 7, " "));// 匯款編號
		section2.setJrnlNo(StringUtils.leftPad("000000000", 9, "0"));// 交易序號
		// 為了與畫面parse一致,讀入資料的secNo由1開始
		section2.getFileSection().setSectionNo(1);

		fileFormat.addDetails(section2);

		// // 第三筆
		// Cactx201ResultTxFileSection section3 = new
		// Cactx201ResultTxFileSection();
		// section3.setBatchNo(StringUtils.leftPad(flowDocId,24,"0"));//批號
		// section3.setSerno(StringUtils.leftPad("00003",5,"0"));//流水號
		// section3.setPayChanel(StringUtils.rightPad("1",1," "));//付款通路
		// section3.setReceiveBankCode(StringUtils.leftPad("8090000",7,"0"));//收款銀行代號
		// section3.setPayeeAcctNo(StringUtils.leftPad("60010100001816",16,"0"));//入薪員工入帳帳號
		// section3.setPayeeUid(StringUtils.leftPad("N190927854",10," "));//入薪員工身分證號
		// section3.setPayeeName(StringUtils.rightPad("何小米",20," "));//入薪員工戶名
		// section3.setTxnAmt(StringUtils.leftPad("5000000",11,"0"));//入帳金額50000.00
		// ?? TODO
		// section3.setFee(StringUtils.leftPad("000",5,"0"));//櫃員手續費/匯款手續費
		//		
		// section3.setPostScript(StringUtils.rightPad("TEST3",76," "));//附言
		// section3.setRetCode(StringUtils.rightPad(" ",1," "));//薪資入帳回覆代碼
		// section3.setFepResult(StringUtils.rightPad(" ",4," "));//匯款處理結果
		// section3.setFepNo(StringUtils.rightPad(" ",7," "));//匯款編號
		// section3.setJrnlNo(StringUtils.leftPad("000000000",9,"0"));//交易序號
		// // 為了與畫面parse一致,讀入資料的secNo由1開始
		// section3.getFileSection().setSectionNo(1);
		//		
		// fileFormat.addDetails(section3);
		//		
		// // 第四筆
		// Cactx201ResultTxFileSection section4 = new
		// Cactx201ResultTxFileSection();
		// section4.setBatchNo(StringUtils.leftPad(flowDocId,24,"0"));//批號
		// section4.setSerno(StringUtils.leftPad("00004",5,"0"));//流水號
		// section4.setPayChanel(StringUtils.rightPad("1",1," "));//付款通路
		// section4.setReceiveBankCode(StringUtils.leftPad("8090000",7,"0"));//收款銀行代號
		// section4.setPayeeAcctNo(StringUtils.leftPad("60010100001007",16,"0"));//入薪員工入帳帳號
		// section4.setPayeeUid(StringUtils.leftPad("S106837972",10," "));//入薪員工身分證號
		// section4.setPayeeName(StringUtils.rightPad("王順一",20," "));//入薪員工戶名
		// section4.setTxnAmt(StringUtils.leftPad("6000000",11,"0"));//入帳金額60000.00
		// ?? TODO
		// section4.setFee(StringUtils.leftPad("000",5,"0"));//櫃員手續費/匯款手續費
		//		
		// section4.setPostScript(StringUtils.rightPad("TEST4",76," "));//附言
		// section4.setRetCode(StringUtils.rightPad(" ",1," "));//薪資入帳回覆代碼
		// section4.setFepResult(StringUtils.rightPad(" ",4," "));//匯款處理結果
		// section4.setFepNo(StringUtils.rightPad(" ",7," "));//匯款編號
		// section4.setJrnlNo(StringUtils.leftPad("000000000",9,"0"));//交易序號
		// // 為了與畫面parse一致,讀入資料的secNo由1開始
		// section4.getFileSection().setSectionNo(1);
		//		
		// fileFormat.addDetails(section4);
		//		
		//		
		// // 第五筆
		// Cactx201ResultTxFileSection section5 = new
		// Cactx201ResultTxFileSection();
		// section5.setBatchNo(StringUtils.leftPad(flowDocId,24,"0"));//批號
		// section5.setSerno(StringUtils.leftPad("00005",5,"0"));//流水號
		// section5.setPayChanel(StringUtils.rightPad("1",1," "));//付款通路
		// section5.setReceiveBankCode(StringUtils.leftPad("8090000",7,"0"));//收款銀行代號
		// section5.setPayeeAcctNo(StringUtils.leftPad("60010100001832",16,"0"));//入薪員工入帳帳號
		// section5.setPayeeUid(StringUtils.leftPad("S120503213",10," "));//入薪員工身分證號
		// section5.setPayeeName(StringUtils.rightPad("王順二",20," "));//入薪員工戶名
		// section5.setTxnAmt(StringUtils.leftPad("7000000",11,"0"));//入帳金額70000.00
		// ?? TODO
		// section5.setFee(StringUtils.leftPad("000",5,"0"));//櫃員手續費/匯款手續費
		//		
		// section5.setPostScript(StringUtils.rightPad("TEST5",76," "));//附言
		// section5.setRetCode(StringUtils.rightPad(" ",1," "));//薪資入帳回覆代碼
		// section5.setFepResult(StringUtils.rightPad(" ",4," "));//匯款處理結果
		// section5.setFepNo(StringUtils.rightPad(" ",7," "));//匯款編號
		// section5.setJrnlNo(StringUtils.leftPad("000000000",9,"0"));//交易序號
		// // 為了與畫面parse一致,讀入資料的secNo由1開始
		// section5.getFileSection().setSectionNo(1);
		//		
		// fileFormat.addDetails(section5);
		//		

	}

	private static void prepareFooters(Cactx201ResultFileFormat fileFormat) {
		Cactx201ResultFooterFileSection section = new Cactx201ResultFooterFileSection();
		// section.setTotalAmt(StringUtils.leftPad("7000000", 17, "0"));
		section.setTotalAmt(StringUtils.leftPad("3000", 17, "0"));
		// section.setTotalCount(StringUtils.leftPad("2", 6, "0"));
		section.setTotalCount(StringUtils.leftPad("1", 6, "0"));
		section.getFileSection().setSectionNo(1);
		fileFormat.addFooter(section);
	}

	private static void testImportFile(String fileName) throws JSchException, SftpException, IOException, ActionException {

		// byte[] fileContent = FileUtils.readFileToByteArray(new
		// File("C:/ACHBACKUP/cactx201_results.txt"));

		byte[] fileContent = null;
		ChannelSftp sftp = null;
		ByteArrayOutputStream os = new ByteArrayOutputStream();
		try {
			sftp = SFTPUtils.connect(server, port, user_get, password_get, "/");

			sftp.get(fileName, os);

			fileContent = os.toByteArray();

			if (fileContent == null) {
				System.err.println("sftp download file Error, fileName:" + fileName);
			}

		}
		catch (JSchException e) {
			System.err.println("SFTP連線失敗");
			e.printStackTrace();
			throw e;
		}
		catch (SftpException e) {
			e.printStackTrace();
			throw e;
		}
		finally {
			try {
				os.close();
				SFTPUtils.disconnect(sftp);
			}
			catch (JSchException e) {
				System.err.println("SFTP離線失敗");
				e.printStackTrace();
			}
			catch (IOException e) {
				System.err.println("ByteArrayOutputStream close failed , fileName:" + fileName);
				e.printStackTrace();
			}
		}

		Cactx201ResultFileFormat fileFormat = new Cactx201ResultFileFormat("CACTX201");
		boolean result = fileFormat.parseFile(fileContent);

		System.out.println("result:" + result);

		FileDoc fileDoc = fileFormat.getFileDoc();

		for (FileDetail fileDetail : fileDoc.getDetails()) {
			System.out.println("=================== " + fileDetail.getRowNo() + " ====================");

			FileSection fileSection = fileDetail.getFirstSection();
			if (fileDetail.getFirstSection().getFieldGroup() == FieldGroup.HEADER) {
				Cactx201ResultHeaderFileSection header = new Cactx201ResultHeaderFileSection(fileSection);
				System.out.println("==========Header==========");
				System.out.println("HEADER getBranchNo:" + header.getBranchNo());
				System.out.println("HEADER getPayerAccountNo:" + header.getPayAcct());
				System.out.println("HEADER getPayerName:" + header.getPayName());
				System.out.println("HEADER getPayerUid:" + header.getPayerUid());

			}
			else if (fileDetail.getFirstSection().getFieldGroup() == FieldGroup.FOOTER) {
				Cactx201ResultFooterFileSection footer = new Cactx201ResultFooterFileSection(fileSection);
				System.out.println("==========Footer==========");
				System.out.println("getTotalCount:" + footer.getTotalCount());
				System.out.println("getTotalAmt:" + footer.getTotalAmt());

			}
			else {
				Cactx201ResultTxFileSection detail = new Cactx201ResultTxFileSection(fileSection);
				System.out.println("==========Tx==========");
				System.out.println("Tx getBatchNo:" + detail.getBatchNo());
				System.out.println("Tx getSerno:" + detail.getSerno());
				System.out.println("Tx getPayChanel:" + detail.getPayChanel());

				System.out.println("Tx getReceiveBankCode:" + detail.getReceiveBankCode());
				System.out.println("Tx getTxAmt:" + detail.getTxnAmt());
				System.out.println("Tx getRemarks:" + detail.getPostScript());
				System.out.println("BaNCS薪資入帳回覆代碼getRetCode:" + detail.getRetCode());
				System.out.println("匯款處理結果getFepResult:" + detail.getFepResult());
				System.out.println("匯款編號getFepNo:" + detail.getFepNo());
				System.out.println("交易序號getJournalNo:" + detail.getJrnlNo());
			}

		}

	}

	/*
	 * 來源檔檔案名稱：9999(流程識別碼)+99999(主辦分行代碼)+交易日期(西元年DDMMYYYY)+999999999999999999999999
	 * (批號).TXT
	 */
	private static String getFileName(Date txDate, String batchNo) {

		return WORDKING_DIR + "0960" + DateUtils.formatDate(txDate, "ddMMyyyy") + StringUtils.leftPad(batchNo, 24, "0");
	}

	public static String generateCaseNo() throws DatabaseException {
		String value = "";
		IB2CSequenceDao dao = (IB2CSequenceDao) AOPProxyFactory.getDao(IB2CSequenceDao.class, B2CSequenceDao.class);
		String caseNoSeq = StringUtils.leftPad(String.valueOf(dao.getCaseNoSeq() % 10000000), 7, "0");
		value = DateUtils.getSimpleISODateStr(new Date()).substring(2) + caseNoSeq;
		return value;
	}

	/** 系統參數代碼表 */
	private static Map<SystemParamEntityPk, String> systemParamMap = null;

	/**
	 * 載入系統參數
	 */
	synchronized private static void loadSystemParamMap() {

		if (systemParamMap != null) {
			return;
		}

		systemParamMap = new Hashtable<SystemParamEntityPk, String>();

		ISystemParamDao dao = CosmosDaoFactory.getSystemParamDao();

		try {

			// System.err.println("loadSystemParamMap");

			List<SystemParamEntity> entities = dao.findAll();

			for (SystemParamEntity entity : entities) {

				SystemParamEntityPk pk = new SystemParamEntityPk(entity.getCategory(), entity.getKey());

				String value = StringUtils.trimToEmpty(entity.getValue());

				// 加入密碼 DECRYPT 的功能
				if (1 == entity.getPasswordFlag()) {
					value = DESUtils.decrypt(value);
				}

				systemParamMap.put(pk, value);

			}
		}
		catch (DatabaseException e) {
			throw new RuntimeException("cannot load SystemParam ", e);
		}
		catch (CryptException e) {
			throw new RuntimeException("cannot load SystemParam ", e);
		}

	}

	public static Map<SystemParamEntityPk, String> getSystemParamMap() {

		if (null == systemParamMap) {
			loadSystemParamMap();
		}
		return systemParamMap;
	}

	/**
	 * 取得參數值
	 * 
	 * @param param
	 * @return
	 */
	public static String getSystemParamValue(ISystemParam param) {

		SystemParamEntityPk pk = new SystemParamEntityPk(param.getCategory().getCode(), param.getKey());

		return getSystemParamMap().get(pk);
	}
}
