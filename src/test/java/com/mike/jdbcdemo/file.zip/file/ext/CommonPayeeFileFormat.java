/*
 * ===========================================================================
 * IBM Confidential
 * AIS Source Materials
 * 
 * 
 * (C) Copyright IBM Corp. 2011.
 *
 * ===========================================================================
 */
package com.cosmos.file.ext;

import com.cosmos.file.FileFormatNew;
import com.cosmos.file.bo.FileDoc;
import com.cosmos.type.FieldGroup;
import com.cosmos.type.TaskType;
import com.cosmos.type.TxBatchType;
import com.ibm.tw.commons.exception.ActionException;
import com.ibm.tw.commons.persistence.exception.DatabaseException;

/**
 * <p>
 * 收款人檔案格式
 * </p>
 * 
 * @author Leo
 * @version 1.0, 2011/5/9
 * @see
 * @since
 */
public abstract class CommonPayeeFileFormat extends FileFormatNew {

	/** 整批類型 */
	public static TxBatchType TX_BATCH_TYPE = TxBatchType.UNKNOWN;

	/**
	 * Constructor
	 * 
	 * @param loginUser
	 */
	public CommonPayeeFileFormat(int companyKey, String taskId) {
		super(companyKey, taskId, TX_BATCH_TYPE.getCode());
	}

	/**
	 * Constructor
	 * 
	 * @param fileFormatKey
	 */
	public CommonPayeeFileFormat(String fileFormatKey) throws DatabaseException {
		super(fileFormatKey);
	}

	@Override
	public TaskType getTaskType() {
		return TaskType.PAYEE;
	}

	@Override
	public FieldGroup getFormatCycle(int rowNo) {
		return null;
	}

	@Override
	public FieldGroup getFormatHead(int rowNo) {

		// Excel 格式
		if (3 == master.getFieldDelimiterType()) {
			if (rowNo == 1) {
				return FieldGroup.COLUMNS;
			}
			else {
				return FieldGroup.COMMONPAYEE;
			}
		}
		// 非 Excel 格式
		else {
			return FieldGroup.COMMONPAYEE;
		}
	}

	@Override
	protected void validateDetailSize(FileDoc fileDoc) throws ActionException {

	}

	@Override
	protected void validateCustom(FileDoc fileDoc) throws ActionException {
	}
}
