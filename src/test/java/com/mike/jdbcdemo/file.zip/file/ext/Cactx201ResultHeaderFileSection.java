/*
 * ===========================================================================
 * IBM Confidential
 * AIS Source Materials
 * 
 * 
 * (C) Copyright IBM Corp. 2018.
 *
 * ===========================================================================
 */
package com.cosmos.file.ext;

import com.cosmos.file.bo.FileField;
import com.cosmos.file.bo.FileSection;
import com.cosmos.file.def.Cactx102Result12NHeaderFileDefinition;
import com.cosmos.file.def.Cactx201ResultHeaderFileDefinition;
import com.cosmos.file.def.IFileDefinition;
import com.cosmos.type.FieldGroup;
import com.ibm.tw.commons.util.StringUtils;

/**
 * <p>
 * 整批薪資入帳
 * </p>
 * 
 * @author Bear
 * @version 1.0, 2018/4/26
 * @see
 * @since
 */
public class Cactx201ResultHeaderFileSection {

	/** 檔案區段 */
	private FileSection fileSection;

	public Cactx201ResultHeaderFileSection() {
		fileSection = new FileSection();
		fileSection.setFieldGroup(FieldGroup.HEADER);
	}

	public Cactx201ResultHeaderFileSection(FileSection fileSection) {
		this.fileSection = fileSection;
	}

	public FileSection getFileSection() {
		return fileSection;
	}

	// 交易使用的分行號碼
	public String getBranchNo() {
		return getValue(Cactx201ResultHeaderFileDefinition.BRANCH_NO);
	}

	public void setBranchNo(String value) {
		setValue(Cactx201ResultHeaderFileDefinition.BRANCH_NO, value);
	}

	// 交易使用的行員號碼
	public String getTellerNo() {
		return getValue(Cactx201ResultHeaderFileDefinition.TELLER_NO);
	}

	public void setTellerNo(String value) {
		setValue(Cactx201ResultHeaderFileDefinition.TELLER_NO, value);
	}

	// 交易使用的端末機號
	public String getTermNo() {
		return getValue(Cactx201ResultHeaderFileDefinition.TERM_NO);
	}

	public void setTermNo(String value) {
		setValue(Cactx201ResultHeaderFileDefinition.TERM_NO, value);
	}

	// 交易日期
	public String getTxDate() {
		return getValue(Cactx201ResultHeaderFileDefinition.TX_DATE);
	}

	public void setTxDate(String value) {
		setValue(Cactx201ResultHeaderFileDefinition.TX_DATE, value);
	}

	// 發薪單位統編
	public String getPayCompanyId() {
		return getValue(Cactx201ResultHeaderFileDefinition.PAY_COMPANY_ID);
	}

	public void setPayCompanyId(String value) {
		setValue(Cactx201ResultHeaderFileDefinition.PAY_COMPANY_ID, value);
	}

	// 付款人帳號
	public String getPayAcct() {
		return getValue(Cactx201ResultHeaderFileDefinition.PAY_ACCT);
	}

	public void setPayAcct(String value) {
		setValue(Cactx201ResultHeaderFileDefinition.PAY_ACCT, value);
	}

	// 付款人戶名
	public String getPayName() {
		return getValue(Cactx201ResultHeaderFileDefinition.PAY_NAME);
	}

	public void setPayName(String value) {
		setValue(Cactx201ResultHeaderFileDefinition.PAY_NAME, value);
	}

	// 清算帳號
	public String getBglAcct() {
		return getValue(Cactx201ResultHeaderFileDefinition.BGL_ACCT);
	}

	public void setBglAcct(String value) {
		setValue(Cactx201ResultHeaderFileDefinition.BGL_ACCT, value);
	}

	// 發薪單位委託單位代號
	public String getPayrolCode() {
		return getValue(Cactx201ResultHeaderFileDefinition.PAYROL_CODE);
	}

	public void setPayrolCode(String value) {
		setValue(Cactx201ResultHeaderFileDefinition.PAYROL_CODE, value);
	}

	// 存摺附註
	public String getRemarks() {
		return getValue(Cactx201ResultHeaderFileDefinition.REMARKS);
	}

	public void setRemarks(String value) {
		setValue(Cactx201ResultHeaderFileDefinition.REMARKS, value);
	}

	// 付款人統編
	public String getPayerUid() {
		return getValue(Cactx201ResultHeaderFileDefinition.PAYER_UID);
	}

	public void setPayerUid(String value) {
		setValue(Cactx201ResultHeaderFileDefinition.PAYER_UID, value);
	}

	// 一扣結果系統代碼
	public String getPayerResultSysId() {
		return getValue(Cactx102Result12NHeaderFileDefinition.PAYER_RESULTSYSID);
	}

	public void setPayerResultSysId(String value) {
		setValue(Cactx102Result12NHeaderFileDefinition.PAYER_RESULTSYSID, value);
	}

	// 一扣結果
	public String getPayerResult() {
		return getValue(Cactx102Result12NHeaderFileDefinition.PAYER_RESULT);
	}

	public void setPayerResult(String value) {
		setValue(Cactx102Result12NHeaderFileDefinition.PAYER_RESULT, value);
	}

	public String getAmt21031() {
		return getValue(Cactx201ResultHeaderFileDefinition.AMT21031);
	}

	public void setAmt21031(String value) {
		setValue(Cactx201ResultHeaderFileDefinition.AMT21031, value);
	}

	public String getJrnlNo21031() {
		return getValue(Cactx201ResultHeaderFileDefinition.JRNLNO21031);
	}

	public void setJrnlNo21031(String value) {
		setValue(Cactx201ResultHeaderFileDefinition.JRNLNO21031, value);
	}

	public String getAmt20045() {
		return getValue(Cactx201ResultHeaderFileDefinition.AMT20045);
	}

	public void setAmt20045(String value) {
		setValue(Cactx201ResultHeaderFileDefinition.AMT20045, value);
	}

	public String getJrnlNo20045() {
		return getValue(Cactx201ResultHeaderFileDefinition.JRNLNO20045);
	}

	public void setJrnlNo20045(String value) {
		setValue(Cactx201ResultHeaderFileDefinition.JRNLNO20045, value);
	}

	public String getAmt21051() {
		return getValue(Cactx201ResultHeaderFileDefinition.AMT21051);
	}

	public void setAmt21051(String value) {
		setValue(Cactx201ResultHeaderFileDefinition.AMT21051, value);
	}

	public String getJrnlNo21051() {
		return getValue(Cactx201ResultHeaderFileDefinition.JRNLNO21051);
	}

	public void setJrnlNo21051(String value) {
		setValue(Cactx201ResultHeaderFileDefinition.JRNLNO21051, value);
	}

	// ========================================================
	// 以下可共用

	/**
	 * 
	 * @param fileDefinition
	 * @return
	 */
	private String getValue(IFileDefinition fileDefinition) {
		FileField fileField = fileSection.getField(fileDefinition.getId());
		if (fileField == null) {
			return null;
		}
		else {
			return StringUtils.trim(fileField.getValue());
		}
	}

	/**
	 * 
	 * @param fileDefinition
	 * @param value
	 */
	private void setValue(IFileDefinition fileDefinition, String value) {

		if (fileSection == null) {
			fileSection = new FileSection();
		}

		FileField field = fileSection.getField(fileDefinition.getId());
		if (field == null) {
			field = new FileField();
			field.setFieldId(fileDefinition.getId());
			field.setValue(value);
			fileSection.addField(field);
		}
		else {
			field.setValue(value);
		}
	}

	// 以上可共用
	// ========================================================
}
