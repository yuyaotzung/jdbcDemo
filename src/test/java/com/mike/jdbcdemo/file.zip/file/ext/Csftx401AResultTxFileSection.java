/*
 * ===========================================================================
 * IBM Confidential
 * AIS Source Materials
 * 
 * 
 * (C) Copyright IBM Corp. 2018.
 *
 * ===========================================================================
 */
package com.cosmos.file.ext;

import com.cosmos.file.bo.FileField;
import com.cosmos.file.bo.FileSection;
import com.cosmos.file.def.Csftx401AResultTxFileDefinition;
import com.cosmos.file.def.IFileDefinition;
import com.cosmos.type.FieldGroup;
import com.ibm.tw.commons.util.StringUtils;

/**
 * <p>
 * 外幣整批扣自入自、複委託扣帳-扣客戶入發動者(凱基) TX FileSection
 * </p>
 * 
 * @author Bear
 * @version 1.0, 2018/6/5
 * @see
 * @since
 */
public class Csftx401AResultTxFileSection {

	/** 檔案區段 */
	private FileSection fileSection;

	public Csftx401AResultTxFileSection() {
		fileSection = new FileSection();
		fileSection.setFieldGroup(FieldGroup.TX);
	}

	public Csftx401AResultTxFileSection(FileSection fileSection) {
		this.fileSection = fileSection;
	}

	public FileSection getFileSection() {
		return fileSection;
	}

	// Data Indicator
	public String getDataIndicator() {
		return getValue(Csftx401AResultTxFileDefinition.DATA_INDICATOR);
	}

	public void setDataIndicator(String value) {
		setValue(Csftx401AResultTxFileDefinition.DATA_INDICATOR, value);
	}

	// 批號PBMT-BATCH-NO
	public String getBatchNo() {
		return getValue(Csftx401AResultTxFileDefinition.BATCH_NO);
	}

	public void setBatchNo(String value) {
		setValue(Csftx401AResultTxFileDefinition.BATCH_NO, value);
	}

	// 流水號PBMT-SERNO
	public String getSerno() {
		return getValue(Csftx401AResultTxFileDefinition.SERNO);
	}

	public void setSerno(String value) {
		setValue(Csftx401AResultTxFileDefinition.SERNO, value);
	}

	// 明細的序號
	public String getSeq() {
		return getValue(Csftx401AResultTxFileDefinition.SEQ);
	}

	public void setSeq(String value) {
		setValue(Csftx401AResultTxFileDefinition.SEQ, value);
	}

	// 轉出帳號
	public String getPayerAcctNo() {
		return getValue(Csftx401AResultTxFileDefinition.PAYER_ACCT_NO);
	}

	public void setPayerAcctNo(String value) {
		setValue(Csftx401AResultTxFileDefinition.PAYER_ACCT_NO, value);
	}

	// 轉出帳號幣別
	public String getPayerCurrency() {
		return getValue(Csftx401AResultTxFileDefinition.PAYER_CURRENCY);
	}

	public void setPayerCurrency(String value) {
		setValue(Csftx401AResultTxFileDefinition.PAYER_CURRENCY, value);
	}

	// 轉入帳號
	public String getPayeeAcctNo() {
		return getValue(Csftx401AResultTxFileDefinition.PAYEE_ACCT_NO);
	}

	public void setPayeeAcctNo(String value) {
		setValue(Csftx401AResultTxFileDefinition.PAYEE_ACCT_NO, value);
	}

	// 轉入帳號幣別
	public String getPayeeCurrency() {
		return getValue(Csftx401AResultTxFileDefinition.PAYEE_CURRENCY);
	}

	public void setPayeeCurrency(String value) {
		setValue(Csftx401AResultTxFileDefinition.PAYEE_CURRENCY, value);
	}

	// 交易金額
	public String getTxAmt() {
		return getValue(Csftx401AResultTxFileDefinition.TX_AMT);
	}

	public void setTxAmt(String value) {
		setValue(Csftx401AResultTxFileDefinition.TX_AMT, value);
	}

	// 交易幣別
	public String getTxCurrency() {
		return getValue(Csftx401AResultTxFileDefinition.TX_CURRENCY);
	}

	public void setTxCurrency(String value) {
		setValue(Csftx401AResultTxFileDefinition.TX_CURRENCY, value);
	}

	// 轉出匯率
	public String getColumn11() {
		return getValue(Csftx401AResultTxFileDefinition.COLUMN11);
	}

	public void setColumn11(String value) {
		setValue(Csftx401AResultTxFileDefinition.COLUMN11, value);
	}

	// 轉入匯率
	public String getColumn12() {
		return getValue(Csftx401AResultTxFileDefinition.COLUMN12);
	}

	public void setColumn12(String value) {
		setValue(Csftx401AResultTxFileDefinition.COLUMN12, value);
	}

	// 匯率議價編號
	public String getColumn13() {
		return getValue(Csftx401AResultTxFileDefinition.COLUMN13);
	}

	public void setColumn13(String value) {
		setValue(Csftx401AResultTxFileDefinition.COLUMN13, value);
	}

	// 遠匯/換匯編號
	public String getColumn14() {
		return getValue(Csftx401AResultTxFileDefinition.COLUMN14);
	}

	public void setColumn14(String value) {
		setValue(Csftx401AResultTxFileDefinition.COLUMN14, value);
	}

	// 牌告/成交匯率
	public String getColumn15() {
		return getValue(Csftx401AResultTxFileDefinition.COLUMN15);
	}

	public void setColumn15(String value) {
		setValue(Csftx401AResultTxFileDefinition.COLUMN15, value);
	}

	// 成本匯率
	public String getColumn16() {
		return getValue(Csftx401AResultTxFileDefinition.COLUMN16);
	}

	public void setColumn16(String value) {
		setValue(Csftx401AResultTxFileDefinition.COLUMN16, value);
	}

	// 等值USD金額
	public String getColumn17() {
		return getValue(Csftx401AResultTxFileDefinition.COLUMN17);
	}

	public void setColumn17(String value) {
		setValue(Csftx401AResultTxFileDefinition.COLUMN17, value);
	}

	// 兌換USD匯率
	public String getColumn18() {
		return getValue(Csftx401AResultTxFileDefinition.COLUMN18);
	}

	public void setColumn18(String value) {
		setValue(Csftx401AResultTxFileDefinition.COLUMN18, value);
	}

	// 兌換USD買/賣匯
	public String getColumn19() {
		return getValue(Csftx401AResultTxFileDefinition.COLUMN19);
	}

	public void setColumn19(String value) {
		setValue(Csftx401AResultTxFileDefinition.COLUMN19, value);
	}

	// 等值TWD金額
	public String getColumn20() {
		return getValue(Csftx401AResultTxFileDefinition.COLUMN20);
	}

	public void setColumn20(String value) {
		setValue(Csftx401AResultTxFileDefinition.COLUMN20, value);
	}

	// 兌換TWD匯率
	public String getColumn21() {
		return getValue(Csftx401AResultTxFileDefinition.COLUMN21);
	}

	public void setColumn21(String value) {
		setValue(Csftx401AResultTxFileDefinition.COLUMN21, value);
	}

	// 兌換TWD買/賣匯
	public String getColumn22() {
		return getValue(Csftx401AResultTxFileDefinition.COLUMN22);
	}

	public void setColumn22(String value) {
		setValue(Csftx401AResultTxFileDefinition.COLUMN22, value);
	}

	// 等值本位幣轉出成本金額
	public String getColumn23() {
		return getValue(Csftx401AResultTxFileDefinition.COLUMN23);
	}

	public void setColumn23(String value) {
		setValue(Csftx401AResultTxFileDefinition.COLUMN23, value);
	}

	// 對本位幣轉出成本匯率
	public String getColumn24() {
		return getValue(Csftx401AResultTxFileDefinition.COLUMN24);
	}

	public void setColumn24(String value) {
		setValue(Csftx401AResultTxFileDefinition.COLUMN24, value);
	}

	// 等值本位幣轉入成本金額
	public String getColumn25() {
		return getValue(Csftx401AResultTxFileDefinition.COLUMN25);
	}

	public void setColumn25(String value) {
		setValue(Csftx401AResultTxFileDefinition.COLUMN25, value);
	}

	// 對本位幣轉入成本匯率
	public String getColumn26() {
		return getValue(Csftx401AResultTxFileDefinition.COLUMN26);
	}

	public void setColumn26(String value) {
		setValue(Csftx401AResultTxFileDefinition.COLUMN26, value);
	}

	// 議價種類
	public String getColumn27() {
		return getValue(Csftx401AResultTxFileDefinition.COLUMN27);
	}

	public void setColumn27(String value) {
		setValue(Csftx401AResultTxFileDefinition.COLUMN27, value);
	}

	// 訂約日期
	public String getColumn28() {
		return getValue(Csftx401AResultTxFileDefinition.COLUMN28);
	}

	public void setColumn28(String value) {
		setValue(Csftx401AResultTxFileDefinition.COLUMN28, value);
	}

	// 被報價幣幣別
	public String getColumn29() {
		return getValue(Csftx401AResultTxFileDefinition.COLUMN29);
	}

	public void setColumn29(String value) {
		setValue(Csftx401AResultTxFileDefinition.COLUMN29, value);
	}

	// 匯率類型
	public String getColumn30() {
		return getValue(Csftx401AResultTxFileDefinition.COLUMN30);
	}

	public void setColumn30(String value) {
		setValue(Csftx401AResultTxFileDefinition.COLUMN30, value);
	}

	// 提示碼
	public String getPromoCode() {
		return getValue(Csftx401AResultTxFileDefinition.PROMO_CODE);
	}

	public void setPromoCode(String value) {
		setValue(Csftx401AResultTxFileDefinition.PROMO_CODE, value);
	}

	// 附註
	public String getRemarks() {
		return getValue(Csftx401AResultTxFileDefinition.REMARKS);
	}

	public void setRemarks(String value) {
		setValue(Csftx401AResultTxFileDefinition.REMARKS, value);
	}

	// 是否檢核代收付起迄日
	public String getValidate() {
		return getValue(Csftx401AResultTxFileDefinition.VALIDATE);
	}

	public void setValidate(String value) {
		setValue(Csftx401AResultTxFileDefinition.VALIDATE, value);
	}

	// 檢核ID
	public String getCheckId() {
		return getValue(Csftx401AResultTxFileDefinition.CHECK_ID);
	}

	public void setCheckId(String value) {
		setValue(Csftx401AResultTxFileDefinition.CHECK_ID, value);
	}

	// 檢核戶名
	public String getCheckName() {
		return getValue(Csftx401AResultTxFileDefinition.CHECK_NAME);
	}

	public void setCheckName(String value) {
		setValue(Csftx401AResultTxFileDefinition.CHECK_NAME, value);
	}

	// 銷帳資料
	public String getColumn36() {
		return getValue(Csftx401AResultTxFileDefinition.COLUMN36);
	}

	public void setColumn36(String value) {
		setValue(Csftx401AResultTxFileDefinition.COLUMN36, value);
	}

	// 央媒申報
	public String getColumn37() {
		return getValue(Csftx401AResultTxFileDefinition.COLUMN37);
	}

	public void setColumn37(String value) {
		setValue(Csftx401AResultTxFileDefinition.COLUMN37, value);
	}

	// 外匯交易編號
	public String getColumn38() {
		return getValue(Csftx401AResultTxFileDefinition.COLUMN38);
	}

	public void setColumn38(String value) {
		setValue(Csftx401AResultTxFileDefinition.COLUMN38, value);
	}

	// 身分別
	public String getColumn39() {
		return getValue(Csftx401AResultTxFileDefinition.COLUMN39);
	}

	public void setColumn39(String value) {
		setValue(Csftx401AResultTxFileDefinition.COLUMN39, value);
	}

	// 證件類型
	public String getColumn40() {
		return getValue(Csftx401AResultTxFileDefinition.COLUMN40);
	}

	public void setColumn40(String value) {
		setValue(Csftx401AResultTxFileDefinition.COLUMN40, value);
	}

	// 證件號碼
	public String getColumn41() {
		return getValue(Csftx401AResultTxFileDefinition.COLUMN41);
	}

	public void setColumn41(String value) {
		setValue(Csftx401AResultTxFileDefinition.COLUMN41, value);
	}

	// 出生日期
	public String getColumn42() {
		return getValue(Csftx401AResultTxFileDefinition.COLUMN42);
	}

	public void setColumn42(String value) {
		setValue(Csftx401AResultTxFileDefinition.COLUMN42, value);
	}

	// 居留證有效日期
	public String getColumn43() {
		return getValue(Csftx401AResultTxFileDefinition.COLUMN43);
	}

	public void setColumn43(String value) {
		setValue(Csftx401AResultTxFileDefinition.COLUMN43, value);
	}

	// 居留證核發日期
	public String getColumn44() {
		return getValue(Csftx401AResultTxFileDefinition.COLUMN44);
	}

	public void setColumn44(String value) {
		setValue(Csftx401AResultTxFileDefinition.COLUMN44, value);
	}

	// 匯款分類
	public String getColumn45() {
		return getValue(Csftx401AResultTxFileDefinition.COLUMN45);
	}

	public void setColumn45(String value) {
		setValue(Csftx401AResultTxFileDefinition.COLUMN45, value);
	}

	// 匯款分類69X細分類
	public String getColumn46() {
		return getValue(Csftx401AResultTxFileDefinition.COLUMN46);
	}

	public void setColumn46(String value) {
		setValue(Csftx401AResultTxFileDefinition.COLUMN46, value);
	}

	// 匯款地國別
	public String getColumn47() {
		return getValue(Csftx401AResultTxFileDefinition.COLUMN47);
	}

	public void setColumn47(String value) {
		setValue(Csftx401AResultTxFileDefinition.COLUMN47, value);
	}

	// 有無申報書
	public String getColumn48() {
		return getValue(Csftx401AResultTxFileDefinition.COLUMN48);
	}

	public void setColumn48(String value) {
		setValue(Csftx401AResultTxFileDefinition.COLUMN48, value);
	}

	// 檢附核准函
	public String getColumn49() {
		return getValue(Csftx401AResultTxFileDefinition.COLUMN49);
	}

	public void setColumn49(String value) {
		setValue(Csftx401AResultTxFileDefinition.COLUMN49, value);
	}

	// 檢附相關文件
	public String getColumn50() {
		return getValue(Csftx401AResultTxFileDefinition.COLUMN50);
	}

	public void setColumn50(String value) {
		setValue(Csftx401AResultTxFileDefinition.COLUMN50, value);
	}

	// 結購結售外匯性質
	public String getColumn51() {
		return getValue(Csftx401AResultTxFileDefinition.COLUMN51);
	}

	public void setColumn51(String value) {
		setValue(Csftx401AResultTxFileDefinition.COLUMN51, value);
	}

	// 交易類型
	public String getColumn52() {
		return getValue(Csftx401AResultTxFileDefinition.COLUMN52);
	}

	public void setColumn52(String value) {
		setValue(Csftx401AResultTxFileDefinition.COLUMN52, value);
	}

	// 指定銀行
	public String getColumn53() {
		return getValue(Csftx401AResultTxFileDefinition.COLUMN53);
	}

	public void setColumn53(String value) {
		setValue(Csftx401AResultTxFileDefinition.COLUMN53, value);
	}

	// 送件編號
	public String getColumn54() {
		return getValue(Csftx401AResultTxFileDefinition.COLUMN54);
	}

	public void setColumn54(String value) {
		setValue(Csftx401AResultTxFileDefinition.COLUMN54, value);
	}

	// 申報註記
	public String getColumn55() {
		return getValue(Csftx401AResultTxFileDefinition.COLUMN55);
	}

	public void setColumn55(String value) {
		setValue(Csftx401AResultTxFileDefinition.COLUMN55, value);
	}

	// 身分別
	public String getColumn56() {
		return getValue(Csftx401AResultTxFileDefinition.COLUMN56);
	}

	public void setColumn56(String value) {
		setValue(Csftx401AResultTxFileDefinition.COLUMN56, value);
	}

	// 證件類型
	public String getColumn57() {
		return getValue(Csftx401AResultTxFileDefinition.COLUMN57);
	}

	public void setColumn57(String value) {
		setValue(Csftx401AResultTxFileDefinition.COLUMN57, value);
	}

	// 證件號碼
	public String getColumn58() {
		return getValue(Csftx401AResultTxFileDefinition.COLUMN58);
	}

	public void setColumn58(String value) {
		setValue(Csftx401AResultTxFileDefinition.COLUMN58, value);
	}

	// 出生日期
	public String getColumn59() {
		return getValue(Csftx401AResultTxFileDefinition.COLUMN59);
	}

	public void setColumn59(String value) {
		setValue(Csftx401AResultTxFileDefinition.COLUMN59, value);
	}

	// 居留證有效日期
	public String getColumn60() {
		return getValue(Csftx401AResultTxFileDefinition.COLUMN60);
	}

	public void setColumn60(String value) {
		setValue(Csftx401AResultTxFileDefinition.COLUMN60, value);
	}

	// 居留證核發日期
	public String getColumn61() {
		return getValue(Csftx401AResultTxFileDefinition.COLUMN61);
	}

	public void setColumn61(String value) {
		setValue(Csftx401AResultTxFileDefinition.COLUMN61, value);
	}

	// 匯款分類
	public String getColumn62() {
		return getValue(Csftx401AResultTxFileDefinition.COLUMN62);
	}

	public void setColumn62(String value) {
		setValue(Csftx401AResultTxFileDefinition.COLUMN62, value);
	}

	// 匯款分類69X細分類
	public String getColumn63() {
		return getValue(Csftx401AResultTxFileDefinition.COLUMN63);
	}

	public void setColumn63(String value) {
		setValue(Csftx401AResultTxFileDefinition.COLUMN63, value);
	}

	// 匯款地國別
	public String getColumn64() {
		return getValue(Csftx401AResultTxFileDefinition.COLUMN64);
	}

	public void setColumn64(String value) {
		setValue(Csftx401AResultTxFileDefinition.COLUMN64, value);
	}

	// 有無申報書
	public String getColumn65() {
		return getValue(Csftx401AResultTxFileDefinition.COLUMN65);
	}

	public void setColumn65(String value) {
		setValue(Csftx401AResultTxFileDefinition.COLUMN65, value);
	}

	// 檢附核准函
	public String getColumn66() {
		return getValue(Csftx401AResultTxFileDefinition.COLUMN66);
	}

	public void setColumn66(String value) {
		setValue(Csftx401AResultTxFileDefinition.COLUMN66, value);
	}

	// 檢附相關文件
	public String getColumn67() {
		return getValue(Csftx401AResultTxFileDefinition.COLUMN67);
	}

	public void setColumn67(String value) {
		setValue(Csftx401AResultTxFileDefinition.COLUMN67, value);
	}

	// 結購結售外匯性質
	public String getColumn68() {
		return getValue(Csftx401AResultTxFileDefinition.COLUMN68);
	}

	public void setColumn68(String value) {
		setValue(Csftx401AResultTxFileDefinition.COLUMN68, value);
	}

	// 交易類型
	public String getColumn69() {
		return getValue(Csftx401AResultTxFileDefinition.COLUMN69);
	}

	public void setColumn69(String value) {
		setValue(Csftx401AResultTxFileDefinition.COLUMN69, value);
	}

	// 指定銀行
	public String getColumn70() {
		return getValue(Csftx401AResultTxFileDefinition.COLUMN70);
	}

	public void setColumn70(String value) {
		setValue(Csftx401AResultTxFileDefinition.COLUMN70, value);
	}

	// 送件編號
	public String getColumn71() {
		return getValue(Csftx401AResultTxFileDefinition.COLUMN71);
	}

	public void setColumn71(String value) {
		setValue(Csftx401AResultTxFileDefinition.COLUMN71, value);
	}

	// 申報註記
	public String getColumn72() {
		return getValue(Csftx401AResultTxFileDefinition.COLUMN72);
	}

	public void setColumn72(String value) {
		setValue(Csftx401AResultTxFileDefinition.COLUMN72, value);
	}

	// 中心執行BANCS-STAT
	public String getBancsStat() {
		return getValue(Csftx401AResultTxFileDefinition.BANCS_STAT);
	}

	public void setBancsStat(String value) {
		setValue(Csftx401AResultTxFileDefinition.BANCS_STAT, value);
	}

	// 交易 Journal No
	public String getJrnlNo() {
		return getValue(Csftx401AResultTxFileDefinition.JRNL_NO);
	}

	public void setJrnlNo(String value) {
		setValue(Csftx401AResultTxFileDefinition.JRNL_NO, value);
	}

	// 實際交易帳號
	public String getAcctNo() {
		return getValue(Csftx401AResultTxFileDefinition.ACCT_NO);
	}

	public void setAcctNo(String value) {
		setValue(Csftx401AResultTxFileDefinition.ACCT_NO, value);
	}

	// 實際扣款金額
	public String getAmount() {
		return getValue(Csftx401AResultTxFileDefinition.AMOUNT);
	}

	public void setAmount(String value) {
		setValue(Csftx401AResultTxFileDefinition.AMOUNT, value);
	}

	// 沖正交易 CORR-STAT
	public String getCorrStat() {
		return getValue(Csftx401AResultTxFileDefinition.CORR_STAT);
	}

	public void setCorrStat(String value) {
		setValue(Csftx401AResultTxFileDefinition.CORR_STAT, value);
	}

	// FILLER
	public String getFiller() {
		return getValue(Csftx401AResultTxFileDefinition.FILLER);
	}

	public void setFiller(String value) {
		setValue(Csftx401AResultTxFileDefinition.FILLER, value);
	}

	// 國外受款/匯款人身份別
	public String getColumn73() {
		return getValue(Csftx401AResultTxFileDefinition.COLUMN73);
	}

	public void setColumn73(String value) {
		setValue(Csftx401AResultTxFileDefinition.COLUMN73, value);
	}

	// 外國人國別
	public String getColumn74() {
		return getValue(Csftx401AResultTxFileDefinition.COLUMN74);
	}

	public void setColumn74(String value) {
		setValue(Csftx401AResultTxFileDefinition.COLUMN74, value);
	}

	// 國外受款/匯款人身份別
	public String getColumn75() {
		return getValue(Csftx401AResultTxFileDefinition.COLUMN75);
	}

	public void setColumn75(String value) {
		setValue(Csftx401AResultTxFileDefinition.COLUMN75, value);
	}

	// 外國人國別
	public String getColumn76() {
		return getValue(Csftx401AResultTxFileDefinition.COLUMN76);
	}

	public void setColumn76(String value) {
		setValue(Csftx401AResultTxFileDefinition.COLUMN76, value);
	}

	// ========================================================
	// 以下可共用

	/**
	 * 
	 * @param fileDefinition
	 * @return
	 */
	private String getValue(IFileDefinition fileDefinition) {

		FileField fileField = fileSection.getField(fileDefinition.getId());
		if (fileField == null) {
			return null;
		}
		else {
			return StringUtils.trim(fileField.getValue());
		}
	}

	/**
	 * 
	 * @param fileDefinition
	 * @param value
	 */
	private void setValue(IFileDefinition fileDefinition, String value) {

		if (fileSection == null) {
			fileSection = new FileSection();
		}

		FileField field = fileSection.getField(fileDefinition.getId());
		if (field == null) {
			field = new FileField();
			field.setFieldId(fileDefinition.getId());
			field.setValue(value);
			fileSection.addField(field);
		}
		else {
			field.setValue(value);
		}
	}

	// 以上可共用
	// ========================================================

	// 代收付流水號
	public String getColumn80() {
		return getValue(Csftx401AResultTxFileDefinition.COLUMN80);
	}

	public void setColumn80(String value) {
		setValue(Csftx401AResultTxFileDefinition.COLUMN80, value);
	}
	
	// 轉入方備註
	public String getColumn81() {
		return getValue(Csftx401AResultTxFileDefinition.COLUMN81);
	}

	public void setColumn81(String value) {
		setValue(Csftx401AResultTxFileDefinition.COLUMN81, value);
	}
	
	// 圈存理由
	public String getColumn82() {
		return getValue(Csftx401AResultTxFileDefinition.COLUMN82);
	}

	public void setColumn82(String value) {
		setValue(Csftx401AResultTxFileDefinition.COLUMN82, value);
	}	
	
	// 原圈存日期
	public String getColumn83() {
		return getValue(Csftx401AResultTxFileDefinition.COLUMN83);
	}

	public void setColumn83(String value) {
		setValue(Csftx401AResultTxFileDefinition.COLUMN83, value);
	}	
	
	// 原圈存交易序號
	public String getColumn84() {
		return getValue(Csftx401AResultTxFileDefinition.COLUMN84);
	}

	public void setColumn84(String value) {
		setValue(Csftx401AResultTxFileDefinition.COLUMN84, value);
	}	
	
	// 券商集保代號
	public String getColumn85() {
		return getValue(Csftx401AResultTxFileDefinition.COLUMN85);
	}

	public void setColumn85(String value) {
		setValue(Csftx401AResultTxFileDefinition.COLUMN85, value);
	}	
}
