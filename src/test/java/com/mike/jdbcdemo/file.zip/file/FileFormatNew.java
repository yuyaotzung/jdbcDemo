/*
 * ===========================================================================
 * IBM Confidential
 * AIS Source Materials
 * 
 * 
 * (C) Copyright IBM Corp. 2011.
 *
 * ===========================================================================
 */
package com.cosmos.file;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.apache.poi.POIXMLException;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.poifs.filesystem.OfficeXmlFileException;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.cosmos.code.CibErrorCode;
import com.cosmos.file.bo.FileDetail;
import com.cosmos.file.bo.FileDoc;
import com.cosmos.file.bo.FileField;
import com.cosmos.file.bo.FileSection;
import com.cosmos.file.parser.handler.FileHandlerDelim;
import com.cosmos.file.parser.handler.FileHandlerExcel;
import com.cosmos.file.parser.handler.FileHandlerFixedLen;
import com.cosmos.persistence.CosmosDaoFactory;
import com.cosmos.persistence.b2c.dao.IFileFormatDao;
import com.cosmos.persistence.b2c.dao.IFileFormatDetailDao;
import com.cosmos.persistence.b2c.entity.FileFormatDetailEntity;
import com.cosmos.persistence.b2c.entity.FileFormatEntity;
import com.cosmos.type.FieldGroup;
import com.cosmos.type.TaskType;
import com.cosmos.util.CosmosUtils;
import com.cosmos.util.LineSeparator;
import com.ibm.tw.commons.exception.ActionException;
import com.ibm.tw.commons.id.ICommonCode;
import com.ibm.tw.commons.persistence.exception.DatabaseException;
import com.ibm.tw.commons.util.ConvertUtils;
import com.ibm.tw.commons.util.StringUtils;

/**
 * <p>
 * 檔案匯入格式
 * </p>
 * 
 * @author Leo
 * @version 1.0, 2011/5/7
 * @see
 * @since
 */
public abstract class FileFormatNew {

	/** 編碼類型(供舊有的parsing使用) */
	public String ENCODING = "MS950";

	/** 檔案格式主檔資料 */
	protected FileFormatEntity master = null;

	/** 檔案格式明細檔 (依FieldGroup分群) */
	protected Map<FieldGroup, List<FileFormatDetail>> detailGroup = new HashMap<FieldGroup, List<FileFormatDetail>>();

	/** 文件是否已經存在資料庫 */
	protected boolean loaded = false;

	protected static Logger logger = Logger.getLogger(FileFormatNew.class);

	/** 原始檔案, 失敗檔案 */
	protected FileDoc fileDoc = new FileDoc();

	/** 檔案行數 */
	private int rows;

	// 新增getter, setter

	// 取得實際檔案格式中設定的encoding
	public String getENCODING() {
		return master.getCodeSet();
	}

	public FileFormatEntity getMaster() {
		return master;
	}

	public void setMaster(FileFormatEntity master) {
		this.master = master;
	}

	public Map<FieldGroup, List<FileFormatDetail>> getDetailGroup() {
		return detailGroup;
	}

	public void setDetailGroup(Map<FieldGroup, List<FileFormatDetail>> detailGroup) {
		this.detailGroup = detailGroup;
	}

	public void setFileDoc(FileDoc fileDoc) {
		this.fileDoc = fileDoc;
	}

	public FileDoc getFileDoc() {

		return fileDoc;
	}

	// 新增getter, setter ends

	/**
	 * 取得所屬交易
	 * 
	 * @return
	 */
	public abstract TaskType getTaskType();

	public FileFormatNew() {
	}

	/**
	 * 根據檔案格式鍵值載入資料
	 * 
	 * Constructor
	 * 
	 * @param fileFormatKey
	 * @throws DatabaseException
	 */
	public FileFormatNew(String fileFormatKey) throws DatabaseException {
		load(fileFormatKey);

		this.loaded = true;
	}

	/**
	 * 初始化檔案格式資料
	 * 
	 * Constructor
	 * 
	 * @param loginUser
	 * @param taskId
	 * @param txBatchType
	 */
	public FileFormatNew(int companyKey, String taskId, int txBatchType) {

		init(companyKey, taskId, txBatchType);

		this.loaded = false;
	}

	/**
	 * 初始化流程文件共同資料
	 * 
	 * @throws DatabaseException
	 * 
	 */
	protected void initMaster(int companyKey, String taskId, int txBatchType) {

		master = new FileFormatEntity();

		// 公司統編
		master.setCompanyKey(companyKey);

		// 交易代號
		master.setTaskId(taskId);

		// 整批格式
		master.setTxBatchType(txBatchType);

		// 2016/3/21:ACH檔案由程式設定格式，須符合新的檔案格式由第一行開始
		master.setStartRow(1);
	}

	/**
	 * 儲存流程文件
	 * 
	 * @throws DatabaseException
	 */
	public void save() throws DatabaseException {

		// 修改
		if (loaded) {
			update();
		}
		// 新增
		else {
			insert();
		}

		this.loaded = true;
	}

	/**
	 * 載入交易主檔
	 * 
	 * @param flowDocId
	 * @throws DatabaseException
	 */
	protected void loadMaster(long fileFormatKey) throws DatabaseException {

		IFileFormatDao dao = CosmosDaoFactory.getFileFormatDao();

		this.master = dao.findByKey(fileFormatKey);

	}

	/**
	 * 移除交易主檔
	 * 
	 * @throws DatabaseException
	 */
	protected void removeMaster() throws DatabaseException {

		IFileFormatDao dao = CosmosDaoFactory.getFileFormatDao();

		dao.remove(master);
	}

	/**
	 * 新增交易主檔
	 * 
	 * @return
	 * @throws DatabaseException
	 */
	protected void insertMaster() throws DatabaseException {

		IFileFormatDao dao = CosmosDaoFactory.getFileFormatDao();

		this.master = dao.insert(master);
	}

	/**
	 * 修改交易主檔
	 * 
	 * @throws DatabaseException
	 */
	protected void updateMaster() throws DatabaseException {

		IFileFormatDao dao = CosmosDaoFactory.getFileFormatDao();

		this.master = dao.update(master);
	}

	/**
	 * 初始化流程文件共同資料
	 * 
	 * @throws DatabaseException
	 * 
	 */
	public void init(int companyKey, String taskId, int txBatchType) {

		initMaster(companyKey, taskId, txBatchType);

		detailGroup = new HashMap<FieldGroup, List<FileFormatDetail>>();

		// fields = new HashMap<String, FileFormatFieldEntity>();

	}

	/**
	 * <p>
	 * 根據案件序號載入文件
	 * </p>
	 * 
	 * @throws DatabaseException
	 */
	public void load(String fileFormatKey) throws DatabaseException {

		long key = ConvertUtils.str2Long(fileFormatKey);

		// 載入主檔 (FileFormatEntity)
		loadMaster(key);

		// 載入明細檔 (FileFormatDetailEntity)
		loadDetails();

		// 載入定義檔 (FileFormatFieldEntity)
		// loadFieldMap(details);
	}

	/**
	 * 分群明細檔
	 * 
	 * @throws DatabaseException
	 */
	private void loadDetails() throws DatabaseException {

		detailGroup.clear();

		IFileFormatDetailDao dao = CosmosDaoFactory.getFileFormatDetailDao();

		List<FileFormatDetailEntity> details = dao.findByMasterKey(master.getFileFormatKey());

		for (FileFormatDetailEntity detail : details) {

			addFileFormatDetail(detail);
		}
	}

	/**
	 * 加入FileFormatDetail
	 * 
	 * @param detail
	 * @param fieldGroup
	 * @throws DatabaseException
	 */
	private void addFileFormatDetail(FileFormatDetailEntity entity) throws DatabaseException {

		FileFormatDetail detail = new FileFormatDetail(getTaskType(), entity);

		// 取得所屬群組
		FieldGroup fieldGroup = detail.getFieldGroup();

		// 取得對應detail list
		List<FileFormatDetail> details = detailGroup.get(fieldGroup);

		if (details == null) {
			details = new ArrayList<FileFormatDetail>();
		}

		// 加入detail
		details.add(detail);

		detailGroup.put(fieldGroup, details);
	}

	/**
	 * 加入FileFormatDetail
	 * 
	 * @param fieldId
	 * @param fieldName
	 * @param length
	 * @param orderNo
	 * @throws DatabaseException
	 */
	public void addFileFormatDetail(String fieldId, String fieldName, int length, int orderNo) throws DatabaseException {

		FileFormatDetail detail = new FileFormatDetail(getTaskType(), fieldId, fieldName, length, orderNo);

		// 取得所屬群組
		FieldGroup fieldGroup = detail.getFieldGroup();

		// 取得對應detail list
		List<FileFormatDetail> details = detailGroup.get(fieldGroup);

		if (details == null) {
			details = new ArrayList<FileFormatDetail>();
		}

		// 加入detail
		details.add(detail);

		detailGroup.put(fieldGroup, details);
	}

	/**
	 * <p>
	 * 根據文件代碼刪除文件
	 * </p>
	 * 
	 * @param docId
	 * @throws DatabaseException
	 */
	public void remove() throws DatabaseException {

		long fileFormatKey = master.getFileFormatKey();

		if (fileFormatKey == 0) {
			logger.info("no fileFormatKey");
			return;
		}

		// 移除明細檔 (FileFormatDetailEntity)
		removeDetails();

		// 移除主檔 (FileFormatEntity)
		removeMaster();
	}

	/**
	 * 移除交易明細檔
	 * 
	 * @return
	 * @throws DatabaseException
	 */
	private void removeDetails() throws DatabaseException {

		for (List<FileFormatDetail> details : detailGroup.values()) {

			for (FileFormatDetail detail : details) {
				detail.remove();
			}
		}
	}

	/**
	 * 新增
	 * 
	 * @throws DatabaseException
	 */
	protected void insert() throws DatabaseException {
		// 新增主檔 (FileFormatEntity)
		insertMaster();

		// 新增明細檔 (FileFormatDetailEntity)
		insertDetails();
	}

	/**
	 * 新增交易明細檔
	 * 
	 * @return
	 * @throws DatabaseException
	 */
	private void insertDetails() throws DatabaseException {

		for (List<FileFormatDetail> details : detailGroup.values()) {

			for (FileFormatDetail detail : details) {

				// 檔案格式鍵值（主檔）
				detail.setFileFormatKey(master.getFileFormatKey());

				detail.insert();
			}
		}
	}

	/**
	 * 更新
	 * 
	 * @throws DatabaseException
	 */
	protected void update() throws DatabaseException {
		// 更新主檔 (FileFormatEntity)
		updateMaster();

		// 更新明細檔 (FileFormatDetailEntity)
		updateDetails();
	}

	/**
	 * 更新交易明細檔
	 * 
	 * @return
	 * @throws DatabaseException
	 */
	private void updateDetails() throws DatabaseException {

		for (List<FileFormatDetail> details : detailGroup.values()) {

			for (FileFormatDetail detail : details) {

				// 檔案格式鍵值（主檔）
				detail.setFileFormatKey(master.getFileFormatKey());

				detail.update();
			}
		}
	}

	public String getFormatName() {
		return StringUtils.trimToEmpty(master.getFormatName());
	}

	public void setFormatName(String formatName) {
		master.setFormatName(formatName);
	}

	public boolean isLoaded() {
		return loaded;
	}

	public void setLoaded(boolean loaded) {
		this.loaded = loaded;
	}

	/**
	 * 依據行號與區段取得格式
	 * 
	 * @param rowNo
	 * @param sectionNo
	 * @return
	 */
	protected FieldGroup getFieldGroup(int rowNo, int sectionNo) {
		if (rowNo < 1) {
			return FieldGroup.UNKNOWN;
		}
		else {
			if (sectionNo < 1) {
				return FieldGroup.UNKNOWN;
			}
			else if (sectionNo == 1) {
				return getFormatHead(rowNo);
			}
			else {
				return getFormatCycle(rowNo);
			}
		}
	}

	/**
	 * 依據行號取得起始格式
	 * 
	 * @param rowNo
	 * @return
	 */
	public abstract FieldGroup getFormatHead(int rowNo);

	/**
	 * 依據行號取得循環格式
	 * 
	 * @param rowNo
	 * @return
	 */
	public abstract FieldGroup getFormatCycle(int rowNo);

	/**
	 * 取得尾筆格式
	 * 
	 * @return
	 */
	public FieldGroup getFormatFooter() {
		return FieldGroup.FOOTER;
	}

	/**
	 * 四階新的pasrsing程式，可支援固定長度與分隔符號檔案格式
	 * 
	 * <p>
	 * 2016/12/30 : 新增 Parse Excel 檔
	 * </p>
	 * 
	 * @param fileContent
	 * @return
	 * @throws ActionException
	 */
	public boolean parseFileEx(byte[] fileContent) throws ActionException {

		fileDoc = new FileDoc();

		if (master.getFieldDelimiterType() == 3) {
			/* 【將匯入資料組成陣列】 */
			List<Row> fileRecords = getExcelFileRecords(fileContent);

			/* 【EXCEL的檔案PARSER】 */
			FileHandlerExcel handler = new FileHandlerExcel(this);
			fileDoc = handler.parse(fileRecords);
		}
		else {
			/* 【將匯入資料組成陣列】 */
			List<byte[]> fileRecords = getFileRecords(fileContent);

			/** 取得fileDoc下的明細資料 **/
			if (master.getFieldDelimiterType() == 1) {
				/* 【固定長度的檔案PARSER】 */
				FileHandlerFixedLen handler = new FileHandlerFixedLen(this);
				fileDoc = handler.parse(fileRecords);
			}
			else {
				/* 【分隔符號的檔案PARSER】 */
				FileHandlerDelim handler = new FileHandlerDelim(this);
				fileDoc = handler.parse(fileRecords);
			}
		}

		validateEx(fileDoc);

		// 如有錯誤, 則回傳false
		if (fileDoc.isError()) {
			// 2016/1/18 ally:失敗仍要轉換檔案內容為可操作物件
			putData(fileDoc);
			return false;
		}
		else {
			// 轉換檔案內容為可操作物件
			putData(fileDoc);

			if (fileDoc.isError()) {
				return false;
			}
			else {
				return true;
			}
		}
	}

	/**
	 * parse檔案(舊的parsing程式，只支援公版固定長度)
	 * 
	 * @param fileContent
	 * @return
	 * @throws ActionException
	 */
	public boolean parseFile(byte[] fileContent) throws ActionException {

		fileDoc = new FileDoc();

		/* 使用分行符號轉成多筆紀錄 */
		List<byte[]> fileRecords = getFileRecords(fileContent);

		rows = fileRecords.size();

		for (int i = 0; i < rows; i++) {

			byte[] byteDetail = fileRecords.get(i);

			// 行號
			int rowNo = i + 1;

			FileDetail fileDetail = getFileDetail(rowNo, byteDetail, getFormatDetails(getFormatHead(rowNo)), getFormatDetails(getFormatCycle(rowNo)));
			fileDoc.addDetail(fileDetail);
		}

		validate(fileDoc);

		// 如有錯誤, 則回傳false
		if (fileDoc.isError()) {
			return false;
		}
		else {
			// 轉換檔案內容為可操作物件
			putData(fileDoc);

			if (fileDoc.isError()) {
				return false;
			}
			else {
				return true;
			}
		}
	}

	/**
	 * 取得FormatDetails
	 * 
	 * @param fieldGroup
	 * @return
	 */
	private List<FileFormatDetail> getFormatDetails(FieldGroup fieldGroup) {
		if (fieldGroup == null) {
			return null;
		}

		return detailGroup.get(fieldGroup);
	}

	/**
	 * 將上傳檔案依照換行符號切分
	 * 
	 * @param fileContent
	 * @return
	 */
	protected List<byte[]> getFileRecords(byte[] fileContent) {
		List<byte[]> fileRecords = null;
		if (contains(fileContent, LineSeparator.Windows.getBytes())) {
			fileRecords = split(fileContent, LineSeparator.Windows.getBytes());
		}
		else if (contains(fileContent, LineSeparator.Macintosh.getBytes())) {
			fileRecords = split(fileContent, LineSeparator.Macintosh.getBytes());
		}
		else if (contains(fileContent, LineSeparator.Unix.getBytes())) {
			fileRecords = split(fileContent, LineSeparator.Unix.getBytes());
		}
		else {
			fileRecords = new ArrayList<byte[]>();
			fileRecords.add(fileContent);
		}
		return fileRecords;
	}

	/**
	 * 將Excel上傳檔案轉成 List
	 * 
	 * @param fileContent
	 * @return
	 * @throws ActionException
	 */
	protected List<Row> getExcelFileRecords(byte[] fileContent) throws ActionException {

		List<Row> rows = new ArrayList<Row>();

		ActionException ex = null;

		// xls 格式
		try {

			rows = getXlsFileRecords(fileContent);
		}
		catch (OfficeXmlFileException e) {
			ex = getActionException(CibErrorCode.FILE_OPERATION_FAIL);
		}
		catch (IOException e) {
			ex = getActionException(CibErrorCode.FILE_OPERATION_FAIL);
		}
		catch (Exception e) {
			ex = getActionException(CibErrorCode.FILE_OPERATION_FAIL);
		}

		// xlsx 格式
		if (ex != null) {
			try {
				rows = getXlsxFileRecords(fileContent);
			}
			catch (POIXMLException e) {
				throw ex;
			}
			catch (IOException e) {
				throw ex;
			}
			catch (Exception e) {
				throw ex;
			}
		}

		return rows;
	}

	/**
	 * 
	 * @param fileContent
	 * @return
	 * @throws IOException
	 */
	private List<Row> getXlsxFileRecords(byte[] fileContent) throws IOException, POIXMLException {

		List<Row> rows = new ArrayList<Row>();

		InputStream inStream = new ByteArrayInputStream(fileContent);
		XSSFWorkbook workbook = new XSSFWorkbook(inStream);

		XSSFSheet sheet1 = workbook.getSheetAt(0);

		Iterator<Row> items = sheet1.rowIterator();

		while (items.hasNext()) {
			Row row = items.next();
			if (isNotEnd(row)) {
				rows.add(row);
			}
		}

		return rows;
	}

	/**
	 * 
	 * @param fileContent
	 * @return
	 * @throws IOException
	 */
	private List<Row> getXlsFileRecords(byte[] fileContent) throws IOException, OfficeXmlFileException {

		List<Row> rows = new ArrayList<Row>();

		InputStream inStream = new ByteArrayInputStream(fileContent);
		HSSFWorkbook workbook = new HSSFWorkbook(inStream);

		HSSFSheet sheet1 = workbook.getSheetAt(0);

		Iterator<Row> items = sheet1.rowIterator();

		while (items.hasNext()) {
			Row row = items.next();
			if (isNotEnd(row)) {
				rows.add(row);
			}
		}

		return rows;
	}

	/**
	 * TODO : 判斷 Excel Row 是否是有效的資料列(目前僅判斷前4個欄位是否為空值)
	 * 
	 * @param row
	 * @return
	 */
	private boolean isNotEnd(Row row) {

		if (StringUtils.isNotBlank(getCellvalue(row, 0)) || StringUtils.isNotBlank(getCellvalue(row, 1)) || StringUtils.isNotBlank(getCellvalue(row, 2)) || StringUtils.isNotBlank(getCellvalue(row, 3))) {
			return true;
		}
		return false;
	}

	/**
	 * 
	 * @return
	 */
	protected String getLineSeparator() {

		String OS = System.getProperty("os.name").toLowerCase();

		if (OS.indexOf("win") >= 0) {
			return LineSeparator.Windows;
		}
		else if (OS.indexOf("mac") >= 0) {
			return LineSeparator.Macintosh;
		}
		else if (OS.indexOf("nix") >= 0 || OS.indexOf("nux") >= 0 || OS.indexOf("aix") > 0) {
			return LineSeparator.Unix;
		}
		return "";
	}

	/**
	 * 
	 * @param data1
	 * @param data2
	 * @return
	 */
	protected byte[] concat(byte[] data1, byte[] data2) {

		byte[] result = new byte[data1.length + data2.length];
		System.arraycopy(data1, 0, result, 0, data1.length);
		System.arraycopy(data2, 0, result, data1.length, data2.length);
		return result;
	}

	/**
	 * Parse單筆
	 * 
	 * @param fileRecord
	 * @param formatDetails
	 * @return
	 */
	protected FileDetail getFileDetail(int rowNo, byte[] byteDetail, List<FileFormatDetail> headFormat, List<FileFormatDetail> cycleFormat) {

		FileDetail fileDetail = null;

		// format排序
		sortFormat(headFormat, cycleFormat);

		// 檢查長度
		if (!checkLength(byteDetail, headFormat, cycleFormat)) {

			// FileException exception = new FileException("長度不符",
			// CibErrorCode.FILE_DATA_LENGTH_NOT_MATCH);

			fileDetail = new FileDetail();

			// 行號
			fileDetail.setRowNo(rowNo);

			// fileDetail.setException(exception);
		}
		else {

			// parse資料
			fileDetail = parseDetail(rowNo, byteDetail, headFormat, cycleFormat);
		}

		return fileDetail;
	}

	/**
	 * format排序
	 * 
	 * @param formatHead
	 * @param formatCycle
	 */
	private void sortFormat(List<FileFormatDetail> formatHead, List<FileFormatDetail> formatCycle) {
		if (formatHead != null && formatHead.size() > 0) {
			// 對formatHead排序
			Collections.sort(formatHead, new FileFormatDetailComparator());
		}

		if (formatCycle != null && formatCycle.size() > 0) {
			// 對formatCycle排序
			Collections.sort(formatCycle, new FileFormatDetailComparator());
		}
	}

	/**
	 * 檢查長度
	 * 
	 * @param byteDetail
	 * @param formatHead
	 * @param formatCycle
	 * @return
	 */
	protected boolean checkLength(byte[] byteDetail, List<FileFormatDetail> formatHead, List<FileFormatDetail> formatCycle) {
		int lengthDetail = byteDetail.length;
		return checkLength(lengthDetail, formatHead, formatCycle);
	}

	/**
	 * 檢查長度
	 * 
	 * @param fileDetail
	 * @return
	 */
	protected boolean validateDetailLength(FileDetail fileDetail) {

		if (master.getFieldDelimiterType() == 3) {
			return true;
		}

		int lengthDetail = fileDetail.getLength();
		List<FileFormatDetail> formatHead = getFormatDetails(getFormatHead(fileDetail.getRowNo()));
		List<FileFormatDetail> formatCycle = getFormatDetails(getFormatCycle(fileDetail.getRowNo()));
		return checkLength(lengthDetail, formatHead, formatCycle);
	}

	/**
	 * 檢查長度
	 * 
	 * @param byteDetail
	 * @param formatHead
	 * @param formatCycle
	 * @return
	 */
	protected boolean checkLength(int lengthDetail, List<FileFormatDetail> formatHead, List<FileFormatDetail> formatCycle) {

		int lengthHead = getLength(formatHead);
		int lengthCycle = getLength(formatCycle);

		// 資料長度小於起始格式
		if (lengthDetail < lengthHead) {
			return false;
		}
		// 資料長度等於起始格式
		else if (lengthDetail == lengthHead) {
			return true;
		}
		// 資料長度大於起始格式
		else {
			lengthDetail = lengthDetail - lengthHead;

			// 檢查資料長度是否為循環格式的倍數

			// 無循環格式
			if (lengthCycle == 0) {
				// 有多餘資料長度
				return false;
			}
			// 有循環格式
			else {
				// 為循環格式倍數
				if (lengthDetail % lengthCycle == 0) {
					return true;
				}
				// 不為循環格式倍數
				else {
					return false;
				}
			}
		}
	}

	/**
	 * 檢查格式
	 * 
	 * @param fileDetail
	 * @return
	 */
	protected FileException validateDetailFormat(FileDetail fileDetail) {

		// FileException throwable = null;
		try {

			// int rowNo = fileDetail.getRowNo();

			// 2016/1/22:因為新增可設定「資料起始列」，用rowNo來抓取format的方式要調整一下
			// int formatRowNo = rowNo - (master.getStartRow() - 1);

			for (FileSection fileSection : fileDetail.getSections()) {

				// int sectionNo = fileSection.getSectionNo();
				// List<FileFormatDetail> formatDetails =
				// getFormatDetails(getFieldGroup(formatRowNo, sectionNo));
				List<FileFormatDetail> formatDetails = getFormatDetails(fileSection.getFieldGroup());
				for (FileFormatDetail formatDetail : formatDetails) {
					FileField fileField = fileSection.getField(formatDetail.getFieldId());
					/* 驗證錯誤時會抛出Exception */
					validateFieldFormat(formatDetail, fileField);
				}
			}
			return null;
		}
		catch (FileException e) {
			// e.printStackTrace();
			return e;
		}
	}

	/**
	 * 檢查格式
	 * 
	 * @param formatDetail
	 * @param field
	 * @throws FileException
	 */
	private void validateFieldFormat(FileFormatDetail formatDetail, FileField fileField) throws FileException {
		String value = fileField.getValue();

		if (value == null) {
			throw new FileException("格式不符", CibErrorCode.FILE_DATA_FORMAT_ERROR);
		}

		// 為空值時會判斷錯誤, 於此先過濾掉
		if (formatDetail.isNotChineseAndSpecialCharText() && value.length() == 0) {
			return;
		}

		String format = "^.*$";

		if (formatDetail.isText()) {
			/** 若為文字 **/
			format = "^.*$";
		}
		else if (formatDetail.isInteger()) {
			/** 若為整數 **/
			// 允許負數故修改
			format = "^(-)?\\d*$";
		}
		// 若為小數
		else if (formatDetail.isDouble()) {
			/** 允許負數故修改 **/
			format = "^(-)?\\d*(\\.\\d+)?$";
		}
		// 若為日期
		else if (formatDetail.isDate()) {
			// 要參考fileFormat內設定的日期格式檢核
			// 因fileField的getValue()已經有轉換過，這裡要檢查rawValue要另外取
			value = fileField.getRawValue();
			String dateFormat = master.getDateType();
			if (StringUtils.equals(dateFormat, "YYYYMMDD")) {
				format = "^(19|20)\\d\\d(0[1-9]|1[012])(0[1-9]|[12][0-9]|3[01])$";
			}
			else if (StringUtils.equals(dateFormat, "YYYY/MM/DD")) {
				format = "^(19|20)\\d\\d[/](0[1-9]|1[012])[/](0[1-9]|[12][0-9]|3[01])$";
			}
			else if (StringUtils.equals(dateFormat, "CCCCMMDD")) {
				format = "^\\d\\d\\d\\d(0[1-9]|1[012])(0[1-9]|[12][0-9]|3[01])$";
			}
			else if (StringUtils.equals(dateFormat, "CCCMMDD")) {
				format = "^\\d\\d\\d(0[1-9]|1[012])(0[1-9]|[12][0-9]|3[01])$";
			}
			else if (StringUtils.equals(dateFormat, "CCMMDD")) {
				format = "^\\d\\d(0[1-9]|1[012])(0[1-9]|[12][0-9]|3[01])$";
			}
		}
		else if (formatDetail.isNotChineseAndSpecialCharText()) {
			/* 不允為中文及不允許特殊字元 */
			format = "^[a-zA-Z0-9|\\/|\\?|\\(|\\)|\\{|\\}|\\.|\\,|\\'|\\+|\\s][a-zA-Z0-9|\\/|\\-|\\?|\\:|\\(|\\)|\\{|\\}|\\.|\\,|\\'|\\+|\\s]*$";
			// format =
			// "^[\\w|\\/|\\?|\\(|\\)|\\{|\\}|\\.|\\,|\\'|\\+|\\s][\\w|\\/|\\-|\\?|\\:|\\(|\\)|\\{|\\}|\\.|\\,|\\'|\\+|\\s]*$";
		}
		if (!value.matches(format)) {
			if (formatDetail.isDate()) {
				throw new FileException("日期格式不符", CibErrorCode.DATE_FORMAT_ERROR);
			}
			else if (formatDetail.isDouble()) {
				throw new FileException("小數格式不符", CibErrorCode.DOT_FORMAT_ERROR);
			}
			else if (formatDetail.isInteger()) {
				throw new FileException("整數格式不符", CibErrorCode.INTEGER_FORMAT_ERROR);
			}
			else if (formatDetail.isNotChineseAndSpecialCharText()) {
				throw new FileException("資料欄位不可為中文，包含非法字元", CibErrorCode.VALIDATE_FX_DETAIL_ERROR_5);
			}
			else {
				throw new FileException("格式不符", CibErrorCode.FILE_DATA_FORMAT_ERROR);
			}
		}

	}

	/**
	 * parse單行資料
	 * 
	 * 先parse起始格式 再parse循環格式
	 * 
	 * @param byteDetail
	 * @param formatHead
	 * @param formatCycle
	 * @return
	 */
	private FileDetail parseDetail(int rowNo, byte[] byteDetail, List<FileFormatDetail> formatHead, List<FileFormatDetail> formatCycle) {

		int lengthHead = getLength(formatHead);
		int lengthCycle = getLength(formatCycle);
		int lengthDetail = byteDetail.length;

		FileDetail fileDetail = new FileDetail();

		// 行號
		fileDetail.setRowNo(rowNo);

		// 長度
		fileDetail.setLength(lengthDetail);

		int sectionNo = 1;
		int pivot = 0;

		// parse起始格式
		byte[] byteHead = subArray(byteDetail, pivot, pivot + lengthHead);

		FileSection sectionHead = parseSection(sectionNo++, byteHead, formatHead);
		sectionHead.setFieldGroup(getFormatHead(rowNo));
		fileDetail.addSection(sectionHead);

		pivot += lengthHead;

		// parse循環格式
		while (pivot < lengthDetail) {

			byte[] byteCycle = subArray(byteDetail, pivot, pivot + lengthCycle);

			FileSection sectionCycle = parseSection(sectionNo++, byteCycle, formatCycle);
			sectionCycle.setFieldGroup(getFormatCycle(rowNo));
			fileDetail.addSection(sectionCycle);

			pivot += lengthCycle;
		}

		return fileDetail;
	}

	/**
	 * parse資料區段
	 * 
	 * @param byteSection
	 * @param formatSection
	 * @return
	 */
	private FileSection parseSection(int sectionNo, byte[] byteSection, List<FileFormatDetail> formatSection) {

		FileSection fileSection = new FileSection();

		// 段號
		fileSection.setSectionNo(sectionNo);

		int pivot = 0;

		for (FileFormatDetail formatDetail : formatSection) {

			byte[] byteField = subArray(byteSection, pivot, pivot + formatDetail.getLength());

			// 將byte陣列轉換為字串
			String value = ConvertUtils.bytes2Str(byteField, getReadFromEncoding());

			FileField fileField = new FileField();

			// 欄號
			fileField.setColumnNo(formatDetail.getOrderNo());

			// 欄位Id
			fileField.setFieldId(formatDetail.getFieldId());

			// 欄位值
			fileField.setValue(value);

			fileSection.addField(fileField);

			pivot += formatDetail.getLength();
		}

		return fileSection;
	}

	/**
	 * 計算格式長度
	 * 
	 * @param formatDetails
	 * @return
	 */
	protected int getLength(List<FileFormatDetail> formatDetails) {
		int length = 0;

		if (formatDetails == null) {
			return length;
		}

		for (FileFormatDetail formatDetail : formatDetails) {
			length += formatDetail.getLength();
		}

		return length;
	}

	/**
	 * 將byte陣列依據separator切成多個byte陣列
	 * 
	 * @param array
	 * @param separator
	 * @return
	 */
	private List<byte[]> split(byte[] array, byte[] separator) {
		List<byte[]> list = new ArrayList<byte[]>();
		int index = indexOf(array, separator);
		while (index >= 0) {
			byte[] subArray = subArray(array, 0, index);
			array = subArray(array, index + separator.length);
			index = indexOf(array, separator);

			list.add(subArray);
		}

		if (array.length > 0) {
			list.add(array);
		}
		return list;
	}

	/**
	 * 搜尋目標陣列在byte陣列中出現的index
	 * 
	 * 若不包含則回傳-1
	 * 
	 * @param array
	 * @param search
	 * @return
	 */
	private int indexOf(byte[] array, byte[] search) {
		for (int i = search.length; i <= array.length; i++) {
			byte[] subArray = subArray(array, i - search.length, i);
			if (equals(subArray, search)) {
				return i - search.length;
			}
		}
		return -1;
	}

	/**
	 * 搜尋byte陣列是否包含目標陣列
	 * 
	 * @param array
	 * @param search
	 * @return
	 */
	private boolean contains(byte[] array, byte[] search) {
		return indexOf(array, search) != -1;
	}

	/**
	 * 取得byte陣列的子陣列
	 * 
	 * @param array
	 * @param start
	 * @return
	 */
	protected byte[] subArray(byte[] array, int start) {
		return subArray(array, start, array.length);
	}

	/**
	 * 取得byte陣列的子陣列
	 * 
	 * @param array
	 * @param start
	 * @param end
	 * @return
	 */
	protected byte[] subArray(byte[] array, int start, int end) {
		int length = end - start;

		if (length <= 0) {
			return new byte[0];
		}

		byte[] subArray = new byte[length];
		for (int i = 0; i < length; i++) {
			subArray[i] = array[i + start];
		}
		return subArray;
	}

	/**
	 * 比較兩byte陣列是否相同
	 * 
	 * @param array1
	 * @param array2
	 * @return
	 */
	private boolean equals(byte[] array1, byte[] array2) {
		if (array1.length != array2.length) {
			return false;
		}
		for (int i = 0; i < array1.length; i++) {
			if (array1[i] != array2[i]) {
				return false;
			}
		}
		return true;
	}

	/**
	 * validate檔案。2016/1/25: 舊的validate不適用於parseFileEx，改用validateEx
	 * 
	 * @param fileContent
	 * @throws ActionException
	 */
	private void validateEx(FileDoc fileDoc) throws ActionException {

		FileDetail firstDetail = fileDoc.getFirstDetail();
		// FileDetail firstDetail = fileDoc.getDetail(master.getStartRow());
		// FileDetail lastDetail = fileDoc.getLastDetail();

		// int lastDetailRowNo = fileDoc.getLastDetailRowNo();

		/** 首筆檢查,當null時表示正確 **/
		FileException throwable = validateDetailFormat(firstDetail);
		if (throwable != null) {
			firstDetail.setException(throwable);
			throw throwable;
		}

		// 檢查資料筆數
		validateDetailSize(fileDoc);

		for (FileDetail fileDetail : fileDoc.getDetails()) {
			// 檢查長度
			if (!validateDetailLength(fileDetail)) {
				// 將錯誤放入fileDetail, 以便顯示逐筆錯誤
				ActionException e = getActionException(CibErrorCode.FILE_DATA_LENGTH_NOT_MATCH);
				fileDetail.setException(e);
			}

			if (fileDetail.isError()) {
				// 若此處有錯，是由parser而來的錯誤，不在進入逐筆內容檢核
				// TODO : parse 異常不拋出 Excception, 同樣於上傳結果頁顯示
				// ActionException e = fileDetail.getError();
				// throw e;
			}
			else {
				try {
					/** 仍要檢查格式,當null時表示正確,錯誤時寫入Exception **/
					throwable = validateDetailFormat(fileDetail);
					if (throwable != null) {
						fileDetail.setException(throwable);
					}
					if (fileDetail.isError() == false) {
						/** 當沒錯誤時才做 **/
						validateDetailContent(fileDetail);
					}
				}
				catch (ActionException e) {
					fileDetail.setException(e);
				}
			}

		}

		// 客製化檢查
		validateCustom(fileDoc);

	}

	/**
	 * validate檔案。2016/1/25:
	 * 舊的validate不適用於parseFileEx，因為Length檢查等細節無法放在FileFormatNew之中
	 * ，而是放在FileHandlerDelim/FixLen裡面。
	 * 
	 * @param fileContent
	 * @throws ActionException
	 */
	private void validate(FileDoc fileDoc) throws ActionException {

		FileDetail firstDetail = fileDoc.getFirstDetail();

		// FileDetail lastDetail = fileDoc.getLastDetail();

		// int lastDetailRowNo = fileDoc.getLastDetailRowNo();

		// 檢查第一筆長度
		if (!validateDetailLength(firstDetail)) {
			ActionException e = getActionException(CibErrorCode.FILE_DATA_LENGTH_NOT_MATCH);
			firstDetail.setException(e);
			throw e;
		}

		// 檢查第一筆資料格式
		FileException throwable = validateDetailFormat(firstDetail);
		if (throwable != null) {
			ActionException e = getActionException(CibErrorCode.FILE_DATA_FORMAT_ERROR);
			firstDetail.setException(e);
			throw e;
		}

		// 檢查資料筆數
		validateDetailSize(fileDoc);

		for (FileDetail fileDetail : fileDoc.getDetails()) {

			// 檢查長度
			if (!validateDetailLength(fileDetail)) {
				// 將錯誤放入fileDetail, 以便顯示逐筆錯誤
				ActionException e = getActionException(CibErrorCode.FILE_DATA_LENGTH_NOT_MATCH);
				throw e;
			}
			else {
				try {
					// 逐筆內容檢核
					validateDetailContent(fileDetail);
				}
				catch (ActionException e) {
					fileDetail.setException(e);
				}
			}

		}

		// 客製化檢查
		validateCustom(fileDoc);

	}

	/**
	 * 檢核資料筆數
	 * 
	 * @param fileDoc
	 */
	abstract protected void validateDetailSize(FileDoc fileDoc) throws ActionException;

	/**
	 * 客製化檢核
	 * 
	 * @param fileDoc
	 * @throws ActionException
	 */
	abstract protected void validateCustom(FileDoc fileDoc) throws ActionException;

	/**
	 * 內容檢核
	 * 
	 * @param fileDetail
	 * @throws ActionException
	 */
	abstract protected void validateDetailContent(FileDetail fileDetail) throws ActionException;

	/**
	 * 轉換檔案內容為可操作物件
	 * 
	 * @param fileDoc
	 */
	abstract protected void putData(FileDoc fileDoc);

	/**
	 * 將CibErrorCode轉為ActionException
	 * 
	 * @param errorCode
	 * @return
	 */
	protected ActionException getActionException(CibErrorCode errorCode) {
		ActionException e = new ActionException(errorCode.getSystemId(), errorCode.getErrorCode(), ICommonCode.SEVERITY_ERROR, errorCode.getMemo());
		return e;
	}

	/**
	 * 組成 字串資料
	 * 
	 * @param detail
	 * @return
	 * @throws ActionException
	 * @throws UnsupportedEncodingException
	 */
	protected byte[] detailStringData(FileDetail detail) throws ActionException, UnsupportedEncodingException {

		byte[] result = new byte[0];

		for (FileSection section : detail.getSections()) {

			List<FileFormatDetail> fileFormatDetails = detailGroup.get(section.getFieldGroup());

			int length = getFixTypeLimitLength(fileFormatDetails);
			result = StringUtils.repeat(" ", length).getBytes(getReadFromEncoding());
			for (FileFormatDetail fileFormatDetail : fileFormatDetails) {
				String fieldvalue = valueToString(fileFormatDetail, section.getField(fileFormatDetail.getFieldId()));

				// 數值型態
				if (fileFormatDetail.isInteger() || fileFormatDetail.isDouble()) {
					fieldvalue = StringUtils.leftPad(fieldvalue, fileFormatDetail.getLength(), "0");
				}
				else if (fileFormatDetail.isChineseAndSpecialCharText()) {

					fieldvalue = CosmosUtils.rightPadByte(fieldvalue, fileFormatDetail.getLength(), ' ', getReadFromEncoding());

				}
				else {

					fieldvalue = StringUtils.rightPad(fieldvalue, fileFormatDetail.getLength(), " ");
				}

				byte[] fieldBuf = fieldvalue.getBytes(getReadFromEncoding());

				// 替換
				int pos = fileFormatDetail.getStartPos() - 1;
				System.arraycopy(fieldBuf, 0, result, pos, fileFormatDetail.getLength());
			}

		}
		return result;
	}

	protected String getReadFromEncoding() {
		return ENCODING;
	}

	/**
	 * 取得固定方式最短的資料長度
	 * 
	 * @param formatDetails
	 * @return
	 */
	protected int getFixTypeLimitLength(List<FileFormatDetail> formatDetails) {

		int maxOrderNo = 0;
		int limitLength = 0;

		for (FileFormatDetail formatDetail : formatDetails) {
			if (formatDetail.getOrderNo() > maxOrderNo) {
				maxOrderNo = formatDetail.getOrderNo();
				limitLength = formatDetail.getStartPos() + formatDetail.getLength();
			}
		}
		return limitLength - 1;
	}

	/**
	 * 資料轉換
	 * 
	 * @param formatDetail
	 * @param fileField
	 * @throws ActionException
	 */
	private String valueToString(FileFormatDetail formatDetail, FileField fileField) throws ActionException {

		if (fileField == null) {
			return "";
		}

		Object value = fileField.getValue();

		String result = "";

		if (value == null) {
			result = "";
		}
		else if (formatDetail.isInteger()) {
			/** 若為整數 **/
			result = String.valueOf(value);
		}
		else if (formatDetail.isDouble()) {
			/** 若為小數 **/
			BigDecimal bdValue = ConvertUtils.str2BigDecimal(String.valueOf(value));
			bdValue = bdValue.setScale(formatDetail.getDecLength());
			result = String.valueOf(bdValue);
			if (formatDetail.getAmtType() == 2) {
				result = StringUtils.replace(result, ".", "");
			}
		}
		// 日期
		// else if (formatDetail.isDate()) {
		// result = dateToString((Date)value, master.getDateType());
		// }
		else {
			result = (String) value;
		}

		return result;
	}

	/**
	 * 取得 Cell String Value *
	 * 
	 * @author hank
	 * @param row
	 * @param iPos
	 * @return
	 */
	private String getCellvalue(Row row, int iPos) {

		String sRtn = "";

		if (row.getCell(iPos) == null) {
			return "";
		}

		try {

			if (HSSFCell.CELL_TYPE_STRING == row.getCell(iPos).getCellType()) {
				sRtn = row.getCell(iPos).getStringCellValue();
			}
			else if (HSSFCell.CELL_TYPE_FORMULA == row.getCell(iPos).getCellType()) {
				sRtn = row.getCell(iPos).getRichStringCellValue().toString();
			}
			else if (HSSFCell.CELL_TYPE_BLANK == row.getCell(iPos).getCellType()) {
				sRtn = "";
			}
			else {
				String sDateFormat = row.getCell(iPos).getCellStyle().getDataFormatString();
				if ("yyyymmdd".equals(sDateFormat)) {
					sRtn = new java.text.SimpleDateFormat("yyyyMMdd").format(row.getCell(iPos).getDateCellValue());

				}
				else if ("m/d/yy".equals(sDateFormat)) {
					sRtn = new java.text.SimpleDateFormat("yyyyMMdd").format(row.getCell(iPos).getDateCellValue());
				}
				else {
					sRtn = String.valueOf(row.getCell(iPos).getNumericCellValue());
				}

				sRtn = reFormat(sRtn);

			}

		}
		catch (Exception e) {
			System.out.println("column at " + iPos + "," + e);
		}
		return sRtn;
	}

	/**
	 * 
	 * 去除小數後面的 .0 及 E
	 * 
	 * ex: reFormat("1000.0") => 1000 reFormat("1.211241E6") => 1211241
	 * 
	 * @author hank
	 * @param sSrc
	 * @return
	 */
	private String reFormat(String sSrc) {

		int iPos = sSrc.indexOf(".");
		int iPos2 = sSrc.indexOf("E");

		if (iPos > 0) {

			if (iPos2 > 0) {

				int iLen = Integer.parseInt(sSrc.substring(iPos2 + 1));
				String sStr = sSrc.substring(iPos + 1, iPos2);
				sStr = StringUtils.rightPad(sStr, iLen, "0");
				sSrc = sSrc.substring(0, iPos) + sStr;

			}
			else {
				int iValue = Integer.parseInt(sSrc.substring(iPos + 1));

				if (iValue == 0) {
					sSrc = sSrc.substring(0, iPos);
				}
			}

		}
		return sSrc;
	}

	/**
	 * 取得檔案行數
	 * 
	 * @return 傳回 rows
	 */
	public int getRows() {
		return rows;
	}
}
