/*
 * ===========================================================================
 * IBM Confidential
 * AIS Source Materials
 * 
 * 
 * (C) Copyright IBM Corp. 2011.
 *
 * ===========================================================================
 */
package com.cosmos.file.ext;

import com.cosmos.file.bo.FileField;
import com.cosmos.file.bo.FileSection;
import com.ibm.tw.commons.util.StringUtils;

/**
 * <p>
 * CommonPayee File Section
 * </p>
 * 
 * @author Leo
 * @version 1.0, 2011/6/27
 * @see
 * @since
 */
public class CACTX601ExcelFileSection {

	/** 檔案區段 */
	private FileSection fileSection;

	public CACTX601ExcelFileSection(FileSection fileSection) {
		this.fileSection = fileSection;
	}

	/**
	 * 收受行代號
	 * 
	 * @return
	 */
	public String getRBank() {
		FileField fileField = fileSection.getField("rBank");
		if (fileField == null) {
			return null;
		}
		else {
			return StringUtils.trim(fileField.getValue());
		}
	}

	/**
	 * 委繳戶帳號
	 * 
	 * @return
	 */
	public String getRClno() {
		FileField fileField = fileSection.getField("rClno");
		if (fileField == null) {
			return null;
		}
		else {
			return StringUtils.trim(fileField.getValue());
		}
	}

	/**
	 * 收受者統一編號
	 * 
	 * @return
	 */
	public String getPId() {
		FileField fileField = fileSection.getField("pId");
		if (fileField == null) {
			return null;
		}
		else {
			return StringUtils.trim(fileField.getValue());
		}
	}

	/**
	 * 扣款上限
	 * 
	 * @return
	 */
	public String getTxAmt() {
		FileField fileField = fileSection.getField("txAmt");
		if (fileField == null) {
			return null;
		}
		else {
			return StringUtils.trim(fileField.getValue());
		}
	}

	/**
	 * 用戶號碼
	 * 
	 * @return
	 */
	public String getCNo() {
		FileField fileField = fileSection.getField("cNo");
		if (fileField == null) {
			return null;
		}
		else {
			return StringUtils.trim(fileField.getValue());
		}
	}

	/**
	 * 公司股市代號 reMark
	 * 
	 * @return
	 */
	public String getReMark() {
		FileField fileField = fileSection.getField("reMark");
		if (fileField == null) {
			return null;
		}
		else {
			return StringUtils.trim(fileField.getValue());
		}
	}

	/**
	 * 發動者專用區
	 * 
	 * @return
	 */
	public String getNote() {
		FileField fileField = fileSection.getField("note");
		if (fileField == null) {
			return null;
		}
		else {
			return StringUtils.trim(fileField.getValue());
		}
	}

	/**
	 * 查詢專用區
	 * 
	 * @return
	 */
	public String getFiller() {
		FileField fileField = fileSection.getField("filler");
		if (fileField == null) {
			return null;
		}
		else {
			return fileField.getValue();
		}
	}

	/**
	 * 存摺摘要欄
	 * 
	 * @return
	 */
	public String getMemo() {
		FileField fileField = fileSection.getField("memo");
		if (fileField == null) {
			return null;
		}
		else {
			return StringUtils.trim(fileField.getValue());
		}
	}

	/**
	 * 客戶支付手續費cfee
	 * 
	 * @return
	 */
	public String getCfee() {
		FileField fileField = fileSection.getField("cfee");
		if (fileField == null) {
			return null;
		}
		else {
			return StringUtils.trim(fileField.getValue());
		}
	}

}
