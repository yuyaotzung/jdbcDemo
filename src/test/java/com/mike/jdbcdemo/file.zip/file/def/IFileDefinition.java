/*
 * ===========================================================================
 * IBM Confidential
 * AIS Source Materials
 * 
 * 
 * (C) Copyright IBM Corp. 2018.
 *
 * ===========================================================================
 */
package com.cosmos.file.def;



/**
 * <p> 共用檔案定義格式</p>
 *
 * @author  monica
 * @version 1.0, Feb 22, 2018
 * @see	    
 * @since 
 */
public interface IFileDefinition {
	
	public String getId();

	public int getType();

	public int getLength();
	
	public int getRequired();

	public String getName();
	
	public String getColumnName();

}



 