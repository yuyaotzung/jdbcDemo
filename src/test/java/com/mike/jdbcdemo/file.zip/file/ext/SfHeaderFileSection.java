/*
 * ===========================================================================
 * IBM Confidential
 * AIS Source Materials
 * 
 * 
 * (C) Copyright IBM Corp. 2016.
 *
 * ===========================================================================
 */
package com.cosmos.file.ext;

import com.cosmos.file.bo.FileField;
import com.cosmos.file.bo.FileSection;
import com.cosmos.type.FieldGroup;
import com.ibm.tw.commons.util.StringUtils;

/**
 * <p>
 * 外幣自行授權扣帳檔案上傳檔案 首筆資料
 * </p>
 * 
 * @author Bear
 * @version 1.0, Sep 8, 2016
 * @see
 * @since
 */
public class SfHeaderFileSection {

	/** 檔案區段 */
	private FileSection fileSection;

	public SfHeaderFileSection(FileSection fileSection) {
		this.fileSection = fileSection;
	}

	public SfHeaderFileSection(FieldGroup fieldGroup) {
		fileSection = new FileSection();
		fileSection.setFieldGroup(fieldGroup);
	}

	/**
	 * 發動者統編1
	 * 
	 * @return
	 */
	public String getHeaderUid() {
		FileField fileField = fileSection.getField("headerUid");
		if (fileField == null) {
			return null;
		}
		else {
			return StringUtils.trim(fileField.getValue());
		}
	}

	/**
	 * 設定發動者統編
	 * 
	 * @param value
	 */
	public void setHeaderUid(String value) {
		setValue("headerUid", value);
	}

	/**
	 * 轉帳總筆數
	 * 
	 * @return
	 */
	public String getCount() {
		FileField fileField = fileSection.getField("headerCount");
		if (fileField == null) {
			return null;
		}
		else {
			return StringUtils.trim(fileField.getValue());
		}
	}

	/**
	 * 設定轉帳總筆數
	 * 
	 * @param value
	 */
	public void setCount(String value) {
		setValue("headerCount", value);
	}

	/**
	 * 交易日期
	 * 
	 * @return
	 */
	public String getTxDate() {
		FileField fileField = fileSection.getField("headerTxDate");
		if (fileField == null) {
			return null;
		}
		else {
			return fileField.getValue();
		}
	}

	/**
	 * 設定交易日期
	 * 
	 * @param value
	 */
	public void setTxDate(String value) {
		setValue("headerTxDate", value);
	}

	/**
	 * 交易金額
	 * 
	 * @return
	 */
	public String getTxAmt() {
		FileField fileField = fileSection.getField("headerTxAmt");
		if (fileField == null) {
			return null;
		}
		else {
			return fileField.getValue();
		}
	}

	/**
	 * 設定 交易金額
	 * 
	 * @param value
	 */
	public void setTxAmt(String value) {
		setValue("headerTxAmt", value);
	}

	/**
	 * 交易金額幣別
	 * 
	 * @return
	 */
	public String getTxCcy() {
		FileField fileField = fileSection.getField("headerTxCcy");
		if (fileField == null) {
			return null;
		}
		else {
			return fileField.getValue();
		}
	}

	/**
	 * 設定 交易金額幣別
	 * 
	 * @param value
	 */
	public void setTxCcy(String value) {
		setValue("headerTxCcy", value);
	}

	public FileSection getFileSection() {
		return fileSection;
	}

	/**
	 * 
	 * @param fieldId
	 * @param value
	 */
	private void setValue(String fieldId, String value) {

		if (fileSection == null) {
			fileSection = new FileSection();
		}

		FileField field = fileSection.getField(fieldId);
		if (field == null) {
			field = new FileField();
			field.setFieldId(fieldId);
			field.setValue(value);
			fileSection.addField(field);
		}
		else {
			field.setValue(value);
		}
	}
}
