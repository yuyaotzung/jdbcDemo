/*
 * ===========================================================================
 * IBM Confidential
 * AIS Source Materials
 * 
 * 
 * (C) Copyright IBM Corp. 2018.
 *
 * ===========================================================================
 */
package com.cosmos.file.ext;

import com.cosmos.file.bo.FileField;
import com.cosmos.file.bo.FileSection;
import com.cosmos.file.def.Cactx502Result12NTxFileDefinition;
import com.cosmos.file.def.Cactx502ResultN2NTxFileDefinition;
import com.cosmos.file.def.IFileDefinition;
import com.cosmos.type.FieldGroup;
import com.ibm.tw.commons.util.StringUtils;

/**
 * <p>
 * 外幣整批多扣多入 Tx格式
 * </p>
 * 
 * @author Bear
 * @version 1.0, 2018/7/12
 * @see
 * @since
 */
public class Cactx502ResultN2NTxFileSection {

	/** 檔案區段 */
	private FileSection fileSection;

	public Cactx502ResultN2NTxFileSection() {
		fileSection = new FileSection();
		fileSection.setFieldGroup(FieldGroup.TX);
		// 為了與畫面parse一致,讀入資料的secNo由1開始
		fileSection.setSectionNo(1);
	}

	public Cactx502ResultN2NTxFileSection(FileSection fileSection) {
		this.fileSection = fileSection;
	}

	public FileSection getFileSection() {
		return fileSection;
	}

	/**
	 * 批號PBMT-BATCH-NO
	 * 
	 * @return
	 */
	public String getBatchNo() {
		return getValue(Cactx502ResultN2NTxFileDefinition.BATCH_NO);
	}

	/**
	 * 批號PBMT-BATCH-NO
	 * 
	 * @param value
	 */
	public void setBatchNo(String value) {
		setValue(Cactx502ResultN2NTxFileDefinition.BATCH_NO, value);
	}

	/**
	 * 流水號
	 * 
	 * @return
	 */
	public String getSerno() {
		return getValue(Cactx502ResultN2NTxFileDefinition.SERNO);
	}

	/**
	 * 流水號
	 * 
	 * @param value
	 */
	public void setSerno(String value) {
		setValue(Cactx502ResultN2NTxFileDefinition.SERNO, value);
	}

	/**
	 * 付款通路
	 * 
	 * @return
	 */
	public String getPayChanel() {
		return getValue(Cactx502ResultN2NTxFileDefinition.PAY_CHANEL);
	}

	/**
	 * 付款通路
	 * 
	 * @param value
	 */
	public void setPayChanel(String value) {
		setValue(Cactx502ResultN2NTxFileDefinition.PAY_CHANEL, value);
	}

	/**
	 * 付款人帳號
	 * 
	 * @return
	 */
	public String getPayerAccountNo() {
		return getValue(Cactx502ResultN2NTxFileDefinition.PAYER_ACCOUNT_NO);
	}

	/**
	 * 付款人帳號
	 * 
	 * @param value
	 */
	public void setPayerAccountNo(String value) {
		setValue(Cactx502ResultN2NTxFileDefinition.PAYER_ACCOUNT_NO, value);
	}

	/**
	 * 付款人戶名
	 * 
	 * @return
	 */
	public String getPayerName() {
		return getValue(Cactx502ResultN2NTxFileDefinition.PAYER_NAME);
	}

	/**
	 * 付款人戶名
	 * 
	 * @param value
	 */
	public void setPayerName(String value) {
		setValue(Cactx502ResultN2NTxFileDefinition.PAYER_NAME, value);
	}

	/**
	 * 收款銀行代號
	 * 
	 * @return
	 */
	public String getReceiveBankCode() {
		return getValue(Cactx502ResultN2NTxFileDefinition.RECEIVE_BANK_CODE);
	}

	/**
	 * 收款銀行代號
	 * 
	 * @param value
	 */
	public void setReceiveBankCode(String value) {
		setValue(Cactx502ResultN2NTxFileDefinition.RECEIVE_BANK_CODE, value);
	}

	/**
	 * 轉入帳號
	 * 
	 * @return
	 */
	public String getRollInAcct() {
		return getValue(Cactx502ResultN2NTxFileDefinition.ROLL_IN_ACCT);
	}

	/**
	 * 轉入帳號
	 * 
	 * @param value
	 */
	public void setRollInAcct(String value) {
		setValue(Cactx502ResultN2NTxFileDefinition.ROLL_IN_ACCT, value);
	}

	/**
	 * 交易金額
	 * 
	 * @return
	 */
	public String getAmount() {
		return getValue(Cactx502ResultN2NTxFileDefinition.AMOUNT);
	}

	/**
	 * 交易金額
	 * 
	 * @param value
	 */
	public void setAmount(String value) {
		setValue(Cactx502ResultN2NTxFileDefinition.AMOUNT, value);
	}

	/**
	 * 提示碼
	 * 
	 * @return
	 */
	public String getPromoCode() {
		return getValue(Cactx502ResultN2NTxFileDefinition.PROMO_CODE);
	}

	/**
	 * 提示碼
	 * 
	 * @param value
	 */
	public void setPromoCode(String value) {
		setValue(Cactx502ResultN2NTxFileDefinition.PROMO_CODE, value);
	}

	/**
	 * 存摺附註
	 * 
	 * @return
	 */
	public String getRemarks() {
		return getValue(Cactx502ResultN2NTxFileDefinition.REMARKS);
	}

	/**
	 * 存摺附註
	 * 
	 * @param value
	 */
	public void setRemarks(String value) {
		setValue(Cactx502ResultN2NTxFileDefinition.REMARKS, value);
	}


	/**
	 * 收款人戶名
	 * 
	 * @return
	 */
	public String getPayeeName() {
		return getValue(Cactx502ResultN2NTxFileDefinition.PAYEE_NAME);
	}

	/**
	 * 收款人戶名
	 * 
	 * @param value
	 */
	public void setPayeeName(String value) {
		setValue(Cactx502ResultN2NTxFileDefinition.PAYEE_NAME, value);
	}

	/**
	 * 櫃員手續費/匯款手續費
	 * 
	 * @return
	 */
	public String getFee() {
		return getValue(Cactx502ResultN2NTxFileDefinition.FEE);
	}

	/**
	 * 櫃員手續費/匯款手續費
	 * 
	 * @param value
	 */
	public void setFee(String value) {
		setValue(Cactx502ResultN2NTxFileDefinition.FEE, value);
	}

	/**
	 * 附言
	 * 
	 * @return
	 */
	public String getPostScript() {
		return getValue(Cactx502ResultN2NTxFileDefinition.POST_SCRIPT);
	}

	/**
	 * 附言
	 * 
	 * @param value
	 */
	public void setPostScript(String value) {
		setValue(Cactx502ResultN2NTxFileDefinition.POST_SCRIPT, value);
	}

	/**
	 * BaNCS中心執行結果BANCS-STAT
	 * 
	 * @return
	 */
	public String getBancsStat() {
		return getValue(Cactx502ResultN2NTxFileDefinition.BANCS_STAT);
	}

	/**
	 * BaNCS中心執行結果BANCS-STAT
	 * 
	 * @param value
	 */
	public void setBancsStat(String value) {
		setValue(Cactx502ResultN2NTxFileDefinition.BANCS_STAT, value);
	}

	/**
	 * 匯款處理結果
	 * 
	 * @return
	 */
	public String getNefxStat() {
		return getValue(Cactx502ResultN2NTxFileDefinition.NEFX_STAT);
	}

	/**
	 * 匯款處理結果
	 * 
	 * @param value
	 */
	public void setNefxStat(String value) {
		setValue(Cactx502ResultN2NTxFileDefinition.NEFX_STAT, value);
	}
	
	/**
	 * ESB_STAT
	 * 
	 * @return
	 */
	public String getEsbStat() {
		return getValue(Cactx502ResultN2NTxFileDefinition.ESB_STAT);
	}

	/**
	 * ESB_STAT
	 * 
	 * @param value
	 */
	public void setEsbStat(String value) {
		setValue(Cactx502ResultN2NTxFileDefinition.ESB_STAT, value);
	}
	
	/**
	 * TBB_STAT代收付狀態
	 * 
	 * @return
	 */
	public String getTbbStat() {
		return getValue(Cactx502ResultN2NTxFileDefinition.TBB_STAT);
	}

	/**
	 * TBB_STAT代收付狀態
	 * 
	 * @param value
	 */
	public void setTbbStat(String value) {
		setValue(Cactx502ResultN2NTxFileDefinition.TBB_STAT, value);
	}
	

	/**
	 * 交易序號
	 * 
	 * @return
	 */
	public String getJrnlNo() {
		return getValue(Cactx502ResultN2NTxFileDefinition.JRNL_NO);
	}

	/**
	 * 交易序號
	 * 
	 * @param value
	 */
	public void setJrnlNo(String value) {
		setValue(Cactx502ResultN2NTxFileDefinition.JRNL_NO, value);
	}

	/**
	 * 付款帳號幣別
	 * 
	 * @return
	 */
	public String getPayAcctCurrcode() {
		return getValue(Cactx502ResultN2NTxFileDefinition.PAY_ACCT_CURRCODE);
	}

	/**
	 * 付款帳號幣別
	 * 
	 * @param value
	 */
	public void setPayAcctCurrcode(String value) {
		setValue(Cactx502ResultN2NTxFileDefinition.PAY_ACCT_CURRCODE, value);
	}

	/**
	 * 轉出匯率類型
	 * 
	 * @return
	 */
	public String getRateType1() {
		return getValue(Cactx502ResultN2NTxFileDefinition.RateType1);
	}

	/**
	 * 轉出匯率類型
	 * 
	 * @param value
	 */
	public void setRateType1(String value) {
		setValue(Cactx502ResultN2NTxFileDefinition.RateType1, value);
	}

	/**
	 * 匯款分類一1
	 * 
	 * @return
	 */
	public String getCBRClass1() {
		return getValue(Cactx502ResultN2NTxFileDefinition.CBRClass1);
	}

	/**
	 * 匯款分類一1
	 * 
	 * @param value
	 */
	public void setCBRClass1(String value) {
		setValue(Cactx502ResultN2NTxFileDefinition.CBRClass1, value);
	}

	/**
	 * 匯款分類細項
	 * 
	 * @return
	 */
	public String getSourceOfFundSub() {
		return getValue(Cactx502ResultN2NTxFileDefinition.sourceOfFundSub);
	}

	/**
	 * 匯款分類細項
	 * 
	 * @param value
	 */
	public void setSourceOfFundSub(String value) {
		setValue(Cactx502ResultN2NTxFileDefinition.sourceOfFundSub, value);
	}

	/**
	 * 匯款分類69x細分類1
	 * 
	 * @return
	 */
	public String getCBRSubCode1() {
		return getValue(Cactx502ResultN2NTxFileDefinition.CBRSubCode1);
	}

	/**
	 * 匯款分類69x細分類1
	 * 
	 * @param value
	 */
	public void setCBRSubCode1(String value) {
		setValue(Cactx502ResultN2NTxFileDefinition.CBRSubCode1, value);
	}

	/**
	 * 申報註記1
	 * 
	 * @return
	 */
	public String getCbrreq1() {
		return getValue(Cactx502ResultN2NTxFileDefinition.CBRREQ1);
	}

	/**
	 * 申報註記1
	 * 
	 * @param value
	 */
	public void setCbrreq1(String value) {
		setValue(Cactx502ResultN2NTxFileDefinition.CBRREQ1, value);
	}

	/**
	 * 交易類型1
	 * 
	 * @return
	 */
	public String getCBRTxnType1() {
		return getValue(Cactx502ResultN2NTxFileDefinition.CBRTxnType1);
	}

	/**
	 * 交易類型1
	 * 
	 * @param value
	 */
	public void setCBRTxnType1(String value) {
		setValue(Cactx502ResultN2NTxFileDefinition.CBRTxnType1, value);
	}
	
	/**
	 * 付款人國別1
	 * 
	 * @return
	 */
	public String getCBRCountry1() {
		return getValue(Cactx502ResultN2NTxFileDefinition.CBRCountry1);
	}

	/**
	 * 付款人國別1
	 * 
	 * @param value
	 */
	public void setCBRCountry1(String value) {
		setValue(Cactx502ResultN2NTxFileDefinition.CBRCountry1, value);
	}

	/**
	 * 轉帳-收款人國別,匯款-匯款地國別
	 * 
	 * @return
	 */
	public String getCbrCountry2() {
		return getValue(Cactx502ResultN2NTxFileDefinition.CBRCountry2);
	}

	/**
	 * 轉帳-收款人國別,匯款-匯款地國別
	 * 
	 * @param value
	 */
	public void setCbrCountry2(String value) {
		setValue(Cactx502ResultN2NTxFileDefinition.CBRCountry2, value);
	}

	/**
	 * 申報註記2
	 * 
	 * @return
	 */
	public String getCbrReq2() {
		return getValue(Cactx502ResultN2NTxFileDefinition.CBRREQ2);
	}

	/**
	 * 申報註記2
	 * 
	 * @param value
	 */
	public void setCbrReq2(String value) {
		setValue(Cactx502ResultN2NTxFileDefinition.CBRREQ2, value);
	}


	/**
	 * 交易編號
	 * 
	 * @return
	 */
	public String getTxntNo() {
		return getValue(Cactx502ResultN2NTxFileDefinition.TxntNo);
	}

	/**
	 * 交易編號
	 * 
	 * @param value
	 */
	public void setTxntNo(String value) {
		setValue(Cactx502ResultN2NTxFileDefinition.TxntNo, value);
	}

	
	/**
	 * 受款銀行名稱
	 * 
	 * @return
	 */
	public String getPayeeBankName() {
		return getValue(Cactx502ResultN2NTxFileDefinition.payeeBankName);
	}

	/**
	 * 受款銀行名稱
	 * 
	 * @param value
	 */
	public void setPayeeBankName(String value) {
		setValue(Cactx502ResultN2NTxFileDefinition.payeeBankName, value);
	}

	/**
	 * 受款銀行地址
	 * 
	 * @return
	 */
	public String getPayeeBankAddr() {
		return getValue(Cactx502ResultN2NTxFileDefinition.payeeBankAddr);
	}

	/**
	 * 受款銀行地址
	 * 
	 * @param value
	 */
	public void setPayeeBankAddr(String value) {
		setValue(Cactx502ResultN2NTxFileDefinition.payeeBankAddr, value);
	}

	/**
	 * 手續費扣款幣金額
	 * 
	 * @return
	 */
	public String getCommission() {
		return getValue(Cactx502ResultN2NTxFileDefinition.commission);
	}

	/**
	 * 手續費扣款幣金額
	 * 
	 * @param value
	 */
	public void setCommission(String value) {
		setValue(Cactx502ResultN2NTxFileDefinition.commission, value);
	}

	/**
	 * 手續費本位幣金額
	 * 
	 * @return
	 */
	public String getCommissionBcu() {
		return getValue(Cactx502ResultN2NTxFileDefinition.commissionBcu);
	}

	/**
	 * 手續費本位幣金額
	 * 
	 * @param value
	 */
	public void setCommissionBcu(String value) {
		setValue(Cactx502ResultN2NTxFileDefinition.commissionBcu, value);
	}

	/**
	 * 郵電費扣款幣金額
	 * 
	 * @return
	 */
	public String getPostage() {
		return getValue(Cactx502ResultN2NTxFileDefinition.postage);
	}

	/**
	 * 郵電費扣款幣金額
	 * 
	 * @param value
	 */
	public void setPostage(String value) {
		setValue(Cactx502ResultN2NTxFileDefinition.postage, value);
	}

	/**
	 * 郵電費本位幣金額
	 * 
	 * @return
	 */
	public String getPostageBcu() {
		return getValue(Cactx502ResultN2NTxFileDefinition.postageBcu);
	}

	/**
	 * 郵電費本位幣金額
	 * 
	 * @param value
	 */
	public void setPostageBcu(String value) {
		setValue(Cactx502ResultN2NTxFileDefinition.postageBcu, value);
	}

	/**
	 * 費用總金額
	 * 
	 * @return
	 */
	public String getTotChg() {
		return getValue(Cactx502ResultN2NTxFileDefinition.totChg);
	}

	/**
	 * 費用總金額
	 * 
	 * @param value
	 */
	public void setTotChg(String value) {
		setValue(Cactx502ResultN2NTxFileDefinition.totChg, value);
	}

	/**
	 * 總扣款金額
	 * 
	 * @return
	 */
	public String getTotPayAmt() {
		return getValue(Cactx502ResultN2NTxFileDefinition.totPayAmt);
	}

	/**
	 * 總扣款金額
	 * 
	 * @param value
	 */
	public void setTotPayAmt(String value) {
		setValue(Cactx502ResultN2NTxFileDefinition.totPayAmt, value);
	}

	/**
	 * 等值美金金額
	 * 
	 * @return
	 */
	public String getEquUsdAmt() {
		return getValue(Cactx502ResultN2NTxFileDefinition.equUsdAmt);
	}

	/**
	 * 等值美金金額
	 * 
	 * @param value
	 */
	public void setEquUsdAmt(String value) {
		setValue(Cactx502ResultN2NTxFileDefinition.equUsdAmt, value);
	}

	/**
	 * 等值台幣金額
	 * 
	 * @return
	 */
	public String getEquTwdAmt() {
		return getValue(Cactx502ResultN2NTxFileDefinition.equTwdAmt);
	}

	/**
	 * 等值台幣金額
	 * 
	 * @param value
	 */
	public void setEquTwdAmt(String value) {
		setValue(Cactx502ResultN2NTxFileDefinition.equTwdAmt, value);
	}

	/**
	 * 收款人Email
	 * 
	 * @return
	 */
	public String getPayeeEmail() {
		return getValue(Cactx502ResultN2NTxFileDefinition.payeeEmail);
	}

	/**
	 * 收款人Email
	 * 
	 * @param value
	 */
	public void setPayeeEmail(String value) {
		setValue(Cactx502ResultN2NTxFileDefinition.payeeEmail, value);
	}

	/**
	 * 受款人地址
	 * 
	 * @return
	 */
	public String getPayeeAddr() {
		return getValue(Cactx502ResultN2NTxFileDefinition.payeeAddr);
	}

	/**
	 * 受款人地址
	 * 
	 * @param value
	 */
	public void setPayeeAddr(String value) {
		setValue(Cactx502ResultN2NTxFileDefinition.payeeAddr, value);
	}

	/**
	 * 受款人電話
	 * 
	 * @return
	 */
	public String getPayeeTel() {
		return getValue(Cactx502ResultN2NTxFileDefinition.payeeTel);
	}

	/**
	 * 受款人電話
	 * 
	 * @param value
	 */
	public void setPayeeTel(String value) {
		setValue(Cactx502ResultN2NTxFileDefinition.payeeTel, value);
	}

	/**
	 * 大陸現代化支付系統帳號
	 * 
	 * @return
	 */
	public String getCnaps() {
		return getValue(Cactx502ResultN2NTxFileDefinition.cnaps);
	}

	/**
	 * 大陸現代化支付系統帳號
	 * 
	 * @param value
	 */
	public void setCnaps(String value) {
		setValue(Cactx502ResultN2NTxFileDefinition.cnaps, value);
	}

	/**
	 * 附言
	 * 
	 * @return
	 */
	public String getPaymentDetails() {
		return getValue(Cactx502ResultN2NTxFileDefinition.paymentDetails);
	}

	/**
	 * 附言
	 * 
	 * @param value
	 */
	public void setPaymentDetails(String value) {
		setValue(Cactx502ResultN2NTxFileDefinition.paymentDetails, value);
	}

	/**
	 * 外匯性質
	 * 
	 * @return
	 */
	public String getCbTradeType() {
		return getValue(Cactx502ResultN2NTxFileDefinition.cbTradeType);
	}

	/**
	 * 外匯性質
	 * 
	 * @param value
	 */
	public void setCbTradeType(String value) {
		setValue(Cactx502ResultN2NTxFileDefinition.cbTradeType, value);
	}

	/**
	 * 受款人身份別
	 * 
	 * @return
	 */
	public String getOppoKind() {
		return getValue(Cactx502ResultN2NTxFileDefinition.oppoKind);
	}

	/**
	 * 受款人身份別
	 * 
	 * @param value
	 */
	public void setOppoKind(String value) {
		setValue(Cactx502ResultN2NTxFileDefinition.oppoKind, value);
	}

	/**
	 * 受款銀行SWIFT
	 * 
	 * @return
	 */
	public String getPayeeBankSwift() {
		return getValue(Cactx502ResultN2NTxFileDefinition.payeeBankSwift);
	}

	/**
	 * 受款銀行SWIFT
	 * 
	 * @param value
	 */
	public void setPayeeBankSwift(String value) {
		setValue(Cactx502ResultN2NTxFileDefinition.payeeBankSwift, value);
	}

	/**
	 * 受款銀行清算代碼
	 * 
	 * @return
	 */
	public String getPayeeBankAcno() {
		return getValue(Cactx502ResultN2NTxFileDefinition.payeeBankAcno);
	}

	/**
	 * 受款銀行清算代碼
	 * 
	 * @param value
	 */
	public void setPayeeBankAcno(String value) {
		setValue(Cactx502ResultN2NTxFileDefinition.payeeBankAcno, value);
	}

	/**
	 * 中間銀行SWIFT
	 * 
	 * @return
	 */
	public String getIntrBankSwift() {
		return getValue(Cactx502ResultN2NTxFileDefinition.intrBankSwift);
	}

	/**
	 * 中間銀行SWIFT
	 * 
	 * @param value
	 */
	public void setIntrBankSwift(String value) {
		setValue(Cactx502ResultN2NTxFileDefinition.intrBankSwift, value);
	}

	/**
	 * 內扣外繳
	 * 
	 * @return
	 */
	public String getDeductFeeFlag() {
		return getValue(Cactx502ResultN2NTxFileDefinition.deductFeeFlag);
	}

	/**
	 * 內扣外繳
	 * 
	 * @param value
	 */
	public void setDeductFeeFlag(String value) {
		setValue(Cactx502ResultN2NTxFileDefinition.deductFeeFlag, value);
	}

	/**
	 * 發動端平台代號
	 * 
	 * @return
	 */
	public String getApplicationId() {
		return getValue(Cactx502ResultN2NTxFileDefinition.applicationId);
	}

	/**
	 * 發動端平台代號
	 * 
	 * @param value
	 */
	public void setApplicationId(String value) {
		setValue(Cactx502ResultN2NTxFileDefinition.applicationId, value);
	}

	/**
	 * 客戶英文名稱
	 * 
	 * @return
	 */
	public String getCustName() {
		return getValue(Cactx502ResultN2NTxFileDefinition.custName);
	}

	/**
	 * 客戶英文名稱
	 * 
	 * @param value
	 */
	public void setCustName(String value) {
		setValue(Cactx502ResultN2NTxFileDefinition.custName, value);
	}

	/**
	 * 客戶英文地址
	 * 
	 * @return
	 */
	public String getCustAddr() {
		return getValue(Cactx502ResultN2NTxFileDefinition.custAddr);
	}

	/**
	 * 客戶英文地址
	 * 
	 * @param value
	 */
	public void setCustAddr(String value) {
		setValue(Cactx502ResultN2NTxFileDefinition.custAddr, value);
	}

	/**
	 * 交易類型
	 * 
	 * @return
	 */
	public String getTxntType() {
		return getValue(Cactx502ResultN2NTxFileDefinition.txntType);
	}

	/**
	 * 交易類型
	 * 
	 * @param value
	 */
	public void setTxntType(String value) {
		setValue(Cactx502ResultN2NTxFileDefinition.txntType, value);
	}

	/**
	 * 客戶所屬分行別
	 * 
	 * @return
	 */
	public String getBsnUnit() {
		return getValue(Cactx502ResultN2NTxFileDefinition.bsnUnit);
	}

	/**
	 * 客戶所屬分行別
	 * 
	 * @param value
	 */
	public void setBsnUnit(String value) {
		setValue(Cactx502ResultN2NTxFileDefinition.bsnUnit, value);
	}

	/**
	 * 交易生效日
	 * 
	 * @return
	 */
	public String getValidDate() {
		return getValue(Cactx502ResultN2NTxFileDefinition.validDate);
	}

	/**
	 * 交易生效日
	 * 
	 * @param value
	 */
	public void setValidDate(String value) {
		setValue(Cactx502ResultN2NTxFileDefinition.validDate, value);
	}

	/**
	 * 匯款幣別
	 * 
	 * @return
	 */
	public String getRemitCcy() {
		return getValue(Cactx502ResultN2NTxFileDefinition.remitCcy);
	}

	/**
	 * 匯款幣別
	 * 
	 * @param value
	 */
	public void setRemitCcy(String value) {
		setValue(Cactx502ResultN2NTxFileDefinition.remitCcy, value);
	}

	/**
	 * 付款幣別
	 * 
	 * @return
	 */
	public String getPayCcy() {
		return getValue(Cactx502ResultN2NTxFileDefinition.payCcy);
	}

	/**
	 * 付款幣別
	 * 
	 * @param value
	 */
	public void setPayCcy(String value) {
		setValue(Cactx502ResultN2NTxFileDefinition.payCcy, value);
	}

	/**
	 * 議價編號
	 * 
	 * @return
	 */
	public String getExCntrno() {
		return getValue(Cactx502ResultN2NTxFileDefinition.exCntrno);
	}

	/**
	 * 議價編號
	 * 
	 * @param value
	 */
	public void setExCntrno(String value) {
		setValue(Cactx502ResultN2NTxFileDefinition.exCntrno, value);
	}

	/**
	 * 成交匯率
	 * 
	 * @return
	 */
	public String getExrate() {
		return getValue(Cactx502ResultN2NTxFileDefinition.exrate);
	}

	/**
	 * 成交匯率
	 * 
	 * @param value
	 */
	public void setExrate(String value) {
		setValue(Cactx502ResultN2NTxFileDefinition.exrate, value);
	}

	/**
	 * 買匯匯率優惠
	 * 
	 * @return
	 */
	public String getSpreadBSpot() {
		return getValue(Cactx502ResultN2NTxFileDefinition.spreadBSpot);
	}

	/**
	 * 買匯匯率優惠
	 * 
	 * @param value
	 */
	public void setSpreadBSpot(String value) {
		setValue(Cactx502ResultN2NTxFileDefinition.spreadBSpot, value);
	}

	/**
	 * 賣匯匯率優惠
	 * 
	 * @return
	 */
	public String getSpreadSSpot() {
		return getValue(Cactx502ResultN2NTxFileDefinition.spreadSSpot);
	}

	/**
	 * 賣匯匯率優惠
	 * 
	 * @param value
	 */
	public void setSpreadSSpot(String value) {
		setValue(Cactx502ResultN2NTxFileDefinition.spreadSSpot, value);
	}

	/**
	 * 匯款分類
	 * 
	 * @return
	 */
	public String getSourceOfFund() {
		return getValue(Cactx502ResultN2NTxFileDefinition.sourceOfFund);
	}

	/**
	 * 匯款分類
	 * 
	 * @param value
	 */
	public void setSourceOfFund(String value) {
		setValue(Cactx502ResultN2NTxFileDefinition.sourceOfFund, value);
	}

	/**
	 * 匯出匯款方式
	 * 
	 * @return
	 */
	public String getFullPayment() {
		return getValue(Cactx502ResultN2NTxFileDefinition.fullPayment);
	}

	/**
	 * 匯出匯款方式
	 * 
	 * @param value
	 */
	public void setFullPayment(String value) {
		setValue(Cactx502ResultN2NTxFileDefinition.fullPayment, value);
	}

	/**
	 * 客戶聯絡電話
	 * 
	 * @return
	 */
	public String getCustTel() {
		return getValue(Cactx502ResultN2NTxFileDefinition.custTel);
	}

	/**
	 * 客戶聯絡電話
	 * 
	 * @param value
	 */
	public void setCustTel(String value) {
		setValue(Cactx502ResultN2NTxFileDefinition.custTel, value);
	}

	/**
	 * 客戶生日
	 * 
	 * @return
	 */
	public String getCustBirthday() {
		return getValue(Cactx502ResultN2NTxFileDefinition.custBirthday);
	}

	/**
	 * 客戶生日
	 * 
	 * @param value
	 */
	public void setCustBirthday(String value) {
		setValue(Cactx502ResultN2NTxFileDefinition.custBirthday, value);
	}

	/**
	 * 客戶身份別
	 * 
	 * @return
	 */
	public String getCustKindCbMemo() {
		return getValue(Cactx502ResultN2NTxFileDefinition.custKindCbMemo);
	}

	/**
	 * 客戶身份別
	 * 
	 * @param value
	 */
	public void setCustKindCbMemo(String value) {
		setValue(Cactx502ResultN2NTxFileDefinition.custKindCbMemo, value);
	}
	
	/**
	 * 證件類型(付款人)
	 * 
	 * @return
	 */
	public String getIdType() {
		return getValue(Cactx502ResultN2NTxFileDefinition.idType);
	}
	
	/**
	 * 證件類型(付款人)
	 * 
	 * @param value
	 */
	public void setIdType(String value) {
		setValue(Cactx502ResultN2NTxFileDefinition.idType, value);
	}
	
	/**
	 * 證件號碼(付款人)
	 * 
	 * @return
	 */
	public String getIdNo() {
		return getValue(Cactx502ResultN2NTxFileDefinition.idNo);
	}
	
	/**
	 * 證件號碼(付款人)
	 * 
	 * @param value
	 */
	public void setIdNo(String value) {
		setValue(Cactx502ResultN2NTxFileDefinition.idNo, value);
	}

	/**
	 * 居留證核發日期
	 * 
	 * @return
	 */
	public String getRsdntIssueDate() {
		return getValue(Cactx502ResultN2NTxFileDefinition.rsdntIssueDate);
	}

	/**
	 * 居留證核發日期
	 * 
	 * @param value
	 */
	public void setRsdntIssueDate(String value) {
		setValue(Cactx502ResultN2NTxFileDefinition.rsdntIssueDate, value);
	}

	/**
	 * 居留證有效期限
	 * 
	 * @return
	 */
	public String getRsdntValidDate() {
		return getValue(Cactx502ResultN2NTxFileDefinition.rsdntValidDate);
	}

	/**
	 * 居留證有效期限
	 * 
	 * @param value
	 */
	public void setRsdntValidDate(String value) {
		setValue(Cactx502ResultN2NTxFileDefinition.rsdntValidDate, value);
	}
	
	/**
	 * 客戶生日(收款人) (DDMMYYYY)
	 * 
	 * @return
	 */
	public String getCustBirthday2() {
		return getValue(Cactx502ResultN2NTxFileDefinition.custBirthday2);
	}

	/**
	 * 客戶生日(收款人) (DDMMYYYY)
	 * 
	 * @param value
	 */
	public void setCustBirthday2(String value) {
		setValue(Cactx502ResultN2NTxFileDefinition.custBirthday2, value);
	}
	
	/**
	 * 客戶身份別(收款人)
	 * 
	 * @return
	 */
	public String getCustKindCbMemo2() {
		return getValue(Cactx502ResultN2NTxFileDefinition.custKindCbMemo2);
	}

	/**
	 * 客戶身份別(收款人)
	 * 
	 * @param value
	 */
	public void setCustKindCbMemo2(String value) {
		setValue(Cactx502ResultN2NTxFileDefinition.custKindCbMemo2, value);
	}
	
	/**
	 * 證件類型(收款人)
	 * 
	 * @return
	 */
	public String getIdType2() {
		return getValue(Cactx502ResultN2NTxFileDefinition.idType2);
	}
	
	/**
	 * 證件類型(收款人)
	 * 
	 * @param value
	 */
	public void setIdType2(String value) {
		setValue(Cactx502ResultN2NTxFileDefinition.idType2, value);
	}
	
	/**
	 * 證件號碼(收款人)
	 * 
	 * @return
	 */
	public String getIdNo2() {
		return getValue(Cactx502ResultN2NTxFileDefinition.idNo2);
	}
	
	/**
	 * 證件號碼(收款人)
	 * 
	 * @param value
	 */
	public void setIdNo2(String value) {
		setValue(Cactx502ResultN2NTxFileDefinition.idNo2, value);
	}

	/**
	 * 居留證核發日期(收款人) (DDMMYYYY)
	 * 
	 * @return
	 */
	public String getRsdntIssueDate2() {
		return getValue(Cactx502ResultN2NTxFileDefinition.rsdntIssueDate2);
	}

	/**
	 * 居留證核發日期(收款人) (DDMMYYYY)
	 * 
	 * @param value
	 */
	public void setRsdntIssueDate2(String value) {
		setValue(Cactx502ResultN2NTxFileDefinition.rsdntIssueDate2, value);
	}

	/**
	 * 居留證有效期限(收款人) (DDMMYYYY)
	 * 
	 * @return
	 */
	public String getRsdntValidDate2() {
		return getValue(Cactx502ResultN2NTxFileDefinition.rsdntValidDate2);
	}

	/**
	 * 居留證有效期限(收款人) (DDMMYYYY)
	 * 
	 * @param value
	 */
	public void setRsdntValidDate2(String value) {
		setValue(Cactx502ResultN2NTxFileDefinition.rsdntValidDate2, value);
	}
	
	
	/**
	 * UUID
	 * 
	 * @return
	 */
	public String getUUID() {
		return getValue(Cactx502ResultN2NTxFileDefinition.UUID);
	}

	/**
	 * UUID
	 * 
	 * @param value
	 */
	public void setUUID(String value) {
		setValue(Cactx502ResultN2NTxFileDefinition.UUID, value);
	}
	
	/**
	 * Custid
	 * 
	 * @return
	 */
	public String getCustid() {
		return getValue(Cactx502ResultN2NTxFileDefinition.Custid);
	}

	/**
	 * Custid
	 * 
	 * @param value
	 */
	public void setCustid(String value) {
		setValue(Cactx502ResultN2NTxFileDefinition.Custid, value);
	}
	
	/**
	 * CustidSub
	 * 
	 * @return
	 */
	public String getCustidSub() {
		return getValue(Cactx502ResultN2NTxFileDefinition.CustidSub);
	}

	/**
	 * CustidSub
	 * 
	 * @param value
	 */
	public void setCustidSub(String value) {
		setValue(Cactx502ResultN2NTxFileDefinition.CustidSub, value);
	}
	
	/**
	 * 水單號碼欄位
	 * 
	 * @return
	 */
	public String getBdSeq() {
		return getValue(Cactx502ResultN2NTxFileDefinition.BdSeq);
	}

	/**
	 * 水單號碼欄位
	 * 
	 * @param value
	 */
	public void setBdSeq(String value) {
		setValue(Cactx502ResultN2NTxFileDefinition.BdSeq, value);
	}
	
	/**
	 * CHECK_ID
	 * 
	 * @return
	 */
	public String getCheckId() {
		return getValue(Cactx502ResultN2NTxFileDefinition.CHECK_ID);
	}

	/**
	 * CHECK_ID
	 * 
	 * @param value
	 */
	public void setCheckId(String value) {
		setValue(Cactx502ResultN2NTxFileDefinition.CHECK_ID, value);
	}

	// ========================================================
	// 以下可共用

	/**
	 * 
	 * @param fileDefinition
	 * @return
	 */
	private String getValue(IFileDefinition fileDefinition) {

		FileField fileField = fileSection.getField(fileDefinition.getId());
		if (fileField == null) {
			return null;
		}
		else {
			return StringUtils.trim(fileField.getValue());
		}
	}

	/**
	 * 
	 * @param fileDefinition
	 * @param value
	 */
	private void setValue(IFileDefinition fileDefinition, String value) {

		if (fileSection == null) {
			fileSection = new FileSection();
		}

		FileField field = fileSection.getField(fileDefinition.getId());
		if (field == null) {
			field = new FileField();
			field.setFieldId(fileDefinition.getId());
			field.setValue(value);
			fileSection.addField(field);
		}
		else {
			field.setValue(value);
		}
	}

	// 以上可共用
	// ========================================================

	@Override
	public String toString() {
		
		StringBuilder sb = new StringBuilder();
		
		sb.append(",getCBRTxnType1:"+getCBRTxnType1());
		sb.append(",getCBRCountry1:"+getCBRCountry1());
		sb.append(",getCbrCountry2:"+getCbrCountry2());
		sb.append(",getOppoKind:"+getOppoKind());
		sb.append(",getCustKindCbMemo:"+getCustKindCbMemo());
		sb.append(",getCustKindCbMemo2:"+getCustKindCbMemo2());
		sb.append(",getCustBirthday2:"+getCustBirthday2());
		sb.append(",getIdType2:"+getIdType2());
		sb.append(",getIdNo2:"+getIdNo2());
		sb.append(",getCheckId:"+getCheckId());
		
		return sb.toString();
	}
	
	/**
	 * 成本匯率 9(05).9(07)
	 * 
	 * @return
	 */
	public String getExcost() {
		return getValue(Cactx502Result12NTxFileDefinition.excost);
	}

	/**
	 * 成本匯率 9(05).9(07)
	 * 
	 * @param value
	 */
	public void setExcost(String value) {
		setValue(Cactx502Result12NTxFileDefinition.excost, value);
	}
	
	/**
	 * 成交買匯匯率 9(05).9(07)
	 * 
	 * @return
	 */
	public String getPayExrate() {
		return getValue(Cactx502Result12NTxFileDefinition.payExrate);
	}

	/**
	 * 成交買匯匯率 9(05).9(07)
	 * 
	 * @param value
	 */
	public void setPayExrate(String value) {
		setValue(Cactx502Result12NTxFileDefinition.payExrate, value);
	}	
	
	/**
	 * 成本買匯匯率 9(05).9(07)
	 * 
	 * @return
	 */
	public String getPayExcost() {
		return getValue(Cactx502Result12NTxFileDefinition.payExcost);
	}

	/**
	 * 成本買匯匯率 9(05).9(07)
	 * 
	 * @param value
	 */
	public void setPayExcost(String value) {
		setValue(Cactx502Result12NTxFileDefinition.payExcost, value);
	}	
	
	/**
	 * 成交賣匯匯率 9(05).9(07)
	 * 
	 * @return
	 */
	public String getRemitExrate() {
		return getValue(Cactx502Result12NTxFileDefinition.remitExrate);
	}

	/**
	 * 成交賣匯匯率 9(05).9(07)
	 * 
	 * @param value
	 */
	public void setRemitExrate(String value) {
		setValue(Cactx502Result12NTxFileDefinition.remitExrate, value);
	}	
	
	/**
	 * 成本賣匯匯率 9(05).9(07)
	 * 
	 * @return
	 */
	public String getRemitExcost() {
		return getValue(Cactx502Result12NTxFileDefinition.remitExcost);
	}

	/**
	 * 成本賣匯匯率 9(05).9(07)
	 * 
	 * @param value
	 */
	public void setRemitExcost(String value) {
		setValue(Cactx502Result12NTxFileDefinition.remitExcost, value);
	}	
	
	/**
	 * 牌告成交匯率 9(05).9(07)
	 * 
	 * @return
	 */
	public String getStdExrate() {
		return getValue(Cactx502Result12NTxFileDefinition.stdExrate);
	}

	/**
	 * 牌告成交匯率 9(05).9(07)
	 * 
	 * @param value
	 */
	public void setStdExrate(String value) {
		setValue(Cactx502Result12NTxFileDefinition.stdExrate, value);
	}	
	
	/**
	 * 牌告成本匯率 9(05).9(07)
	 * 
	 * @return
	 */
	public String getStdExcost() {
		return getValue(Cactx502Result12NTxFileDefinition.stdExcost);
	}

	/**
	 * 牌告成本匯率 9(05).9(07)
	 * 
	 * @param value
	 */
	public void setStdExcost(String value) {
		setValue(Cactx502Result12NTxFileDefinition.stdExcost, value);
	}	
	
	/**
	 * 手續費成交匯率 9(05).9(07)
	 * 
	 * @return
	 */
	public String getChgExrate() {
		return getValue(Cactx502Result12NTxFileDefinition.chgExrate);
	}

	/**
	 * 手續費成交匯率 9(05).9(07)
	 * 
	 * @param value
	 */
	public void setChgExrate(String value) {
		setValue(Cactx502Result12NTxFileDefinition.chgExrate, value);
	}	
	
	/**
	 * 手續費成本匯率 9(05).9(07)
	 * 
	 * @return
	 */
	public String getChgExcost() {
		return getValue(Cactx502Result12NTxFileDefinition.chgExcost);
	}

	/**
	 * 手續費成本匯率 9(05).9(07)
	 * 
	 * @param value
	 */
	public void setChgExcost(String value) {
		setValue(Cactx502Result12NTxFileDefinition.chgExcost, value);
	}
	
	/**
	 * 付款人手續費帳號
	 * 
	 * @return
	 */
	public String getChgAcno() {
		return getValue(Cactx502ResultN2NTxFileDefinition.CHG_ACNO);
	}

	/**
	 * 付款人手續費帳號
	 * 
	 * @param value
	 */
	public void setChgAcno(String value) {
		setValue(Cactx502ResultN2NTxFileDefinition.CHG_ACNO, value);
	}
	
	/**
	 * 付款人手續費帳號幣別
	 * 
	 * @return
	 */
	public String getChgCcy() {
		return getValue(Cactx502ResultN2NTxFileDefinition.CHGCCY);
	}

	/**
	 * 付款人手續費帳號幣別
	 * 
	 * @param value
	 */
	public void setChgCcy(String value) {
		setValue(Cactx502ResultN2NTxFileDefinition.CHGCCY, value);
	}
	
	/**
	 * 付款金額  9(17).9(3)
	 * 
	 * @return
	 */
	public String getPayAmt() {
		return getValue(Cactx502ResultN2NTxFileDefinition.payAmt);
	}

	/**
	 * 付款金額 9(17).9(3)
	 * 
	 * @param value
	 */
	public void setPayAmt(String value) {
		setValue(Cactx502ResultN2NTxFileDefinition.payAmt, value);
	}
	
	/**
	 * 匯款金額   9(17).9(3)
	 * 
	 * @return
	 */
	public String getRemitAmt() {
		return getValue(Cactx502ResultN2NTxFileDefinition.remitAmt);
	}

	/**
	 * 匯款金額  9(17).9(3)
	 * 
	 * @param value
	 */
	public void setRemitAmt(String value) {
		setValue(Cactx502ResultN2NTxFileDefinition.remitAmt, value);
	}
}
