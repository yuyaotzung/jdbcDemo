/*
 * ===========================================================================
 * IBM Confidential
 * AIS Source Materials
 * 
 * 
 * (C) Copyright IBM Corp. 2018.
 *
 * ===========================================================================
 */
package com.cosmos.file.ext;

import com.cosmos.file.bo.FileField;
import com.cosmos.file.bo.FileSection;
import com.cosmos.file.def.Csftx401AResultHeader2FileDefinition;
import com.cosmos.file.def.IFileDefinition;
import com.cosmos.type.FieldGroup;
import com.ibm.tw.commons.util.StringUtils;



/**
 * <p> 外幣整批扣自入自、複委託扣帳-扣客戶入發動者(凱基) Header2 FileSection</p>
 *
 * @author  Bear
 * @version 1.0, 2018/6/5
 * @see	    
 * @since 
 */
public class Csftx401AResultHeader2FileSection {

	/** 檔案區段 */
	private FileSection fileSection;
	
	public Csftx401AResultHeader2FileSection() {
		fileSection = new FileSection();
		fileSection.setFieldGroup(FieldGroup.HEADER2);
	}
	
	public Csftx401AResultHeader2FileSection(FileSection fileSection) {
		this.fileSection = fileSection;
	}
	
	public FileSection getFileSection() {
		return fileSection;
	}
	
//	Data Indicator
	public String getDataIndicator() {
		return getValue(Csftx401AResultHeader2FileDefinition.DATA_INDICATOR);
	}
	
	public void setDataIndicator(String value) {
		setValue(Csftx401AResultHeader2FileDefinition.DATA_INDICATOR, value);
	}
	
//	委託單位代號
	public String getCompanyCode() {
		return getValue(Csftx401AResultHeader2FileDefinition.COMPANY_CODE);
	}
	
	public void setCompanyCode(String value) {
		setValue(Csftx401AResultHeader2FileDefinition.COMPANY_CODE, value);
	}
	
//	清算帳號
	public String getColumn3() {
		return getValue(Csftx401AResultHeader2FileDefinition.COLUMN3);
	}
	
	public void setColumn3(String value) {
		setValue(Csftx401AResultHeader2FileDefinition.COLUMN3, value);
	}
	
//	清算帳號幣別
	public String getCurrency() {
		return getValue(Csftx401AResultHeader2FileDefinition.CURRENCY);
	}
	
	public void setCurrency(String value) {
		setValue(Csftx401AResultHeader2FileDefinition.CURRENCY, value);
	}
	
//	提示碼
	public String getPromoCode() {
		return getValue(Csftx401AResultHeader2FileDefinition.PROMO_CODE);
	}
	
	public void setPromoCode(String value) {
		setValue(Csftx401AResultHeader2FileDefinition.PROMO_CODE, value);
	}
	
//	清算帳號入扣類別
	public String getColumn6() {
		return getValue(Csftx401AResultHeader2FileDefinition.COLUMN6);
	}
	
	public void setColumn6(String value) {
		setValue(Csftx401AResultHeader2FileDefinition.COLUMN6, value);
	}
	
//	指定牌告匯率時間
	public String getColumn7() {
		return getValue(Csftx401AResultHeader2FileDefinition.COLUMN7);
	}
	
	public void setColumn7(String value) {
		setValue(Csftx401AResultHeader2FileDefinition.COLUMN7, value);
	}
	
//	公司統編
	public String getCompanyUid() {
		return getValue(Csftx401AResultHeader2FileDefinition.COMPANY_UID);
	}
	
	public void setCompanyUid(String value) {
		setValue(Csftx401AResultHeader2FileDefinition.COMPANY_UID, value);
	}
	
//	公司名稱
	public String getCompanyName() {
		return getValue(Csftx401AResultHeader2FileDefinition.COMPANY_NAME);
	}
	
	public void setCompanyName(String value) {
		setValue(Csftx401AResultHeader2FileDefinition.COMPANY_NAME, value);
	}
	
//	FILLER
	public String getFiller() {
		return getValue(Csftx401AResultHeader2FileDefinition.FILLER);
	}
	
	public void setFiller(String value) {
		setValue(Csftx401AResultHeader2FileDefinition.FILLER, value);
	}
	
	//========================================================
	// 以下可共用
	
	
	/**
	 * 
	 * @param fileDefinition
	 * @return
	 */
	private String getValue(IFileDefinition fileDefinition) {
		
		FileField fileField = fileSection.getField(fileDefinition.getId());
		if (fileField == null) {
			return null;
		}
		else {
			return StringUtils.trim(fileField.getValue());
		}
	}
	
	/**
	 * 
	 * @param fileDefinition
	 * @param value
	 */
	private void setValue(IFileDefinition fileDefinition, String value) {

		if (fileSection == null) {
			fileSection = new FileSection();
		}

		FileField field = fileSection.getField(fileDefinition.getId());
		if (field == null) {
			field = new FileField();
			field.setFieldId(fileDefinition.getId());
			field.setValue(value);
			fileSection.addField(field);
		}
		else {
			field.setValue(value);
		}
	}
	
	// 以上可共用
	//========================================================

}



 