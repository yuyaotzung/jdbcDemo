/*
 * ===========================================================================
 * IBM Confidential
 * AIS Source Materials
 * 
 * 
 * (C) Copyright IBM Corp. 2018.
 *
 * ===========================================================================
 */
package com.cosmos.file.ext;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;

import org.apache.commons.io.FileUtils;

import com.cosmos.code.CibErrorCode;
import com.cosmos.code.CosmosCommonId;
import com.cosmos.esb.exception.EsbActionException;
import com.cosmos.esb.exception.EsbException;
import com.cosmos.esb.xml.kgib.bns08550000q.Bns08550000qRq;
import com.cosmos.esb.xml.kgib.bns08550000q.Bns08550000qRs;
import com.cosmos.esb.xml.nefx.frn55s.Frn55sRq;
import com.cosmos.esb.xml.nefx.frn55s.Frn55sRs;
import com.cosmos.file.bo.FileDetail;
import com.cosmos.file.bo.FileDoc;
import com.cosmos.file.bo.FileSection;
import com.cosmos.param.ISystemParam;
import com.cosmos.param.ext.CibParam;
import com.cosmos.persistence.CosmosDaoFactory;
import com.cosmos.persistence.b2c.dao.B2CSequenceDao;
import com.cosmos.persistence.b2c.dao.IB2CSequenceDao;
import com.cosmos.persistence.b2c.dao.IExchangeRateDao;
import com.cosmos.persistence.b2c.dao.IFxDocViewDao;
import com.cosmos.persistence.b2c.dao.ISystemParamDao;
import com.cosmos.persistence.b2c.entity.ExchangeRateEntity;
import com.cosmos.persistence.b2c.entity.SystemParamEntity;
import com.cosmos.persistence.b2c.entity.pk.SystemParamEntityPk;
import com.cosmos.persistence.b2c.entity.view.FxDocView;
import com.cosmos.persistence.kp.dao.IBns06750300qViewDao;
import com.cosmos.persistence.kp.view.Bns06750300qView;
import com.cosmos.tx.IFxDetailDoc;
import com.cosmos.tx.query.FxQueryDetailDoc;
import com.cosmos.type.FieldGroup;
import com.cosmos.type.FxScenarioType;
import com.cosmos.type.TxType;
import com.cosmos.util.CosmosCryptUtils;
import com.cosmos.util.CosmosFxUtils;
import com.cosmos.util.CosmosSequenceUtils;
import com.cosmos.util.CosmosUtils;
import com.cosmos.util.SFTPUtils;
import com.ibm.mq.MQException;
import com.ibm.tw.commons.aop.AOPProxyFactory;
import com.ibm.tw.commons.exception.ActionException;
import com.ibm.tw.commons.exception.CryptException;
import com.ibm.tw.commons.id.ICommonCode;
import com.ibm.tw.commons.net.mq.CMQStrMessage;
import com.ibm.tw.commons.net.mq.MQReceiver;
import com.ibm.tw.commons.net.mq.MQSender;
import com.ibm.tw.commons.persistence.exception.DatabaseException;
import com.ibm.tw.commons.util.ConvertUtils;
import com.ibm.tw.commons.util.DESUtils;
import com.ibm.tw.commons.util.StringUtils;
import com.ibm.tw.commons.util.time.DateFormatUtils;
import com.ibm.tw.commons.util.time.DateUtils;
import com.ibm.tw.uaa.b2c.bo.B2CUaaBoUtils;
import com.ibm.tw.uaa.b2c.bo.Company;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.SftpException;

/**
 * <p>
 * 外幣整批多扣多入
 * </p>
 * 
 * @author Bear
 * @version 1.0, 2018/7/13
 * @see
 * @since
 */
public class Cactx502ResultN2NFileFormatTest {

	// 多扣多入資料夾
	private static final String WORDKING_DIR = "0028";

	// Server
	static String server;

	// Port
	static int port;

	// 帳號
	static String user_put;

	// 密碼
	static String password_put;

	// 帳號
	static String user_get;

	// 密碼
	static String password_get;
	
	private static int totalCount = 0;
	
	private static BigDecimal totalAmt = BigDecimal.ZERO;
	
	static MQSender sender = null;

	static MQReceiver receiver = null;

	public static void main(String[] args) throws Throwable {

		init();

		// 產出檔案請使用Cactx502N2NMain
//		testExportFile();

		String fileName = "0028096016082018201808160010000793430000.TMP";
		testImportFile(fileName);

	}

	private static void init() throws MQException {
		// Server
		server = getSystemParamValue(CibParam.FCS_SFTP_SERVER);
		// Port
		port = ConvertUtils.str2Int(getSystemParamValue(CibParam.FCS_SFTP_PORT));
		// 帳號
		user_put = getSystemParamValue(CibParam.FCS_SFTP_USER_PUT);
		// 密碼
		password_put = getSystemParamValue(CibParam.FCS_SFTP_PASSWORD_PUT);
		// 帳號
		user_get = getSystemParamValue(CibParam.FCS_SFTP_USER_GET);
		// 密碼
		password_get = getSystemParamValue(CibParam.FCS_SFTP_PASSWORD_GET);
		
		sender = new MQSender();
		sender.setMQEnvironment("172.31.7.13", 1422, "ESBMQSVR.EB");
		sender.connect("", "MQ.EA");

		receiver = new MQReceiver();
		receiver.setMQEnvironment("172.31.7.13", 1422, "ESBMQSVR.EB");
		receiver.connect("", "EA.EB");

	}

	private static void testExportFile() throws JSchException, SftpException, IOException, DatabaseException, ActionException, MQException {
		Cactx502ResultN2NFileFormat fileFormat = new Cactx502ResultN2NFileFormat("CACTX502");

		// 案件序號
		String flowDocId = generateCaseNo();

		// 交易日期
		Date txDate = new Date();

		prepareHeaders(fileFormat, flowDocId, txDate);
		prepareDetails(fileFormat, flowDocId, txDate);
		prepareFooters(fileFormat);
		byte[] data = new byte[0];

		data = fileFormat.toFile();

		String fileName = getFileName(txDate, flowDocId);

		System.out.println("fileName:" + fileName);

		// TODO 備份路徑??
		// 備份檔案
		FileUtils.writeByteArrayToFile(new File("C:/ACHBACKUP/" + fileName + ".TXT"), data);

//		ChannelSftp sftp = null;
//
//		boolean result = false;
//		ByteArrayInputStream is = new ByteArrayInputStream(data);
//
//		try {
//			sftp = SFTPUtils.connect(server, port, user_put, password_put, WORDKING_DIR);
//
//			sftp.put(is, fileName + ".tmp");
//
//			result = true;
//			System.out.println("是否上傳成功 =" + result);
//			is.close();
//
//			if (!result) {
//				System.err.println("上傳失敗");
//			}
//
//			try {
//				if (result) {
//					sftp.rename(fileName + ".tmp", fileName + ".TXT");
//				}
//			}
//			catch (SftpException e) {
//				e.printStackTrace();
//				System.err.println("rename失敗, fileName:" + fileName);
//
//			}
//
//		}
//		catch (JSchException e) {
//			System.err.println("SFTP連線失敗");
//			e.printStackTrace();
//			throw e;
//		}
//		catch (SftpException e) {
//			e.printStackTrace();
//			throw e;
//		}
//		catch (IOException e) {
//			e.printStackTrace();
//			throw e;
//		}
//		finally {
//			try {
//				is.close();
//				SFTPUtils.disconnect(sftp);
//			}
//			catch (JSchException e) {
//				System.err.println("SFTP離線失敗");
//				e.printStackTrace();
//			}
//			catch (IOException e) {
//				System.err.println("ByteArrayInputStream close failed , fileName:" + fileName);
//				e.printStackTrace();
//			}
//		}
	}

	private static void prepareHeaders(Cactx502ResultN2NFileFormat fileFormat, String flowDocId, Date txDate) {

		Cactx502ResultN2NHeaderFileSection section = new Cactx502ResultN2NHeaderFileSection();
		// 交易使用的分行號碼 TODO 多扣多入會有OBU或DBU的資料,要放甚麼?
		// TRANS_BRANCH
		section.setBranchNo(CosmosCommonId.TX_branchNo);
		// 交易使用的行員號碼 TODO 多扣多入會有OBU或DBU的資料,要放甚麼?
		section.setTellerNo(CosmosCommonId.tellerNo);
		// 交易使用的端末機號
		section.setTermNo("");
		// 交易日期
		section.setTxDate(DateUtils.formatDate(txDate, "ddMMyyyy"));
		
		// 為了與畫面parse一致,讀入資料的secNo由1開始
		section.getFileSection().setSectionNo(1);
		fileFormat.addHeader(section);

	}

	private static void prepareDetails(Cactx502ResultN2NFileFormat fileFormat, String flowDocId, Date txDate) throws ActionException, DatabaseException, MQException {
		
		prepareDetail1(fileFormat,flowDocId, txDate);
		
		// TODO 未完成
//		prepareDetail2(fileFormat,flowDocId, txDate);
		
	}

	private static void prepareFooters(Cactx502ResultN2NFileFormat fileFormat) {
		Cactx502ResultN2NFooterFileSection section = new Cactx502ResultN2NFooterFileSection();
		
		section.setTotalAmt(StringUtils.remove(ConvertUtils.bigDecimal2Str(totalAmt, 3),"."));
		section.setTotalCount(String.valueOf(totalCount));
		
		// 為了與畫面parse一致,讀入資料的secNo由1開始
		section.getFileSection().setSectionNo(1);
		fileFormat.addFooter(section);
	}
	
	private static void prepareDetail1(Cactx502ResultN2NFileFormat fileFormat, String pmtId, Date txDate) throws ActionException, DatabaseException, MQException{

		// FIXME 使用DB裡單筆的資料
		// 自行轉帳 - flowDocId=1807310045491, scenario=9	
		List<String> flowDocIds = new ArrayList<String>();
		flowDocIds.add("1807310045491");
		IFxDocViewDao fxDocViewDao = CosmosDaoFactory.getFxDocViewDao();
		FxDocView fxDocView = fxDocViewDao.findByFlowDocIds(flowDocIds).get(0);
		FxQueryDetailDoc detail = new FxQueryDetailDoc(fxDocView);
		
		// 操作者公司
		Company company = B2CUaaBoUtils.getCompany(detail.getCompanyKey());
		
		// 試算
		Bns08550000qRs bns0855rs = queryBns0855000Q(detail);
		
		FxScenarioType fxScenarioType = FxScenarioType.valueOf(detail.getScenario());
		
		prepareBnsf0104500bDetail(fileFormat, pmtId, detail, txDate, fxScenarioType, company, bns0855rs);
		
	}
	
	
	
	
	private static void prepareBnsf0104500bDetail(Cactx502ResultN2NFileFormat fileFormat, String pmtId, IFxDetailDoc detail, 
			Date txDate, FxScenarioType fxScenarioType, Company company, Bns08550000qRs bns0855rs) throws ActionException {
		
		totalCount++;
		totalAmt = totalAmt.add(detail.getTxAmt());
		
		// 取得央媒申報欄位
		IBns06750300qViewDao dao = CosmosDaoFactory.getBns06750300qViewDao();
		// 付款人payer央媒申報欄位
		Bns06750300qView payerCBR = null;
		// 收款人payee央媒申報欄位
		Bns06750300qView payeeCBR = null;
		
		// 試算
//		Bns08550000qRs bns0855rs = queryBns0855000Q(detail);
		detail.setEquUsdAmt(ConvertUtils.str2BigDecimal(bns0855rs.getEquivalentUSD()));
		detail.setEquTwdAmt(ConvertUtils.str2BigDecimal(bns0855rs.getEquivalentTWD()));
		
		Cactx502ResultN2NTxFileSection section = new Cactx502ResultN2NTxFileSection();
		// 批號PBMT-BATCH-NO
		section.setBatchNo(pmtId); // TODO 因為是拿DB的資料,所以要設定為此次取的值
		// 流水號
		section.setSerno(String.valueOf(totalCount)); // TODO  因為是拿DB的資料,所以要設定為此次取的值
		// 付款通路 1-自行轉帳, 2-自行匯款, 3-匯出匯款
		section.setPayChanel(String.valueOf(fxScenarioType.getChannelType()));
		// 付款人帳號
		section.setPayerAccountNo(detail.getPayerAccountNo());
		// 付款人戶名
		String addr = StringUtils.defaultString(detail.getPayerEngAddress());
		String payerName = CosmosFxUtils.getConcatenateStr(detail.getPayerEngName(), StringUtils.substring(addr, 0, 35));// 客戶英文名稱35*2分2行, 每行35字
		section.setPayerName(payerName); 
		// 付款人統編
//		section.setPayerUid(detail.getPayerUid()); 
		// 收款銀行代號 TODO
		// TODO 應該1-自行轉帳以及2-自行匯款都可以放8090000吧??
		// 付款通路為1自行轉帳時，收款銀行請補空白或放8090000
		section.setReceiveBankCode("8090000");
		
		// 轉入帳號
		section.setRollInAcct(detail.getPayeeAccountNo());
		// 交易金額
		section.setAmount(StringUtils.remove(ConvertUtils.bigDecimal2Str(detail.getTxAmt(), 3),"."));
		// 提示碼 
		section.setPromoCode(CosmosCommonId.PROMOCODE);
		// 存摺附註 TODO ??
		section.setRemarks("");
		// 檢核ID TODO ??
//		section.setCheckId("");
//		// 檢核戶名 TODO ??
//		section.setCheckName("");
		// 櫃員手續費/匯款手續費 ?? TODO
		section.setFee("");
		// 附言
		section.setPostScript(CosmosFxUtils.getConcatenateStr(detail.getPaymentdetails1(), detail.getPaymentdetails2(), detail.getPaymentdetails3(), detail.getPaymentdetails4()));
		// BaNCS中心執行結果
		section.setBancsStat("9999");
		// 匯款處理結果(他行)
		section.setNefxStat("");
		// ESB_STAT
		section.setNefxStat("");
		// 交易序號 , 9個0
		section.setJrnlNo("");
		// 付款帳號幣別
		section.setPayAcctCurrcode(detail.getPayerCcy());
		// 轉出匯率類型 TODO
		section.setRateType1("1");
		section.setCBRClass1(detail.getSourceOfFund());// 匯款分類一1
		section.setSourceOfFundSub(StringUtils.isBlank(detail.getSourceOfFundSub()) ? "" : detail.getSourceOfFundSub());// 匯款分類細項
		section.setCBRSubCode1(detail.getSourceOfFundSub());// 匯款分類69x細分類
		section.setCbrreq1("");// 申報註記1
		section.setCBRTxnType1("S");// 交易類型1
		
		// 付款人國別1
		section.setCBRCountry1(detail.getPayeeCountry());
		// 收款人國別2
		section.setCbrCountry2(detail.getPayeeCountry());
		// 申報註記2
		section.setCbrReq2("");
		// 交易編號
		section.setTxntNo("");
		// 受款銀行名稱  TODO 自行應該沒有
		section.setPayeeBankName(CosmosFxUtils.getConcatenateStr(detail.getPayeeBankName1(), detail.getPayeeBankName2()));
		// 受款銀行地址   TODO 自行應該沒有
		section.setPayeeBankAddr(CosmosFxUtils.getConcatenateStr(detail.getPayeeBankAddr1(), detail.getPayeeBankAddr2()));
		// 手續費扣款幣金額   TODO 自行應該沒有
		section.setCommission("");
		// 手續費本位幣金額  TODO 自行應該沒有
		section.setCommissionBcu(ConvertUtils.bigDecimal2Str(detail.getCommissionBcu()));
		// 郵電費扣款幣金額 TODO 自行應該沒有
		section.setPostage("");
		// 郵電費本位幣金額 TODO 自行應該沒有
		section.setPostageBcu(ConvertUtils.bigDecimal2Str(detail.getPostageBcu()));
		// 費用總金額 TODO 自行應該沒有
		section.setTotChg("");
		// 總扣款金額 TODO 自行應該沒有
		section.setTotPayAmt("");
		// 等值美金金額 
		section.setEquUsdAmt("");
		// 等值台幣金額
		section.setEquTwdAmt("");
		// 收款人Email
		section.setPayeeEmail(detail.getPayeeEmail());
		// 受款人地址
		section.setPayeeAddr(CosmosFxUtils.getConcatenateStr(detail.getPayeeAddr1(), detail.getPayeeAddr2()));
		// 受款人電話
		section.setPayeeTel(detail.getPayeePhone());
		
		String cnaps = StringUtils.defaultString(detail.getCnaps()); //大陸現代化支付系統帳號/受款銀行清算代碼 其中之一有值
		// 大陸現代化支付系統帳號
		section.setCnaps(cnaps.startsWith("CN") ? cnaps : "");
		// 附言
		section.setPaymentDetails(CosmosFxUtils.getConcatenateStr(detail.getPaymentdetails1(),
				detail.getPaymentdetails2(), detail.getPaymentdetails3(), detail.getPaymentdetails4()));
		// 外匯性質
		section.setCbTradeType("3");
		// 受款人身份別
		section.setOppoKind(StringUtils.equals("1", detail.getSelfFlag()) ? "5" : "4");
		// 受款銀行SWIFT
		section.setPayeeBankSwift(detail.getPayeeSwiftCode());
		// 受款銀行清算代碼
		section.setPayeeBankAcno(cnaps.startsWith("CN") ? "" : cnaps);
		// 中間銀行SWIFT
		section.setIntrBankSwift(detail.getMiddleSwiftCode());
		// 內扣外繳
		section.setDeductFeeFlag(detail.getChargeAmtType4Rq());
		// 發動端平台代號一般文字欄位，右補空白"CB":企網銀 "KG":新核心
		section.setApplicationId("CB");
		// 客戶英文名稱
		section.setCustName(CosmosFxUtils.getConcatenateStr(detail.getPayerEngName(), StringUtils.substring(addr, 0, 35)));
		// 客戶英文地址
		section.setCustAddr(StringUtils.substring(addr, 35));
		
		int txntType = fxScenarioType.getTxntType(TxType.REALTIME);
		// 交易類型
		section.setTxntType(String.valueOf(txntType));
		// 客戶所屬分行別
		section.setBsnUnit(company.getMgnBankId());
		// 交易生效日
		section.setValidDate(DateUtils.getISODateStr(txDate, ""));
		
		if (detail.getScenario() == 21) {
			// 外幣轉台幣,幣別皆填入外幣
			// 付款幣別
			section.setPayCcy(detail.getPayerCcy());
			// 匯款幣別
			section.setRemitCcy(detail.getPayerCcy());
//			section.setTxntCcy(detail.getPayerCcy());

		}
		else {
			// 付款幣別
			section.setPayCcy(detail.getPayerCcy());
			// 匯款幣別
			section.setRemitCcy(detail.getPayeeCcy());
//			section.setTxntCcy(detail.getTxAmtCcy());
		}
		
		// 填入議價編號,成交匯率
		if (StringUtils.isNotBlank(detail.getExCntrNo())) {
			// 議價編號
			section.setExCntrno(detail.getExCntrNo());
			// 成交匯率
			section.setExrate(ConvertUtils.bigDecimal2Str(detail.getExRate()));
		}
		else {
			// 議價編號
			section.setExCntrno("");
			// 成交匯率
			section.setExrate("0");
		}

		// 取得客戶當下外幣匯率優惠設定
		ExchangeRateEntity exchangeRate;
		try {
			exchangeRate = getExchangeRate(company, detail.getPayerCcy(), detail.getPayeeCcy());
		}
		catch (DatabaseException e) {
			CibErrorCode code = CibErrorCode.DATABASE_EXCEPTION;
			throw new ActionException(code.getSystemId(), code.getErrorCode(), ICommonCode.SEVERITY_ERROR, code.getMemo());
		}
		
		if (exchangeRate == null || exchangeRate.getRateType() == 1) {
			System.out.println("外幣匯率優惠設定:不優惠");
			section.setSpreadBSpot("0");
			section.setSpreadSSpot("0");
		}
		else if (exchangeRate.getRateType() == 2) {
			System.out.println("外幣匯率優惠設定:2,B:" + ConvertUtils.bigDecimal2Str(exchangeRate.getBrate()) + ",S:" + ConvertUtils.bigDecimal2Str(exchangeRate.getSrate()));
			section.setSpreadBSpot(ConvertUtils.bigDecimal2Str(exchangeRate.getBrate()));
			section.setSpreadSSpot(ConvertUtils.bigDecimal2Str(exchangeRate.getSrate()));
		}
		
		section.setSourceOfFund(detail.getSourceOfFund());// 匯款分類
		section.setFullPayment(CosmosFxUtils.getPayment(detail));// 匯出匯款方式
		section.setCustTel(detail.getPayerPhone());// 客戶聯絡電話
		
		String custBirthday = "";
		String custKindCbMemo = "";
		String foreignStartDateString = "";
		String foreignEndDateString = "";
		String idType = "";
		
		if (!StringUtils.equals("TWD", detail.getPayerCcy())) {
			List<Bns06750300qView> result = null;
			try {
				// 付款人payer央媒申報欄位
				result = dao.findByIdNoAndAccountNo(detail.getPayerUid(), detail.getPayerAccountNo(), "KPDB01_UAT", "CNBT_KPSERVER");
			}
			catch (DatabaseException e) {
				CibErrorCode code = CibErrorCode.DATABASE_EXCEPTION;
				throw new ActionException(code.getSystemId(), code.getErrorCode(), ICommonCode.SEVERITY_ERROR, code.getMemo());
			}
			
			if (result == null || result.size() == 0) {
				CibErrorCode code = CibErrorCode.DATA_NOT_FOUND;
				throw new ActionException(code.getSystemId(), code.getErrorCode(), ICommonCode.SEVERITY_ERROR, code.getMemo());
			}
			
			payerCBR = result.get(0);
			
			Company payerCompany;
			try {
				payerCompany = B2CUaaBoUtils.getCompany(detail.getPayerUid());
			} catch (DatabaseException e) {
				CibErrorCode code = CibErrorCode.DATABASE_EXCEPTION;
				throw new ActionException(code.getSystemId(), code.getErrorCode(), ICommonCode.SEVERITY_ERROR, code.getMemo());
			}
			// 若非外匯客戶
			if (payerCompany.isDBU()) {
				custBirthday = DateUtils.formatDate(payerCBR.getBirthDate1(), "ddMMyyyy");
				custKindCbMemo = payerCBR.getRemitterPayeeTyp();
				idType = payerCBR.getIdType();
				
				// 若非外匯客戶且持居留證, 則須填入rsdntIssueDate居留證核發日期,rsdntValidDate居留證有效期限
				if (StringUtils.equals(StringUtils.left(custKindCbMemo, 1), "4")) {
					foreignEndDateString = DateUtils.formatDate(payerCBR.getIdExpiDate(), "ddMMyyyy");
					foreignStartDateString = DateUtils.formatDate(payerCBR.getIdIssueDate(), "ddMMyyyy");
				}
			}
		}
		
		// 客戶生日(付款人)
		section.setCustBirthday(custBirthday);
		// 客戶身份別(付款人)
		section.setCustKindCbMemo(custKindCbMemo);
		// 證件類型(付款人)
		section.setIdType(idType);
		// 證件號碼(付款人)
		section.setIdNo(detail.getPayerUid());
		// 居留證核發日期(付款人) (DDMMYYYY)
		section.setRsdntIssueDate(foreignStartDateString);
		// 居留證有效期限(付款人) (DDMMYYYY)
		section.setRsdntValidDate(foreignEndDateString);
		
		String custBirthday2 = "";
		String custKindCbMemo2 = "";
		String foreignStartDateString2 = "";
		String foreignEndDateString2 = "";
		String idType2 = "";
		String idNo2 = "";
		
		if (!StringUtils.equals("TWD", detail.getPayeeCcy())) {
			List<Bns06750300qView> result = null;
			try {
				// 收款人payee央媒申報欄位
				result = dao.findByIdNoAndAccountNo(detail.getPayeeId(), detail.getPayeeAccountNo(), "KPDB01_UAT", "CNBT_KPSERVER");
			}
			catch (DatabaseException e) {
				CibErrorCode code = CibErrorCode.DATABASE_EXCEPTION;
				throw new ActionException(code.getSystemId(), code.getErrorCode(), ICommonCode.SEVERITY_ERROR, code.getMemo());
			}
			
			if (result == null || result.size() == 0) {
				CibErrorCode code = CibErrorCode.DATA_NOT_FOUND;
				throw new ActionException(code.getSystemId(), code.getErrorCode(), ICommonCode.SEVERITY_ERROR, code.getMemo());
			}

			payeeCBR = result.get(0);
			
			custBirthday2 = DateUtils.formatDate(payeeCBR.getBirthDate1(), "ddMMyyyy");
			custKindCbMemo2 = payeeCBR.getRemitterPayeeTyp();
			idType2 = payeeCBR.getIdType();
			idNo2 = payeeCBR.getIdNo();
			// 若非外匯客戶且持居留證, 則須填入rsdntIssueDate居留證核發日期,rsdntValidDate居留證有效期限
			if (StringUtils.equals(StringUtils.left(payeeCBR.getRemitterPayeeTyp(), 1), "4")) {
				foreignEndDateString2 = DateUtils.formatDate(payeeCBR.getIdExpiDate(), "ddMMyyyy");
				foreignStartDateString2 = DateUtils.formatDate(payeeCBR.getIdIssueDate(), "ddMMyyyy");
			}
		}
			
		//客戶生日(收款人) (DDMMYYYY)
		section.setCustBirthday2(custBirthday2);
		//客戶身份別(收款人)
		section.setCustKindCbMemo2(custKindCbMemo2);
		//證件類型(收款人)
		section.setIdType2(idType2);
		//證件號碼(收款人)
		section.setIdNo2(idNo2);
		//居留證核發日期(收款人) (DDMMYYYY)
		section.setRsdntIssueDate2(foreignStartDateString2);
		//居留證有效期限(收款人) (DDMMYYYY)
		section.setRsdntValidDate2(foreignEndDateString2);

		//UUID
		section.setUUID(CosmosSequenceUtils.generateESBUuid()); // FIXME 要用新的uuid
		
		// 為了與畫面parse一致,讀入資料的secNo由1開始
		section.getFileSection().setSectionNo(1);

		fileFormat.addDetails(section);
	}
	
	
	private static void prepareDetail2(Cactx502ResultN2NFileFormat fileFormat, String pmtId, Date txDate) throws ActionException, DatabaseException, MQException{

		// FIXME 使用DB裡單筆的資料
		// 匯款 - flowDocId=1806110043376, scenario=13	
		List<String> flowDocIds = new ArrayList<String>();
		flowDocIds.add("1806110043376");
		IFxDocViewDao fxDocViewDao = CosmosDaoFactory.getFxDocViewDao();
		FxDocView fxDocView = fxDocViewDao.findByFlowDocIds(flowDocIds).get(0);
		FxQueryDetailDoc detail = new FxQueryDetailDoc(fxDocView);
		
		// 操作者公司
		Company company = B2CUaaBoUtils.getCompany(detail.getCompanyKey());
		
		// 試算
		Frn55sRs frn55s = queryFrn55s(detail, company);
		
		FxScenarioType fxScenarioType = FxScenarioType.valueOf(detail.getScenario());
		
		prepareMixfrn56u00bDetail(fileFormat, pmtId, detail, txDate, fxScenarioType, company, frn55s);
		
	}
	
	
	private static void prepareMixfrn56u00bDetail(Cactx502ResultN2NFileFormat fileFormat, String pmtId, IFxDetailDoc detail, 
			Date txDate, FxScenarioType fxScenarioType, Company company, Frn55sRs frn55s) throws ActionException {
		
		totalCount++;
		totalAmt = totalAmt.add(detail.getTxAmt());
		
		Cactx502ResultN2NTxFileSection section = new Cactx502ResultN2NTxFileSection();
		// 批號PBMT-BATCH-NO
		section.setBatchNo(pmtId);
		// 流水號
		section.setSerno(detail.getSendSerialNo());
		// 付款通路 1-自行轉帳, 2-自行匯款, 3-匯出匯款
		section.setPayChanel(String.valueOf(fxScenarioType.getChannelType()));
		// 付款人帳號
		section.setPayerAccountNo(detail.getPayerAccountNo());
		// 付款人戶名
		String addr = detail.getPayerEngAddress();
		String payerName = CosmosFxUtils.getConcatenateStr(detail.getPayerEngName(), StringUtils.substring(addr, 0, 35));// 客戶英文名稱35*2分2行, 每行35字
		section.setPayerName(payerName); 
		// 付款人統編
//		section.setPayerUid(detail.getPayerUid()); 
		// 收款銀行代號 TODO
		// TODO 要帶甚麼?
		section.setReceiveBankCode("");
		
		// 轉入帳號
		section.setRollInAcct(detail.getPayeeAccountNo());
		// 交易金額
		section.setAmount(StringUtils.remove(ConvertUtils.bigDecimal2Str(detail.getTxAmt(), 3),"."));
		// 提示碼 
		section.setPromoCode(CosmosCommonId.PROMOCODE);
		// 存摺附註 TODO ??
		section.setRemarks("");
		// 檢核ID TODO ??
//		section.setCheckId("");
//		// 檢核戶名 TODO ??
//		section.setCheckName("");
		// 櫃員手續費/匯款手續費 ?? TODO
		section.setFee("");
		// 附言
		section.setPostScript(CosmosFxUtils.getConcatenateStr(detail.getPaymentdetails1(), detail.getPaymentdetails2(), detail.getPaymentdetails3(), detail.getPaymentdetails4()));
		// BaNCS中心執行結果
		section.setBancsStat("9999");
		// 匯款處理結果(他行)
		section.setNefxStat("");
		// ESB_STAT
		section.setNefxStat("");
		// 交易序號 , 9個0
		section.setJrnlNo("");
		// 付款帳號幣別
		section.setPayAcctCurrcode(detail.getPayerCcy());
		// 轉出匯率類型 TODO
		section.setRateType1("");
		section.setCBRClass1(detail.getSourceOfFund());// 匯款分類一1
		section.setSourceOfFundSub(StringUtils.isBlank(detail.getSourceOfFundSub()) ? "" : detail.getSourceOfFundSub());// 匯款分類細項
		section.setCBRSubCode1(detail.getSourceOfFundSub());// 匯款分類69x細分類
		section.setCbrreq1("");// 申報註記1
		section.setCBRTxnType1("S");// 交易類型1
		// 付款人國別1
		section.setCBRCountry1(detail.getPayeeCountry());
		// 收款人國別2
		section.setCbrCountry2(detail.getPayeeCountry());
		// 申報註記2
		section.setCbrReq2("");
		// 交易編號
		section.setTxntNo("");
		// 受款銀行名稱 
		section.setPayeeBankName(CosmosFxUtils.getConcatenateStr(detail.getPayeeBankName1(), detail.getPayeeBankName2()));
		// 受款銀行地址 
		section.setPayeeBankAddr(CosmosFxUtils.getConcatenateStr(detail.getPayeeBankAddr1(), detail.getPayeeBankAddr2()));
		// 手續費扣款幣金額 9(11).9(02)
		section.setCommission(StringUtils.remove(ConvertUtils.bigDecimal2Str(detail.getCommission(), 2), "."));
		// 手續費本位幣金額 9(11).9(02)
		section.setCommissionBcu(StringUtils.remove(ConvertUtils.bigDecimal2Str(detail.getCommissionBcu(), 2), "."));
		// 郵電費扣款幣金額 9(11).9(02)
		section.setPostage(StringUtils.remove(ConvertUtils.bigDecimal2Str(detail.getPostage(), 2), "."));
		// 郵電費本位幣金額 9(11).9(02)
		section.setPostageBcu(StringUtils.remove(ConvertUtils.bigDecimal2Str(detail.getPostageBcu(), 2), "."));
		// 費用總金額 9(11).9(02)
		section.setTotChg(StringUtils.remove(ConvertUtils.bigDecimal2Str(detail.getTotChg(), 2), "."));
		// 總扣款金額 9(13).9(02)
		section.setTotPayAmt(StringUtils.remove(ConvertUtils.bigDecimal2Str(detail.getTotalAmt(), 2), "."));
		// 等值美金金額 9(13).9(02)
		section.setEquUsdAmt(StringUtils.remove(ConvertUtils.bigDecimal2Str(detail.getEquUsdAmt(), 2), "."));
		// 等值台幣金額 9(13).9(02)
		section.setEquTwdAmt(StringUtils.remove(ConvertUtils.bigDecimal2Str(detail.getEquTwdAmt(), 2), "."));
		// 收款人Email
		section.setPayeeEmail(detail.getPayeeEmail());
		// 受款人地址
		section.setPayeeAddr(CosmosFxUtils.getConcatenateStr(detail.getPayeeAddr1(), detail.getPayeeAddr2()));
		// 受款人電話
		section.setPayeeTel(detail.getPayeePhone());
		
		String cnaps = StringUtils.defaultString(detail.getCnaps()); //大陸現代化支付系統帳號/受款銀行清算代碼 其中之一有值
		// 大陸現代化支付系統帳號
		section.setCnaps(cnaps.startsWith("CN") ? cnaps : "");
		// 附言
		section.setPaymentDetails(CosmosFxUtils.getConcatenateStr(detail.getPaymentdetails1(),
				detail.getPaymentdetails2(), detail.getPaymentdetails3(), detail.getPaymentdetails4()));
		// 外匯性質
		section.setCbTradeType("3");
		// 受款人身份別
		section.setOppoKind(StringUtils.equals("1", detail.getSelfFlag()) ? "5" : "4");
		// 受款銀行SWIFT
		section.setPayeeBankSwift(detail.getPayeeSwiftCode());
		// 受款銀行清算代碼
		section.setPayeeBankAcno(cnaps.startsWith("CN") ? "" : cnaps);
		// 中間銀行SWIFT
		section.setIntrBankSwift(detail.getMiddleSwiftCode());
		// 內扣外繳
		section.setDeductFeeFlag(detail.getChargeAmtType4Rq());
		// 發動端平台代號一般文字欄位，右補空白"CB":企網銀 "KG":新核心
		section.setApplicationId("CB");
		// 客戶英文名稱
		section.setCustName(CosmosFxUtils.getConcatenateStr(detail.getPayerEngName(), StringUtils.substring(addr, 0, 35)));
		// 客戶英文地址
		section.setCustAddr(StringUtils.substring(addr, 35));
		
		int txntType = fxScenarioType.getTxntType(TxType.REALTIME);
		// 交易類型
		section.setTxntType(String.valueOf(txntType));
		// 客戶所屬分行別
		section.setBsnUnit(company.getMgnBankId());
		// 交易生效日
		section.setValidDate(DateUtils.getISODateStr(txDate, ""));
		
		if (detail.getScenario() == 21) {
			// 外幣轉台幣,幣別皆填入外幣
			// 付款幣別
			section.setPayCcy(detail.getPayerCcy());
			// 匯款幣別
			section.setRemitCcy(detail.getPayerCcy());
//			section.setTxntCcy(detail.getPayerCcy());

		}
		else {
			// 付款幣別
			section.setPayCcy(detail.getPayerCcy());
			// 匯款幣別
			section.setRemitCcy(detail.getPayeeCcy());
//			section.setTxntCcy(detail.getTxAmtCcy());
		}
		
		// 填入議價編號,成交匯率
		if (StringUtils.isNotBlank(detail.getExCntrNo())) {
			// 議價編號
			section.setExCntrno(detail.getExCntrNo());
			// 成交匯率
			section.setExrate(ConvertUtils.bigDecimal2Str(detail.getExRate()));
		}
		else {
			// 議價編號
			section.setExCntrno("");
			// 成交匯率
			section.setExrate("0");
		}

		// 取得客戶當下外幣匯率優惠設定
		ExchangeRateEntity exchangeRate;
		try {
			exchangeRate = getExchangeRate(company, detail.getPayerCcy(), detail.getPayeeCcy());
		}
		catch (DatabaseException e) {
			CibErrorCode code = CibErrorCode.DATABASE_EXCEPTION;
			throw new ActionException(code.getSystemId(), code.getErrorCode(), ICommonCode.SEVERITY_ERROR, code.getMemo());
		}
		
		if (exchangeRate == null || exchangeRate.getRateType() == 1) {
			System.out.println("外幣匯率優惠設定:不優惠");
			section.setSpreadBSpot("0");
			section.setSpreadSSpot("0");
		}
		else if (exchangeRate.getRateType() == 2) {
			System.out.println("外幣匯率優惠設定:2,B:" + ConvertUtils.bigDecimal2Str(exchangeRate.getBrate()) + ",S:" + ConvertUtils.bigDecimal2Str(exchangeRate.getSrate()));
			section.setSpreadBSpot(ConvertUtils.bigDecimal2Str(exchangeRate.getBrate()));
			section.setSpreadSSpot(ConvertUtils.bigDecimal2Str(exchangeRate.getSrate()));
		}
		
		section.setSourceOfFund(detail.getSourceOfFund());// 匯款分類
		section.setFullPayment(CosmosFxUtils.getPayment(detail));// 匯出匯款方式
		section.setCustTel(detail.getPayerPhone());// 客戶聯絡電話
		
		String custBirthday = "";
		String custKindCbMemo = "";
		String foreignStartDateString = "";
		String foreignEndDateString = "";
		
		IBns06750300qViewDao dao = CosmosDaoFactory.getBns06750300qViewDao();
		// 付款人payer央媒申報欄位
		Bns06750300qView payerCBR = null;
		List<Bns06750300qView> result = null;
		try {
			// 付款人payer央媒申報欄位
			result = dao.findByIdNoAndAccountNo(detail.getPayerUid(), detail.getPayerAccountNo(), "KPDB01_UAT", "CNBT_KPSERVER");
		}
		catch (DatabaseException e) {
			CibErrorCode code = CibErrorCode.DATABASE_EXCEPTION;
			throw new ActionException(code.getSystemId(), code.getErrorCode(), ICommonCode.SEVERITY_ERROR, code.getMemo());
		}
		
		if (result == null || result.size() == 0) {
			CibErrorCode code = CibErrorCode.DATA_NOT_FOUND;
			throw new ActionException(code.getSystemId(), code.getErrorCode(), ICommonCode.SEVERITY_ERROR, code.getMemo());
		}

		payerCBR = result.get(0);

		Company payerCompany;
		try {
			payerCompany = B2CUaaBoUtils.getCompany(detail.getPayerUid());
		} catch (DatabaseException e) {
			CibErrorCode code = CibErrorCode.DATABASE_EXCEPTION;
			throw new ActionException(code.getSystemId(), code.getErrorCode(), ICommonCode.SEVERITY_ERROR, code.getMemo());
		}
		// 若非外匯客戶
		if (payerCompany.isDBU()) {
			custBirthday = DateUtils.formatDate(payerCBR.getBirthDate1(), "ddMMyyyy");
			custKindCbMemo = payerCBR.getRemitterPayeeTyp();

			// 若非外匯客戶且持居留證, 則須填入rsdntIssueDate居留證核發日期,rsdntValidDate居留證有效期限
			if (StringUtils.equals(StringUtils.left(custKindCbMemo, 1), "4")) {
				foreignEndDateString = DateUtils.formatDate(payerCBR.getIdExpiDate(), "ddMMyyyy");
				foreignStartDateString = DateUtils.formatDate(payerCBR.getIdIssueDate(), "ddMMyyyy");
			}
		}
		// 客戶生日(付款人)
		section.setCustBirthday(custBirthday);
		// 客戶身份別(付款人)
		section.setCustKindCbMemo(custKindCbMemo);
		// 證件類型(付款人)
		section.setIdType(payerCBR.getIdType());
		// 證件號碼(付款人)
		section.setIdNo(detail.getPayerUid());
		// 居留證核發日期(付款人) (DDMMYYYY)
		section.setRsdntIssueDate(foreignStartDateString);
		// 居留證有效期限(付款人) (DDMMYYYY)
		section.setRsdntValidDate(foreignEndDateString);
		
		// TODO MIXFRN56U以下收款人應該不用設定
		//客戶生日(收款人) (DDMMYYYY)
		section.setCustBirthday2("");
		//客戶身份別(收款人)
		section.setCustKindCbMemo2("");
		//證件類型(收款人)
		section.setIdType2("");
		//證件號碼(收款人)
		section.setIdNo2("");
		//居留證核發日期(收款人) (DDMMYYYY)
		section.setRsdntIssueDate2("");
		//居留證有效期限(收款人) (DDMMYYYY)
		section.setRsdntValidDate2("");

		//UUID
		section.setUUID(CosmosSequenceUtils.generateESBUuid()); // FIXME 要用新的uuid
		
		// 為了與畫面parse一致,讀入資料的secNo由1開始
		section.getFileSection().setSectionNo(1);

		fileFormat.addDetails(section);
		
	}
	
	

	private static void testImportFile(String fileName) throws JSchException, SftpException, IOException, ActionException {

		// byte[] fileContent = FileUtils.readFileToByteArray(new
		// File("C:/ACHBACKUP/"+fileName));

		byte[] fileContent = null;
		ChannelSftp sftp = null;
		ByteArrayOutputStream os = new ByteArrayOutputStream();
		try {
			sftp = SFTPUtils.connect(server, port, user_get, password_get, "/");

			sftp.get(fileName, os);

			fileContent = os.toByteArray();

			if (fileContent == null) {
				System.err.println("sftp download file Error, fileName:" + fileName);
			}

		}
		catch (JSchException e) {
			System.err.println("SFTP連線失敗");
			e.printStackTrace();
			throw e;
		}
		catch (SftpException e) {
			e.printStackTrace();
			throw e;
		}
		finally {
			try {
				os.close();
				SFTPUtils.disconnect(sftp);
			}
			catch (JSchException e) {
				System.err.println("SFTP離線失敗");
				e.printStackTrace();
			}
			catch (IOException e) {
				System.err.println("ByteArrayOutputStream close failed , fileName:" + fileName);
				e.printStackTrace();
			}
		}

		Cactx502ResultN2NFileFormat fileFormat = new Cactx502ResultN2NFileFormat("CACTX502");
		boolean result = fileFormat.parseFile(fileContent);

		System.out.println("result:" + result);

		FileDoc fileDoc = fileFormat.getFileDoc();

		for (FileDetail fileDetail : fileDoc.getDetails()) {
			System.out.println("=================== " + fileDetail.getRowNo() + " ====================");

			FileSection fileSection = fileDetail.getFirstSection();
			if (fileDetail.getFirstSection().getFieldGroup() == FieldGroup.HEADER) {
				Cactx502ResultN2NHeaderFileSection header = new Cactx502ResultN2NHeaderFileSection(fileSection);
				System.out.println("==========Header==========");
				System.out.println("getBranchNo:" + header.getBranchNo());
//				System.out.println("getPayerAccountNo:" + header.getPayAcct());
//				System.out.println("getPayerName:" + header.getPayName());

			}
			else if (fileDetail.getFirstSection().getFieldGroup() == FieldGroup.FOOTER) {
				Cactx502ResultN2NFooterFileSection footer = new Cactx502ResultN2NFooterFileSection(fileSection);
				System.out.println("==========Footer==========");
				System.out.println("getTotalCount:" + footer.getTotalCount());
				System.out.println("getTotalAmt:" + footer.getTotalAmt());

			}
			else {
				Cactx502ResultN2NTxFileSection detail = new Cactx502ResultN2NTxFileSection(fileSection);
				System.out.println("==========Tx==========");
				System.out.println("getBatchNo:" + detail.getBatchNo());
				System.out.println("getSerno:" + detail.getSerno());
				System.out.println("getPayChanel:" + detail.getPayChanel());

				System.out.println("getReceiveBankCode:" + detail.getReceiveBankCode());
				System.out.println("getTxAmt:" + detail.getAmount());
				System.out.println("getRemarks:" + detail.getRemarks());
				System.out.println("BaNCS中心執行結果getBancsStat:" + detail.getBancsStat());
				System.out.println("getNefxStat:" + detail.getNefxStat());
				System.out.println("getEsbStat:" + detail.getEsbStat());
				System.out.println("交易序號getJournalNo:" + detail.getJrnlNo());
				System.out.println("getTxntNo:" + detail.getTxntNo());
				System.out.println("getEquTwdAmt:" + detail.getEquTwdAmt());
				System.out.println("getEquUsdAmt:" + detail.getEquUsdAmt());
				
				System.out.println("getCommission:" + detail.getCommission());
				System.out.println("getCommissionBcu:" + detail.getCommissionBcu());
				System.out.println("getPostage:" + detail.getPostage());
				System.out.println("getPostageBcu:" + detail.getPostageBcu());
				System.out.println("getTotChg:" + detail.getTotChg());
				System.out.println("getTotPayAmt:" + detail.getTotPayAmt());
				
				System.out.println("getBdSeq:" + detail.getBdSeq());
			}

		}

	}

	/*
	 * 來源檔檔案名稱：9999(流程識別碼)+9999(主辦分行代碼)+交易日期(西元年DDMMYYYY)+999999999999999999999999
	 * (批號).TXT
	 */
	private static String getFileName(Date txDate, String batchNo) {

		return WORDKING_DIR + "0001" + DateUtils.formatDate(txDate, "ddMMyyyy") + StringUtils.leftPad(batchNo, 24, "0");
	}

	public static String generateCaseNo() throws DatabaseException {
		String value = "";
		IB2CSequenceDao dao = (IB2CSequenceDao) AOPProxyFactory.getDao(IB2CSequenceDao.class, B2CSequenceDao.class);
		String caseNoSeq = StringUtils.leftPad(String.valueOf(dao.getCaseNoSeq() % 10000000), 7, "0");
		value = DateUtils.getSimpleISODateStr(new Date()).substring(2) + caseNoSeq;
		return value;
		
	}

	/** 系統參數代碼表 */
	private static Map<SystemParamEntityPk, String> systemParamMap = null;

	/**
	 * 載入系統參數
	 */
	synchronized private static void loadSystemParamMap() {

		if (systemParamMap != null) {
			return;
		}

		systemParamMap = new Hashtable<SystemParamEntityPk, String>();

		ISystemParamDao dao = CosmosDaoFactory.getSystemParamDao();

		try {

			// System.err.println("loadSystemParamMap");

			List<SystemParamEntity> entities = dao.findAll();

			for (SystemParamEntity entity : entities) {

				SystemParamEntityPk pk = new SystemParamEntityPk(entity.getCategory(), entity.getKey());

				String value = StringUtils.trimToEmpty(entity.getValue());

				// 加入密碼 DECRYPT 的功能
				if (1 == entity.getPasswordFlag()) {
					value = DESUtils.decrypt(value);
				}

				systemParamMap.put(pk, value);

			}
		}
		catch (DatabaseException e) {
			throw new RuntimeException("cannot load SystemParam ", e);
		}
		catch (CryptException e) {
			throw new RuntimeException("cannot load SystemParam ", e);
		}

	}

	public static Map<SystemParamEntityPk, String> getSystemParamMap() {

		if (null == systemParamMap) {
			loadSystemParamMap();
		}
		return systemParamMap;
	}

	/**
	 * 取得參數值
	 * 
	 * @param param
	 * @return
	 */
	public static String getSystemParamValue(ISystemParam param) {

		SystemParamEntityPk pk = new SystemParamEntityPk(param.getCategory().getCode(), param.getKey());

		return getSystemParamMap().get(pk);
	}
	
	
	public static Bns08550000qRs queryBns0855000Q(FxQueryDetailDoc detail) throws ActionException, MQException {

		Bns08550000qRs rs = null;
		Bns08550000qRq rq;
		try {
			rq = getBns0855000QRq(detail);
			rs = (Bns08550000qRs) doBns08550000qSyncTxn(rs, rq);

			return rs;

		}
		catch (EsbException e) {
			e.printStackTrace();
		}
		return rs;
	}
	
	public static Bns08550000qRq getBns0855000QRq(FxQueryDetailDoc detail) {
		Bns08550000qRq rq = new Bns08550000qRq();
		
		rq.setClientId("EB");
		rq.setClientDt(new Date());
		String clientPwd = "4df9d6415edac9ea7c3dbd1691d0b132";
		try {
			clientPwd = CosmosCryptUtils.decryptEsbPwd(clientPwd);
			rq.setClientPwd(CosmosCryptUtils.encryptEsbPwd(clientPwd, DateFormatUtils.CLIENTDT_FORMAT.format(rq.getClientDt())));
		}
		catch (CryptException e) {
			e.printStackTrace();
		}
		
		// Svc header
		rq.getBNSHeader().setFlagX("");
		rq.getBNSHeader().setFlag4("L");
		rq.getBNSHeader().setChannelId("01");
		rq.setUUID(String.valueOf((new Date()).getTime()));
		
		rq.setRateTypeAcct("01"); // 即期
		rq.setCRFromCurrency(detail.getPayerCcy());// 轉出幣別
		rq.setCRToCurrency(detail.getPayeeCcy());// 轉入幣別
		// 轉出金額與轉入金額需擇一輸入
		if (StringUtils.equals(detail.getTxAmtCcy(), detail.getPayerCcy())) {
			rq.setCRFromAmount(ConvertUtils.bigDecimal2Str(detail.getTxAmt()));
			rq.setCRToAmount("0");
		}
		else {
			rq.setCRFromAmount("0");
			rq.setCRToAmount(ConvertUtils.bigDecimal2Str(detail.getTxAmt()));
		}
		return rq;
	}
	
	private static Bns08550000qRs doBns08550000qSyncTxn(Bns08550000qRs preRs, Bns08550000qRq rq) throws EsbActionException, EsbException, MQException {
		
		System.out.println(rq.toXml());

		CMQStrMessage message = new CMQStrMessage();
		message.setMessage(rq.toXml().getBytes());

		sender.send(message);

		System.out.println(">>>>>>> Send OK");

		CMQStrMessage message2 = (CMQStrMessage) receiver.receive(message.getMessageId(), 50000);

		System.out.println(message2.getMessageStr());
		Bns08550000qRs rs = new Bns08550000qRs(message2.getMessageStr());

		return rs;

	}
	
	/**
	 * 取得客戶當下外幣匯率優惠設定
	 */
	public static ExchangeRateEntity getExchangeRate(Company company, String payerCcy, String payeeCcy) throws DatabaseException {
		System.out.println("取得 company key:" + company.getCompanyKey() + "的" + payerCcy + "," + payeeCcy + "匯率優惠設定");

		if (!StringUtils.equals("TWD", payerCcy) && !StringUtils.equals("TWD", payeeCcy)) {
			// 外幣轉外幣
			return null;
		}

		String ccy = StringUtils.equals("TWD", payerCcy) ? payeeCcy : payerCcy;

		IExchangeRateDao dao = CosmosDaoFactory.getExchangeRateDao();
		List<ExchangeRateEntity> entities = dao.findByCompanyNow(company.getCompanyKey());

		for (ExchangeRateEntity entity : entities) {
			if (StringUtils.equals(entity.getCurrencyId(), ccy))
				return entity;
		}

		return null;
	}
	
	public static Frn55sRs queryFrn55s(IFxDetailDoc fxDetailDoc, Company company) throws ActionException, MQException {

		Frn55sRs rs = null;

		Frn55sRq rq;
		try {
			rq = getFrn55sRq(fxDetailDoc, company);
			rs = (Frn55sRs) doFrn55sSyncTxn(rs, rq);
			System.out.println("rs:" + rs);

			return rs;
		}
		catch (EsbException e) {
			e.printStackTrace();
		}
		catch (DatabaseException e) {
			e.printStackTrace();
		}
		return rs;
	}
	
	public static Frn55sRq getFrn55sRq(IFxDetailDoc detail, Company company) throws EsbException, DatabaseException, ActionException {

		Frn55sRq rq = new Frn55sRq();
		
		rq.setCustid(company.getCompanyUid());
		rq.setCustidSub(detail.getPayerUid());
		rq.setCustName(detail.getPayerEngName());
		rq.setCustAddr(detail.getPayerEngAddress());

		String custBirthday = "";
		String custKindCbMemo = "";
		String foreignStartDateString = "";
		String foreignEndDateString = "";

		// 若非外匯客戶
		// Company company = user.getRelatedCompany(detail.getPayerUid());
		if (company.isDBU()) {
			custBirthday = DateUtils.getSimpleISODateStr(company.getBirthdate());
			custKindCbMemo = company.getPayerType();

			// 若非外匯客戶且持居留證, 則須填入rsdntIssueDate居留證核發日期,rsdntValidDate居留證有效期限
			if (StringUtils.equals(StringUtils.left(company.getPayerType(), 1), "4")) {

				// 若台外幣主機皆有值，頁面僅顯示外幣主機回傳值
				// 若僅一個有值，就顯示該值
				if (company.getForeignEndDatef() != null) {
					foreignEndDateString = DateUtils.getSimpleISODateStr(company.getForeignEndDatef());
				}
				else if (company.getForeignEndDate() != null) {
					foreignEndDateString = DateUtils.getSimpleISODateStr(company.getForeignEndDate());
				}

				foreignStartDateString = DateUtils.getSimpleISODateStr(company.getForeignStartDate());
			}
		}

		rq.setCustBirthday(custBirthday);
		rq.setCustKindCbMemo(custKindCbMemo);
		rq.setRsdntIssueDate(foreignStartDateString);
		rq.setRsdntValidDate(foreignEndDateString);

		// rq.setTxntType(String.valueOf(txntType));
		rq.setBsnUnit(company.getMgnBankId());

		FxScenarioType fxScenarioType = FxScenarioType.valueOf(detail.getScenario());
		// 若日期小於等於今日,則日期填入今日
		Date txDate = detail.getTxDate();
		Date now = new Date();
		DateUtils.clearTime(txDate);
		DateUtils.clearTime(now);
		if (txDate.compareTo(now) <= 0) {
			rq.setValidDate(DateUtils.getSimpleISODateStr(now));
		}
		else {
			rq.setValidDate(DateUtils.getSimpleISODateStr(detail.getTxDate()));
		}
		rq.setTxntType(String.valueOf(fxScenarioType.getTxntType(detail.getTxType())));
		System.out.println("String.valueOf(fxScenarioType.getTxntType(detail.getTxType())):" + String.valueOf(fxScenarioType.getTxntType(detail.getTxType())));

		rq.setPayAcno(detail.getPayerAccountNo());

		if (detail.getScenario() == 21) {
			// 外幣轉台幣,幣別皆填入外幣
			rq.setPayCcy(detail.getPayerCcy());
			rq.setRemitCcy(detail.getPayerCcy());
			rq.setTxntCcy(detail.getPayerCcy());

		}
		else {
			rq.setPayCcy(detail.getPayerCcy());
			rq.setRemitCcy(detail.getPayeeCcy());
			rq.setTxntCcy(detail.getTxAmtCcy());
		}

		rq.setTxntAmt(ConvertUtils.bigDecimal2Str(detail.getTxAmt()));
		rq.setPayeeAcno(detail.getPayeeAccountNo());

		// 填入議價編號,成交匯率
		if (StringUtils.isNotBlank(detail.getExCntrNo())) {
			rq.setExCntrno(detail.getExCntrNo());
			rq.setExrate(ConvertUtils.bigDecimal2Str(detail.getExRate()));
		}
		else {
			rq.setExCntrno("");
			rq.setExrate("0");
		}

		// 取得客戶當下外幣匯率優惠設定
		ExchangeRateEntity exchangeRate = getExchangeRate(company, detail.getPayerCcy(), detail.getPayeeCcy());

		if (exchangeRate == null || exchangeRate.getRateType() == 1) {
			System.out.println("外幣匯率優惠設定:不優惠");
			rq.setSpreadBSpot("0");
			rq.setSpreadSSpot("0");
		}
		else if (exchangeRate.getRateType() == 2) {
			System.out.println("外幣匯率優惠設定:2,B:" + ConvertUtils.bigDecimal2Str(exchangeRate.getBrate()) + ",S:" + ConvertUtils.bigDecimal2Str(exchangeRate.getSrate()));
			rq.setSpreadBSpot(ConvertUtils.bigDecimal2Str(exchangeRate.getBrate()));
			rq.setSpreadSSpot(ConvertUtils.bigDecimal2Str(exchangeRate.getSrate()));
		}

		rq.setAreaCode(detail.getPayeeCountry());
		rq.setSourceOfFund(detail.getSourceOfFund());
		rq.setSourceOfFundSub(detail.getSourceOfFundSub());

		rq.setPayeeName(CosmosFxUtils.getConcatenateStr(detail.getPayeeName1(), detail.getPayeeName2()));
		rq.setPayeeAddr(CosmosFxUtils.getConcatenateStr(detail.getPayeeAddr1(), detail.getPayeeAddr2()));
		rq.setPayeeBankName(CosmosFxUtils.getConcatenateStr(detail.getPayeeBankName1(), detail.getPayeeBankName2()));
		rq.setPayeeBankAddr(CosmosFxUtils.getConcatenateStr(detail.getPayeeBankAddr1(), detail.getPayeeBankAddr2()));
		String cnaps = StringUtils.defaultString(detail.getCnaps());
		if (StringUtils.isNotEmpty(cnaps)) {
			if (cnaps.startsWith("CN")) {
				rq.setCnaps(cnaps);
			}
			else {
				rq.setPayeeBankAcno(cnaps);
			}
		}
		rq.setPayeeBankSwift(detail.getPayeeSwiftCode());
		rq.setIntrBankSwift(detail.getMiddleSwiftCode());

		rq.setFullPayment(CosmosFxUtils.getPayment(detail));
		rq.setPaymentDetails(CosmosFxUtils.getConcatenateStr(detail.getPaymentdetails1(), detail.getPaymentdetails2(), detail.getPaymentdetails3(), detail.getPaymentdetails4()));

		System.out.println("detail.getCommissionBcu():" + detail.getCommissionBcu());
		System.out.println("detail.getPostageBcu():" + detail.getPostageBcu());

		rq.setCommissionBcu(ConvertUtils.bigDecimal2Str(detail.getCommissionBcu()));
		rq.setPostageBcu(ConvertUtils.bigDecimal2Str(detail.getPostageBcu()));

		// 目前先填3
		rq.setCbTradeType("3");

		detail.setLastPmtId(CosmosUtils.getNetMsgSeqno("NB", detail.getPayerUid()));

		// required
		rq.setMakerNo(detail.getPayerUid());
		rq.setSeqNo(detail.getLastPmtId());

		rq.setOppoKind(detail.getSelfFlag());

		// 費用內扣或外加
		rq.setDeductFeeFlag(detail.getChargeAmtType4Rq());

		return rq;
	}
	
	private static Frn55sRs doFrn55sSyncTxn(Frn55sRs preRs, Frn55sRq rq) throws EsbActionException, EsbException, MQException {

		System.out.println(rq.toXml());

		CMQStrMessage message = new CMQStrMessage();
		message.setMessage(rq.toXml().getBytes());

		sender.send(message);

		System.out.println(">>>>>>> Send OK");

		CMQStrMessage message2 = (CMQStrMessage) receiver.receive(message.getMessageId(), 50000);

		System.out.println(message2.getMessageStr());
		Frn55sRs rs = new Frn55sRs(message2.getMessageStr());

		return rs;

	}
	
}
