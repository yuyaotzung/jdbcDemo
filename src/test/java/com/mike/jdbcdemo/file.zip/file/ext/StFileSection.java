/*
 * ===========================================================================
 * IBM Confidential
 * AIS Source Materials
 * 
 * 
 * (C) Copyright IBM Corp. 2011.
 *
 * ===========================================================================
 */
package com.cosmos.file.ext;

import com.cosmos.file.bo.FileField;
import com.cosmos.file.bo.FileSection;
import com.cosmos.type.FieldGroup;
import com.ibm.tw.commons.util.StringUtils;

/**
 * <p>
 * 台幣自行授權扣帳檔案上傳檔案 明細資料
 * </p>
 * 
 * @author BearChen
 * @version 1.0, 2011/6/27
 * @see
 * @since
 */
public class StFileSection {

	/** 檔案區段 */
	private FileSection fileSection;

	public StFileSection(FileSection fileSection) {
		this.fileSection = fileSection;
	}

	public StFileSection(FieldGroup fieldGroup) {
		fileSection = new FileSection();
		fileSection.setFieldGroup(fieldGroup);
	}

	/**
	 * 入扣帳帳號
	 * 
	 * @return
	 */
	public String getAccountNo() {
		FileField fileField = fileSection.getField("accountNo");
		if (fileField == null) {
			return null;
		}
		else {

			String account = StringUtils.trim(fileField.getValue());

			if (StringUtils.length(account) == 12) {

				account = StringUtils.leftPad(account, 14, "0");

			}

			return account;
		}
	}
	
	/**
	 * 客戶上傳 入扣帳帳號
	 * 
	 * @return
	 */
	public String getAccountNoOri() {
		FileField fileField = fileSection.getField("accountNo");
		if (fileField == null) {
			return null;
		}
		else {
			return StringUtils.trim(fileField.getValue());
		}
	}

	/**
	 * 設定入扣帳帳號
	 * 
	 * @param value
	 */
	public void setAccountNo(String value) {
		setValue("accountNo", value);
	}

	/**
	 * 入扣帳客戶之統編
	 * 
	 * @return
	 */
	public String getCustomerUid() {
		FileField fileField = fileSection.getField("customerUid");
		if (fileField == null) {
			return null;
		}
		else {
			return StringUtils.trim(fileField.getValue());
		}
	}

	/**
	 * 設定入扣帳客戶之統編
	 * 
	 * @param value
	 */
	public void setCustomerUid(String value) {
		setValue("customerUid", value);
	}

	/**
	 * 轉帳代碼
	 * 
	 * @return
	 */
	public String getTransCode() {
		FileField fileField = fileSection.getField("transCode");
		if (fileField == null) {
			return null;
		}
		else {
			return fileField.getValue();
		}
	}

	/**
	 * 設定轉帳代碼
	 * 
	 * @param value
	 */
	public void setTransCode(String value) {
		setValue("transCode", value);
	}

	/**
	 * 交易日期
	 * 
	 * @return
	 */
	public String getTxDate() {
		FileField fileField = fileSection.getField("txDate");
		if (fileField == null) {
			return null;
		}
		else {
			return fileField.getValue();
		}
	}

	/**
	 * 設定交易日期
	 * 
	 * @param value
	 */
	public void setTxDate(String value) {
		setValue("txDate", value);
	}

	/**
	 * 帳號轉帳類別代號 1115 為入帳 1315為扣帳
	 * 
	 * @return
	 */
	public String getAccountType() {
		FileField fileField = fileSection.getField("accountType");
		if (fileField == null) {
			return null;
		}
		else {
			return fileField.getValue();
		}
	}

	/**
	 * 設定帳號轉帳類別代號 1115 為入帳 1315為扣帳
	 * 
	 * @param value
	 */
	public void setAccountType(String value) {
		setValue("accountType", value);
	}

	/**
	 * 交易金額
	 * 
	 * @return
	 */
	public String getTxAmt() {
		FileField fileField = fileSection.getField("txAmt");
		if (fileField == null) {
			return null;
		}
		else {
			return fileField.getValue();
		}
	}

	/**
	 * 設定交易金額
	 * 
	 * @param value
	 */
	public void setTxAmt(String value) {
		setValue("txAmt", value);
	}

	/**
	 * 發動者統編
	 * 
	 * @return
	 */
	public String getUid() {
		FileField fileField = fileSection.getField("uid");
		if (fileField == null) {
			return null;
		}
		else {
			return StringUtils.trim(fileField.getValue());
		}
	}

	/**
	 * 設定發動者統編
	 * 
	 * @param value
	 */
	public void setUid(String value) {
		setValue("uid", value);
	}

	/**
	 * 轉帳業務種類
	 * 
	 * @return
	 */
	public String getTransType() {
		FileField fileField = fileSection.getField("transType");
		if (fileField == null) {
			return null;
		}
		else {
			return StringUtils.trim(fileField.getValue());
		}
	}

	/**
	 * 設定轉帳業務種類
	 * 
	 * @param value
	 */
	public void setTransType(String value) {
		setValue("transType", value);
	}

	/**
	 * 客戶參考資料
	 * 
	 * @return
	 */
	public String getRemark() {
		FileField fileField = fileSection.getField("remark");
		if (fileField == null) {
			return null;
		}
		else {
			return StringUtils.trim(fileField.getValue());
		}
	}

	/**
	 * 設定客戶參考資料
	 * 
	 * @param value
	 */
	public void setRemark(String value) {
		setValue("remark", value);
	}

	/**
	 * 保留欄
	 * 
	 * @return
	 */
	public String getMemo() {
		FileField fileField = fileSection.getField("memo");
		if (fileField == null) {
			return null;
		}
		else {
			return StringUtils.trim(fileField.getValue());
		}
	}

	/**
	 * 設定保留欄
	 * 
	 * @param value
	 */
	public void setMemo(String value) {
		setValue("memo", value);
	}

	/**
	 * 結果欄
	 * 
	 * @return
	 */
	public String getResult() {
		FileField fileField = fileSection.getField("result");
		if (fileField == null) {
			return null;
		}
		else {
			return StringUtils.trim(fileField.getValue());
		}
	}

	/**
	 * 設定結果欄
	 * 
	 * @param value
	 */
	public void setResult(String value) {
		setValue("result", value);
	}

	public FileSection getFileSection() {
		return fileSection;
	}

	/**
	 * 
	 * @param fieldId
	 * @param value
	 */
	private void setValue(String fieldId, String value) {

		if (fileSection == null) {
			fileSection = new FileSection();
		}

		FileField field = fileSection.getField(fieldId);
		if (field == null) {
			field = new FileField();
			field.setFieldId(fieldId);
			field.setValue(value);
			fileSection.addField(field);
		}
		else {
			field.setValue(value);
		}
	}

}
