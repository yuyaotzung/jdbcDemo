/*
 * ===========================================================================
 * IBM Confidential
 * AIS Source Materials
 * 
 * 
 * (C) Copyright IBM Corp. 2011.
 *
 * ===========================================================================
 */
package com.cosmos.file.ext;

import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.cosmos.code.CibErrorCode;
import com.cosmos.file.FileFormatNew;
import com.cosmos.file.bo.FileDetail;
import com.cosmos.file.bo.FileDoc;
import com.cosmos.file.bo.FileSection;
import com.cosmos.file.ext.fx.FxFileSection;
import com.cosmos.type.FieldGroup;
import com.cosmos.type.TaskType;
import com.cosmos.type.TxBatchType;
import com.ibm.tw.commons.exception.ActionException;
import com.ibm.tw.commons.persistence.exception.DatabaseException;
import com.ibm.tw.commons.util.ConvertUtils;

/**
 * <p>
 * 多扣多入檔案格式
 * </p>
 * 
 * @author Leo
 * @version 1.0, 2011/6/8
 * @see
 * @since
 */
public abstract class SfFileFormat extends FileFormatNew {

	/** */
	private List<SfFileSection> details = new ArrayList<SfFileSection>();

	/** 整批類型 */
	public static TxBatchType TX_BATCH_TYPE;

	/**
	 * Constructor
	 * 
	 * @param loginUser
	 */
	public SfFileFormat(int companyKey, String taskId, TxBatchType txBachType) {
		super(companyKey, taskId, txBachType.getCode());
	}

	/**
	 * Constructor
	 * 
	 * @param fileFormatKey
	 */
	public SfFileFormat(String fileFormatKey, TxBatchType txBachType) throws DatabaseException {
		TX_BATCH_TYPE = txBachType;

		load(fileFormatKey);

		this.loaded = true;
	}

	@Override
	public FieldGroup getFormatCycle(int rowNo) {
		return null;
	}

	@Override
	public FieldGroup getFormatHead(int rowNo) {

		return FieldGroup.SF;

	}

	@Override
	public TaskType getTaskType() {
		if (TX_BATCH_TYPE.isUnknow()) {
			return TaskType.SF;
		}
		else {
			return TaskType.SF2;
		}
	}

	/**
	 * 
	 * @return
	 * @throws ActionException
	 */
	public byte[] toFile() throws ActionException {

		byte[] dataBuff = new byte[0];

		try {

			// 明細
			for (FileDetail detail : fileDoc.getDetails()) {
				if (!detail.isHeader()) {
					if (dataBuff.length > 0)
						dataBuff = concat(dataBuff, getLineSeparator().getBytes(ENCODING));
					dataBuff = concat(dataBuff, detailStringData(detail));
				}
			}

			return dataBuff;
		}
		catch (UnsupportedEncodingException e) {

			ActionException ex = getActionException(CibErrorCode.VALIDATE_SIZE_ERROR);

			throw ex;
		}
	}

	/**
	 * 加入明細
	 * 
	 * @param detail
	 */
	public void addDetails(SfFileSection detail) {
		details.add(detail);
		FileDetail fileDetail = new FileDetail();
		fileDetail.addSection(detail.getFileSection());
		getFileDoc().addDetail(fileDetail);
	}

	/**
	 * 2016/1/28 依幣別加總上傳總金額
	 * 
	 */
	public void addTotalTxAmt(FileDoc fileDoc, FileDetail detail) {
		Map<String, BigDecimal> txAmtMap = fileDoc.getTxAmtMap();
		BigDecimal totalTxAmt = ConvertUtils.str2BigDecimal(null, 0);
		BigDecimal detailTxAmt = ConvertUtils.str2BigDecimal(null, 0);
		String ccy = "";

		// 取得detail金額
		for (FileSection fileSection : detail.getSections()) {
			if (fileSection.getSectionNo() == 1) {
				SfFileSection section = new SfFileSection(fileSection);
				detailTxAmt = ConvertUtils.str2BigDecimal(section.getTxAmt(), 2);
				ccy = section.getTxCcy();
			}
		}
		// 取得幣別目前總金額
		totalTxAmt = txAmtMap.get(ccy);

		// 加總detail金額
		if (totalTxAmt == null) {
			txAmtMap.put(ccy, detailTxAmt);
		}
		else {
			totalTxAmt = totalTxAmt.add(detailTxAmt);
			txAmtMap.put(ccy, totalTxAmt);
		}

	}
}
