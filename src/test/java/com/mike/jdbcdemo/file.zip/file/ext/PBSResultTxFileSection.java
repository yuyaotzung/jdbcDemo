/*
 * ===========================================================================
 * IBM Confidential
 * AIS Source Materials
 * 
 * 
 * (C) Copyright IBM Corp. 2018.
 *
 * ===========================================================================
 */
package com.cosmos.file.ext;

import com.cosmos.file.bo.FileField;
import com.cosmos.file.bo.FileSection;
import com.cosmos.file.def.IFileDefinition;
import com.cosmos.file.def.PBSResultTxFileDefinition;
import com.cosmos.type.FieldGroup;
import com.ibm.tw.commons.util.StringUtils;

/**
 * <p>
 * 證券款檔案上傳至代收付 Tx格式
 * </p>
 * 
 * @author monica
 * @version 1.0, Feb 14, 2018
 * @see
 * @since
 */
public class PBSResultTxFileSection {

	/** 檔案區段 */
	private FileSection fileSection;

	public PBSResultTxFileSection() {
		fileSection = new FileSection();
		fileSection.setFieldGroup(FieldGroup.TX);
	}

	public PBSResultTxFileSection(FileSection fileSection) {
		this.fileSection = fileSection;
	}

	public FileSection getFileSection() {
		return fileSection;
	}

	public String getBatchNo() {
		return getValue(PBSResultTxFileDefinition.BATCH_NO);
	}

	public void setBatchNo(String value) {
		setValue(PBSResultTxFileDefinition.BATCH_NO, value);
	}

	public String getSerno() {
		return getValue(PBSResultTxFileDefinition.SERNO);
	}

	public void setSerno(String value) {
		setValue(PBSResultTxFileDefinition.SERNO, value);
	}

	public String getPayerAccountNo() {
		return getValue(PBSResultTxFileDefinition.PAYER_ACCOUNT_NO);
	}

	public void setPayerAccountNo(String value) {
		setValue(PBSResultTxFileDefinition.PAYER_ACCOUNT_NO, value);
	}

	public String getPayerIdNo() {
		return getValue(PBSResultTxFileDefinition.PAYER_ID_NO);
	}

	public void setPayerIdNo(String value) {
		setValue(PBSResultTxFileDefinition.PAYER_ID_NO, value);
	}

	public String getPayeeAccountTypeId() {
		return getValue(PBSResultTxFileDefinition.PAYEE_ACCOUNT_TYPE_ID);
	}

	public void setPayeeAccountTypeId(String value) {
		setValue(PBSResultTxFileDefinition.PAYEE_ACCOUNT_TYPE_ID, value);
	}

	public String getTxAmt() {
		return getValue(PBSResultTxFileDefinition.TX_AMT);
	}

	public void setTxAmt(String value) {
		setValue(PBSResultTxFileDefinition.TX_AMT, value);
	}

	public String getTransType() {
		return getValue(PBSResultTxFileDefinition.TRANS_TYPE);
	}

	public void setTransType(String value) {
		setValue(PBSResultTxFileDefinition.TRANS_TYPE, value);
	}

	public String getShopId() {
		return getValue(PBSResultTxFileDefinition.SHOP_ID);
	}

	public void setShopId(String value) {
		setValue(PBSResultTxFileDefinition.SHOP_ID, value);
	}

	public String getPayeeAccountNo() {
		return getValue(PBSResultTxFileDefinition.PAYEE_ACCOUNT_NO);
	}

	public void setPayeeAccountNo(String value) {
		setValue(PBSResultTxFileDefinition.PAYEE_ACCOUNT_NO, value);
	}

	public String getStockId() {
		return getValue(PBSResultTxFileDefinition.STOCK_ID);
	}

	public void setStockId(String value) {
		setValue(PBSResultTxFileDefinition.STOCK_ID, value);
	}

	public String getPromoCode() {
		return getValue(PBSResultTxFileDefinition.PROMO_CODE);
	}

	public void setPromoCode(String value) {
		setValue(PBSResultTxFileDefinition.PROMO_CODE, value);
	}

	public String getRemark() {
		return getValue(PBSResultTxFileDefinition.REMARK);
	}

	public void setRemark(String value) {
		setValue(PBSResultTxFileDefinition.REMARK, value);
	}

	public String getAccountId() {
		return getValue(PBSResultTxFileDefinition.ACCOUNT_ID);
	}

	public void setAccountId(String value) {
		setValue(PBSResultTxFileDefinition.ACCOUNT_ID, value);
	}

	public String getAccountName() {
		return getValue(PBSResultTxFileDefinition.ACCOUNT_NAME);
	}

	public void setAccountName(String value) {
		setValue(PBSResultTxFileDefinition.ACCOUNT_NAME, value);
	}

	public String getPhone1() {
		return getValue(PBSResultTxFileDefinition.PHONE1);
	}

	public void setPhone1(String value) {
		setValue(PBSResultTxFileDefinition.PHONE1, value);
	}

	public String getPhone2() {
		return getValue(PBSResultTxFileDefinition.PHONE2);
	}

	public void setPhone2(String value) {
		setValue(PBSResultTxFileDefinition.PHONE2, value);
	}

	public String getTxnStatus() {
		return getValue(PBSResultTxFileDefinition.TXN_STATUS);
	}

	public void setTxnStatus(String value) {
		setValue(PBSResultTxFileDefinition.TXN_STATUS, value);
	}

	public String getAccountBal() {
		return getValue(PBSResultTxFileDefinition.ACCOUNT_BAL);
	}

	public void setAccountBal(String value) {
		setValue(PBSResultTxFileDefinition.ACCOUNT_BAL, value);
	}

	public String getErrorCode() {
		return getValue(PBSResultTxFileDefinition.ERROR_CODE);
	}

	public void setErrorCode(String value) {
		setValue(PBSResultTxFileDefinition.ERROR_CODE, value);
	}

	// 交易序號
	public String getJrnlNo() {
		return getValue(PBSResultTxFileDefinition.JRNL_NO);
	}

	public void setJrnlNo(String value) {
		setValue(PBSResultTxFileDefinition.JRNL_NO, value);
	}

	// TODO
	// ========================================================
	// 以下可共用

	/**
	 * 
	 * @param fileDefinition
	 * @return
	 */
	private String getValue(IFileDefinition fileDefinition) {
		FileField fileField = fileSection.getField(fileDefinition.getId());
		if (fileField == null) {
			return null;
		}
		else {
			return StringUtils.trim(fileField.getValue());
		}
	}

	/**
	 * 
	 * @param fileDefinition
	 * @param value
	 */
	private void setValue(IFileDefinition fileDefinition, String value) {

		if (fileSection == null) {
			fileSection = new FileSection();
		}

		FileField field = fileSection.getField(fileDefinition.getId());
		if (field == null) {
			field = new FileField();
			field.setFieldId(fileDefinition.getId());
			field.setValue(value);
			fileSection.addField(field);
		}
		else {
			field.setValue(value);
		}
	}

	// 以上可共用
	// ========================================================

}
