/*
 * ===========================================================================
 * IBM Confidential
 * AIS Source Materials
 * 
 * 
 * (C) Copyright IBM Corp. 2011.
 *
 * ===========================================================================
 */
package com.cosmos.file.ext;

import com.cosmos.file.bo.FileField;
import com.cosmos.file.bo.FileSection;
import com.cosmos.type.FieldGroup;
import com.ibm.tw.commons.util.StringUtils;

/**
 * <p>
 * 證券款檔案上傳
 * </p>
 * 
 * @author BearChen
 * @version 1.0, 2011/6/27
 * @see
 * @since
 */
public class PBSFileSection {

	/** 檔案區段 */
	private FileSection fileSection;

	public PBSFileSection(FileSection fileSection) {
		this.fileSection = fileSection;
	}

	public PBSFileSection(FieldGroup fieldGroup) {
		fileSection = new FileSection();
		fileSection.setFieldGroup(fieldGroup);
	}

	/**
	 * 客戶銀行付款帳號
	 * 
	 * @return
	 */
	public String getPayerAccountNo() {

		FileField fileField = fileSection.getField("payerAccountNo");
		if (fileField == null) {
			return null;
		}
		else {

			String payerAccount = StringUtils.trim(fileField.getValue());

			if (StringUtils.length(payerAccount) == 12) {

				payerAccount = StringUtils.leftPad(payerAccount, 14, "0");

			}

			return payerAccount;
		}

	}
	
	/**
	 * 客戶上傳付款帳號
	 * 
	 * @return
	 */
	public String getPayerAccountNoOri() {

		FileField fileField = fileSection.getField("payerAccountNo");
		if (fileField == null) {
			return null;
		}
		else {
			return StringUtils.trim(fileField.getValue());
		}
	}

	/**
	 * 客戶付款統編
	 * 
	 * @return
	 */
	public String getPayerUid() {
		FileField fileField = fileSection.getField("payerUid");
		if (fileField == null) {
			return null;
		}
		else {
			return StringUtils.trim(fileField.getValue());
		}
	}

	/**
	 * 券商股款轉帳代碼
	 * 
	 * @return
	 */
	public String getPayeeTransId() {
		FileField fileField = fileSection.getField("payeeTransId");
		if (fileField == null) {
			return null;
		}
		else {
			return StringUtils.trim(fileField.getValue());
		}
	}

	/**
	 * 交易日期
	 * 
	 * @return
	 */
	public String getTxDate() {
		FileField fileField = fileSection.getField("txDate");
		if (fileField == null) {
			return null;
		}
		else {
			return fileField.getValue();
		}
	}

	/**
	 * 帳號轉帳類別代號 1115為入帳 1315為扣帳
	 * 
	 * @return
	 */
	public String getPayeeAccountTypeId() {
		FileField fileField = fileSection.getField("payeeAccountTypeId");
		if (fileField == null) {
			return null;
		}
		else {
			return fileField.getValue();
		}
	}

	/**
	 * 交易金額
	 * 
	 * @return
	 */
	public String getTxAmt() {
		FileField fileField = fileSection.getField("txAmt");
		if (fileField == null) {
			return null;
		}
		else {
			return fileField.getValue();
		}
	}

	/**
	 * 券商統編
	 * 
	 * @return
	 */
	public String getPayeeUid() {
		FileField fileField = fileSection.getField("payeeUid");
		if (fileField == null) {
			return null;
		}
		else {
			return StringUtils.trim(fileField.getValue());
		}
	}

	/**
	 * 證券戶號
	 * 
	 * @return
	 */
	public String getPayeeAccountNo() {

		FileField fileField = fileSection.getField("payeeAccountNo");
		if (fileField == null) {
			return null;
		}
		else {

			String payeeAccount = StringUtils.trim(fileField.getValue());

			if (StringUtils.length(payeeAccount) == 12) {

				payeeAccount = StringUtils.leftPad(payeeAccount, 14, "0");

			}

			return payeeAccount;
		}

	}
	
	/**
	 * 客戶上傳收款帳號
	 * 
	 * @return
	 */
	public String getPayeeAccountNoOri() {

		FileField fileField = fileSection.getField("payeeAccountNo");
		if (fileField == null) {
			return null;
		}
		else {
			return StringUtils.trim(fileField.getValue());
		}

	}

	/**
	 * 轉帳業務種類
	 * 
	 * @return
	 */
	public String getTransType() {
		FileField fileField = fileSection.getField("transType");
		if (fileField == null) {
			return null;
		}
		else {
			return StringUtils.trim(fileField.getValue());
		}
	}

	/**
	 * 營業員代號
	 * 
	 * @return
	 */
	public String getShopId() {
		FileField fileField = fileSection.getField("shopId");
		if (fileField == null) {
			return null;
		}
		else {
			return StringUtils.trim(fileField.getValue());
		}
	}

	/**
	 * 股票代號
	 * 
	 * @return
	 */
	public String getStocksId() {
		FileField fileField = fileSection.getField("stocksId");
		if (fileField == null) {
			return null;
		}
		else {
			return StringUtils.trim(fileField.getValue());
		}
	}

	/**
	 * 證券商專戶代號
	 * 
	 * @return
	 */
	public String getPbsOwnerId() {
		FileField fileField = fileSection.getField("pbsOwnerId");
		if (fileField == null) {
			return null;
		}
		else {
			return StringUtils.trim(fileField.getValue());
		}
	}

	/**
	 * 扣款順序* 0(交割入帳、交割扣款、申購退款、申購扣款)、1（交割入帳、申購退款、申購扣款、交割扣款）業務種類為03申購扣款才須輸入
	 * 
	 * @return
	 */
	public String getDeductSeq() {
		FileField fileField = fileSection.getField("deductSeq");
		if (fileField == null) {
			return null;
		}
		else {
			return StringUtils.trim(fileField.getValue());
		}
	}

	public FileSection getFileSection() {
		return fileSection;
	}

	/**
	 * 設定客戶銀行付款帳號
	 * 
	 * @param value
	 */
	public void setPayerAccountNo(String value) {
		setValue("payerAccountNo", value);
	}

	/**
	 * 設定客戶付款統編
	 * 
	 * @param value
	 */
	public void setPayerUid(String value) {
		setValue("payerUid", value);
	}

	/**
	 * 設定券商股款轉帳代碼
	 * 
	 * @param value
	 */
	public void setPayeeTransId(String value) {
		setValue("payeeTransId", value);
	}

	/**
	 * 設定交易日期
	 * 
	 * @param value
	 */
	public void setTxDate(String value) {
		setValue("txDate", value);
	}

	/**
	 * 設定帳號轉帳類別代號 1115為入帳 1315為扣帳
	 * 
	 * @param value
	 */
	public void setPayeeAccountTypeId(String value) {
		setValue("payeeAccountTypeId", value);
	}

	/**
	 * 設定交易金額
	 * 
	 * @param value
	 */
	public void setTxAmt(String value) {
		setValue("txAmt", value);
	}

	/**
	 * 設定券商統編
	 * 
	 * @param value
	 */
	public void setPayeeUid(String value) {
		setValue("payeeUid", value);
	}

	/**
	 * 設定證券戶號
	 * 
	 * @param value
	 */
	public void setPayeeAccountNo(String value) {
		setValue("payeeAccountNo", value);
	}

	/**
	 * 設定轉帳業務種類
	 * 
	 * @param value
	 */
	public void setTransType(String value) {
		setValue("transType", value);
	}

	/**
	 * 設定營業員代號
	 * 
	 * @param value
	 */
	public void setShopId(String value) {
		setValue("shopId", value);
	}

	/**
	 * 設定股票代號
	 * 
	 * @param value
	 */
	public void setStocksId(String value) {
		setValue("stocksId", value);
	}

	/**
	 * 設定證券商專戶代號
	 * 
	 * @param value
	 */
	public void setPbsOwnerId(String value) {
		setValue("pbsOwnerId", value);
	}

	/**
	 * 設定扣款順序* 0(交割入帳、交割扣款、申購退款、申購扣款)、1（交割入帳、申購退款、申購扣款、交割扣款）業務種類為03申購扣款才須輸入
	 * 
	 * @param value
	 */
	public void setDeductSeq(String value) {
		setValue("deductSeq", value);
	}

	/**
	 * 
	 * @param fieldId
	 * @param value
	 */
	private void setValue(String fieldId, String value) {

		if (fileSection == null) {
			fileSection = new FileSection();
		}

		FileField field = fileSection.getField(fieldId);
		if (field == null) {
			field = new FileField();
			field.setFieldId(fieldId);
			field.setValue(value);
			fileSection.addField(field);
		}
		else {
			field.setValue(value);
		}
	}

}
