/*
 * ===========================================================================
 * IBM Confidential
 * AIS Source Materials
 *
 *
 * (C) Copyright IBM Corp. 2011.
 *
 * ===========================================================================
 */
package com.cosmos.file.ext;

import com.cosmos.file.bo.FileField;
import com.cosmos.file.bo.FileSection;
import com.cosmos.file.def.CactxB01ResultFooterFileDefinition;
import com.cosmos.file.def.IFileDefinition;
import com.cosmos.type.FieldGroup;
import com.ibm.tw.commons.util.StringUtils;

/**
 * <p>
 * FISC整批代收格式(首錄)
 * </p>
 * 
 * @author Hank
 * @version 1.0, 2016/106
 * @see
 * @since
 */
public class CactxB01ResultFooterFileSection {

	/** 檔案區段 */
	private FileSection fileSection;

	public CactxB01ResultFooterFileSection() {

		fileSection = new FileSection();
		fileSection.setFieldGroup(FieldGroup.FOOTER);
	}

	public CactxB01ResultFooterFileSection(FileSection fileSection) {
		this.fileSection = fileSection;
	}

	public FileSection getFileSection() {
		return fileSection;
	}

	// 區別碼
	public String getSecNo() {
		return getValue(CactxB01ResultFooterFileDefinition.SECNO);
	}

	public void setSecNo(String value) {
		setValue(CactxB01ResultFooterFileDefinition.SECNO, value);
	}

	// 委託單位
	public String getPunit() {
		return getValue(CactxB01ResultFooterFileDefinition.PUNIT);
	}

	public void setPunit(String value) {
		setValue(CactxB01ResultFooterFileDefinition.PUNIT, value);
	}

	// 收件單位
	public String getRunit() {
		return getValue(CactxB01ResultFooterFileDefinition.RUNIT);
	}

	public void setRunit(String value) {
		setValue(CactxB01ResultFooterFileDefinition.RUNIT, value);
	}

	// 交易日期
	public String getTxDate() {
		return getValue(CactxB01ResultFooterFileDefinition.TXDATE);
	}

	public void setTxDate(String value) {
		setValue(CactxB01ResultFooterFileDefinition.TXDATE, value);
	}

	// 費用類別
	public String getPaymentType() {
		return getValue(CactxB01ResultFooterFileDefinition.PAYMENTTYPE);
	}

	public void setPaymentType(String value) {
		setValue(CactxB01ResultFooterFileDefinition.PAYMENTTYPE, value);
	}

	// 固定為+號
	public String getChk2() {
		return getValue(CactxB01ResultFooterFileDefinition.CHK2);
	}

	public void setChk2(String value) {
		setValue(CactxB01ResultFooterFileDefinition.CHK2, value);
	}

	// 交易總金額
	public String getTotAmt() {
		return getValue(CactxB01ResultFooterFileDefinition.TOT_AMT);
	}

	public void setTotAmt(String value) {
		setValue(CactxB01ResultFooterFileDefinition.TOT_AMT, value);
	}

	// 交易總筆數
	public String getTotNum() {
		return getValue(CactxB01ResultFooterFileDefinition.TOT_NUM);
	}

	public void setTotNum(String value) {
		setValue(CactxB01ResultFooterFileDefinition.TOT_NUM, value);
	}

	// 固定為+號
	public String getChk3() {
		return getValue(CactxB01ResultFooterFileDefinition.CHK3);
	}

	public void setChk3(String value) {
		setValue(CactxB01ResultFooterFileDefinition.CHK3, value);
	}

	// 成交總金額
	public String getDealAmt() {
		return getValue(CactxB01ResultFooterFileDefinition.DEAL_AMT);
	}

	public void setDealAmt(String value) {
		setValue(CactxB01ResultFooterFileDefinition.DEAL_AMT, value);
	}

	// 成交總筆數
	public String getDealNum() {
		return getValue(CactxB01ResultFooterFileDefinition.DEAL_NUM);
	}

	public void setDealNum(String value) {
		setValue(CactxB01ResultFooterFileDefinition.DEAL_NUM, value);
	}

	// 固定為+號
	public String getChk4() {
		return getValue(CactxB01ResultFooterFileDefinition.CHK4);
	}

	public void setChk4(String value) {
		setValue(CactxB01ResultFooterFileDefinition.CHK4, value);
	}

	// 未成交總金額
	public String getUnDealAmt() {
		return getValue(CactxB01ResultFooterFileDefinition.UNDEAL_AMT);
	}

	public void setUnDealAmt(String value) {
		setValue(CactxB01ResultFooterFileDefinition.UNDEAL_AMT, value);
	}

	// 未成交總筆數
	public String getUnDealNum() {
		return getValue(CactxB01ResultFooterFileDefinition.UNDEAL_NUM);
	}

	public void setUnDealNum(String value) {
		setValue(CactxB01ResultFooterFileDefinition.UNDEAL_NUM, value);
	}

	// 保留欄
	public String getFiller() {
		return getValue(CactxB01ResultFooterFileDefinition.FILLER);
	}

	public void setFiller(String value) {
		setValue(CactxB01ResultFooterFileDefinition.FILLER, value);
	}

	// ========================================================
	// 以下可共用

	/**
	 * 
	 * @param fileDefinition
	 * @return
	 */
	private String getValue(IFileDefinition fileDefinition) {
		FileField fileField = fileSection.getField(fileDefinition.getId());
		if (fileField == null) {
			return null;
		}
		else {
			return StringUtils.trim(fileField.getValue());
		}
	}

	/**
	 * 
	 * @param fileDefinition
	 * @param value
	 */
	private void setValue(IFileDefinition fileDefinition, String value) {

		if (fileSection == null) {
			fileSection = new FileSection();
		}

		FileField field = fileSection.getField(fileDefinition.getId());
		if (field == null) {
			field = new FileField();
			field.setFieldId(fileDefinition.getId());
			field.setValue(value);
			fileSection.addField(field);
		}
		else {
			field.setValue(value);
		}
	}

}
