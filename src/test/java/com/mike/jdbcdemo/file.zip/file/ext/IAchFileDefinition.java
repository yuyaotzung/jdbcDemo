/*
 * ===========================================================================
 * IBM Confidential
 * AIS Source Materials
 *
 *
 * (C) Copyright IBM Corp. 2013.
 *
 * ===========================================================================
 */
package com.cosmos.file.ext;



/**
 * <p> </p>
 *
 * @author  Leo
 * @version 1.0, 2013/12/28
 * @see
 * @since
 */
public interface IAchFileDefinition {

	public String getId();

	public int getType();

	public int getLength();
	
	public int getRequired();

	public String getName();
}



