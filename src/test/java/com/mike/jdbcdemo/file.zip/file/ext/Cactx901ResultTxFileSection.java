/*
 * ===========================================================================
 * IBM Confidential
 * AIS Source Materials
 * 
 * 
 * (C) Copyright IBM Corp. 2018.
 *
 * ===========================================================================
 */
package com.cosmos.file.ext;

import com.cosmos.file.bo.FileField;
import com.cosmos.file.bo.FileSection;
import com.cosmos.file.def.Cactx901ResultTxFileDefinition;
import com.cosmos.file.def.IFileDefinition;
import com.cosmos.type.FieldGroup;
import com.ibm.tw.commons.util.StringUtils;

/**
 * <p>
 * 台幣整批扣自入自、複委託扣帳
 * </p>
 * 
 * @author Bear
 * @version 1.0, 2018/4/16
 * @see
 * @since
 */
public class Cactx901ResultTxFileSection {

	/** 檔案區段 */
	private FileSection fileSection;

	public Cactx901ResultTxFileSection() {
		fileSection = new FileSection();
		fileSection.setFieldGroup(FieldGroup.TX);
	}

	public Cactx901ResultTxFileSection(FileSection fileSection) {
		this.fileSection = fileSection;
	}

	public FileSection getFileSection() {
		return fileSection;
	}

	// 批號
	public String getBatchNo() {
		return getValue(Cactx901ResultTxFileDefinition.BATCH_NO);
	}

	public void setBatchNo(String value) {
		setValue(Cactx901ResultTxFileDefinition.BATCH_NO, value);
	}

	// 流水號
	public String getSerno() {
		return getValue(Cactx901ResultTxFileDefinition.SERNO);
	}

	public void setSerno(String value) {
		setValue(Cactx901ResultTxFileDefinition.SERNO, value);
	}

	// 轉出帳號
	public String getPayerAcctNo() {
		return getValue(Cactx901ResultTxFileDefinition.PAYER_ACCT_NO);
	}

	public void setPayerAcctNo(String value) {
		setValue(Cactx901ResultTxFileDefinition.PAYER_ACCT_NO, value);
	}

	// 清算帳號(入帳帳號)
	public String getPayeeAcctNo() {
		return getValue(Cactx901ResultTxFileDefinition.PAYEE_ACCT_NO);
	}

	public void setPayeeAcctNo(String value) {
		setValue(Cactx901ResultTxFileDefinition.PAYEE_ACCT_NO, value);
	}

	// 交易金額
	public String getAmount() {
		return getValue(Cactx901ResultTxFileDefinition.AMOUNT);
	}

	public void setAmount(String value) {
		setValue(Cactx901ResultTxFileDefinition.AMOUNT, value);
	}

	// 提示碼
	public String getPromoCode() {
		return getValue(Cactx901ResultTxFileDefinition.PROMO_CODE);
	}

	public void setPromoCode(String value) {
		setValue(Cactx901ResultTxFileDefinition.PROMO_CODE, value);
	}

	// 存摺附註
	public String getRemarks() {
		return getValue(Cactx901ResultTxFileDefinition.REMARKS);
	}

	public void setRemarks(String value) {
		setValue(Cactx901ResultTxFileDefinition.REMARKS, value);
	}

	// 檢核ID
	public String getCheckId() {
		return getValue(Cactx901ResultTxFileDefinition.CHECK_ID);
	}

	public void setCheckId(String value) {
		setValue(Cactx901ResultTxFileDefinition.CHECK_ID, value);
	}

	// 檢核戶名
	public String getCheckName() {
		return getValue(Cactx901ResultTxFileDefinition.CHECK_NAME);
	}

	public void setCheckName(String value) {
		setValue(Cactx901ResultTxFileDefinition.CHECK_NAME, value);
	}

	// BaNCS中心執行結果
	public String getBancsStat() {
		return getValue(Cactx901ResultTxFileDefinition.BANCS_STAT);
	}

	public void setBancsStat(String value) {
		setValue(Cactx901ResultTxFileDefinition.BANCS_STAT, value);
	}

	// 交易序號
	public String getJrnlNo() {
		return getValue(Cactx901ResultTxFileDefinition.JRNL_NO);
	}

	public void setJrnlNo(String value) {
		setValue(Cactx901ResultTxFileDefinition.JRNL_NO, value);
	}

	// 300長
	public String getPayerData() {
		return getValue(Cactx901ResultTxFileDefinition.PAYER_DATA);
	}

	public void setPayerData(String value) {
		setValue(Cactx901ResultTxFileDefinition.PAYER_DATA, value);
	}

	// ========================================================
	// 以下可共用

	/**
	 * 
	 * @param fileDefinition
	 * @return
	 */
	private String getValue(IFileDefinition fileDefinition) {
		FileField fileField = fileSection.getField(fileDefinition.getId());
		if (fileField == null) {
			return null;
		}
		else {
			return StringUtils.trim(fileField.getValue());
		}
	}

	/**
	 * 
	 * @param fileDefinition
	 * @param value
	 */
	private void setValue(IFileDefinition fileDefinition, String value) {

		if (fileSection == null) {
			fileSection = new FileSection();
		}

		FileField field = fileSection.getField(fileDefinition.getId());
		if (field == null) {
			field = new FileField();
			field.setFieldId(fileDefinition.getId());
			field.setValue(value);
			fileSection.addField(field);
		}
		else {
			field.setValue(value);
		}
	}

	// 以上可共用
	// ========================================================
}
