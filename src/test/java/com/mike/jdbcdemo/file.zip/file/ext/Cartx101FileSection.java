package com.cosmos.file.ext;

import com.cosmos.file.bo.FileSection;
import com.cosmos.file.ext.fx.FileSectionWrapperBase;
import com.cosmos.type.PayerKind;

/**
 * <p>
 * Cartx101 File Section
 * </p>
 * 

 */
public class Cartx101FileSection extends FileSectionWrapperBase {

	public Cartx101FileSection(FileSection fileSection) {
		super(fileSection);
	}

	/**
	 * 買方統編
	 * 
	 * @return
	 */
	public String getBuyerId() {
		return getFieldValue("buyerId");
	}
	
	/**
	 * 買方名稱
	 * 
	 * @return
	 */
	public String getBuyerName() {
		return getFieldValue("buyerName");
	}
	
	
	/**
	 * 發票日編
	 * 
	 * @return
	 */
	public String getInvoiceDate() {
		return getFieldValue("invoiceDate");
	}
	
	
	/**
	 * 發票號碼
	 * 
	 * @return
	 */
	public String getInvoiceNumber() {
		return getFieldValue("invoiceNumber");
	}
	
	
	/**
	 * 發票幣別
	 * 
	 * @return
	 */
	public String getInvoiceCcy() {
		return getFieldValue("invoiceCcy");
	}
	
	
	/**
	 * 發票金額
	 * 
	 * @return
	 */
	public String getInvoiceAmt() {
		return getFieldValue("invoiceAmt");
	}

	
	/**
	 * 帳款起算日
	 * 
	 * @return
	 */
	public String getPaymentStartDate() {
		return getFieldValue("paymentStartDate");
	}
	
	/**
	 * 帳款到期日
	 * 
	 * @return
	 */
	public String getPaymentEndDate() {
		return getFieldValue("paymentEndDate");
	}
	
}
