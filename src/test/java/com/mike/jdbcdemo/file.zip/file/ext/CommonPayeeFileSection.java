/*
 * ===========================================================================
 * IBM Confidential
 * AIS Source Materials
 * 
 * 
 * (C) Copyright IBM Corp. 2011.
 *
 * ===========================================================================
 */
package com.cosmos.file.ext;

import com.cosmos.file.bo.FileField;
import com.cosmos.file.bo.FileSection;
import com.ibm.tw.commons.util.StringUtils;

/**
 * <p>
 * CommonPayee File Section
 * </p>
 * 
 * @author Leo
 * @version 1.0, 2011/6/27
 * @see
 * @since
 */
public class CommonPayeeFileSection {

	/** 檔案區段 */
	private FileSection fileSection;

	public CommonPayeeFileSection(FileSection fileSection) {
		this.fileSection = fileSection;
	}

	/**
	 * 付款通路
	 * 
	 * @return
	 */
	public String getPayerKind() {
		FileField fileField = fileSection.getField("payerKind");
		if (fileField == null) {
			return null;
		}
		else {
			return StringUtils.trim(fileField.getValue());
		}
	}

	/**
	 * 收款人戶名
	 * 
	 * @return
	 */
	public String getPayeeName() {
		FileField fileField = fileSection.getField("payeeName");
		if (fileField == null) {
			return null;
		}
		else {
			return StringUtils.trim(fileField.getValue());
		}
	}

	/**
	 * 收款人Email
	 * 
	 * @return
	 */
	public String getPayeeEmail() {
		FileField fileField = fileSection.getField("payeeEmail");
		if (fileField == null) {
			return null;
		}
		else {
			return StringUtils.trim(fileField.getValue());
		}
	}

	/**
	 * 收款銀行代號
	 * 
	 * @return
	 */
	public String getPayeeBankId() {
		FileField fileField = fileSection.getField("payeeBankId");
		if (fileField == null) {
			return null;
		}
		else {
			return StringUtils.trim(fileField.getValue());
		}
	}

	/**
	 * 收款帳號
	 * 
	 * @return
	 */
	public String getPayeeAccountNo() {
		FileField fileField = fileSection.getField("payeeAccountNo");
		if (fileField == null) {
			return null;
		}
		else {
			return StringUtils.trim(fileField.getValue());
		}
	}

	/**
	 * 收款人統編
	 * 
	 * @return
	 */
	public String getPayeeUid() {
		FileField fileField = fileSection.getField("payeeUid");
		if (fileField == null) {
			return null;
		}
		else {
			return StringUtils.trim(fileField.getValue());
		}
	}

	/**
	 * 手續費負擔
	 * 
	 * @return
	 */
	public String getChargeAmtType() {
		FileField fileField = fileSection.getField("chargeAmtType");
		if (fileField == null) {
			return null;
		}
		else {
			return fileField.getValue();
		}
	}

	/**
	 * 帳戶別名
	 * 
	 * @return
	 */
	public String getPayeeAlias() {
		FileField fileField = fileSection.getField("payeeAlias");
		if (fileField == null) {
			return null;
		}
		else {
			return StringUtils.trim(fileField.getValue());
		}
	}
}
