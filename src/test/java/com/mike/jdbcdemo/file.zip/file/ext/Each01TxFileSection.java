/*
 * ===========================================================================
 * IBM Confidential
 * AIS Source Materials
 *
 *
 * (C) Copyright IBM Corp. 2011.
 *
 * ===========================================================================
 */
package com.cosmos.file.ext;

import com.cosmos.file.ext.IAchFileDefinition;






/**
 * <p>ACH提出電子檔檔案規格-明細(ACHP01)</p>
 *
 * @author  shawn
 * @version 1.0, 2013/9/26
 * @see
 * @since
 */
public enum Each01TxFileSection implements IAchFileDefinition {

	/** 欄位代號(類型, 是否必填 ,長度, 資料庫欄位, 欄位名稱(說明)) */
	P_TYPE(1,0, 1, "TYPE", "交易型態"),
	P_TXTYPE(1,1, 2, "TXTYPE", "交易類別"),
	P_TXID(1,0, 3, "TXID", "交易代號"),
	P_SEQ(1,0, 6, "SEQ", "交易序號"),
	P_PBANK(1,0, 7, "PBANK", "提出行代號"),

	P_PCLNO(1,0, 14, "PCLNO", "發動者帳號"),
	P_RBANK(1,0, 7, "RBANK", "提回行代號"),
	P_RCLNO(1,0, 14, "RCLNO", "收受者帳號"),
	P_AMT(1,0, 10, "AMT", "金額"),
	P_RCODE(1,0, 2, "RCODE", "退件理由代號"),

	P_SCHD(1,0, 1, "SCHD", "提示交換次序"),
	P_CID(1,0, 10, "CID", "發動者統一編號"),
	P_PID(1,0, 10, "PID", "收受者統一編號"),
	P_SID(1,0, 6, "SID", "上市上櫃公司代號"),
	P_PDATE(1,0, 8, "PDATE", "原提示交易日期"),

	P_PSEQ(1,0, 6, "PSEQ", "原提示交易序號"),
	P_PSCHD(1,0, 1, "PSCHD", "原提示交換次序"),
	P_CNO(1,0, 20, "CNO", "用戶號碼"),
	P_NOTE(1,0, 20, "NOTE", "發動者專用區"),
	P_MEMO(1,0, 10, "MEMO", "存摺摘要"),
	P_FILLER(1,0, 2, "FILLER", "備用");


	/** 資料類型 */
	private int type;
	
	/** 是否必填 */
	private int required;

	/** 檔案格式長度 */
	private int length;

	/** 資料庫存放欄位 */
	private String columnName;

	/** 欄位名稱 說明 */
	private String name;
	
	/** 交易方式 ACH/eACH (因為不在檔案內容,於匯入時儲存) */
	public static final String ACH_CHANNEL = "ACH_CHANNEL";

	/**
	 * Constructor
	 *
	 * @param code
	 * @param memo
	 */
	Each01TxFileSection(int type, int required, int length, String columnName, String name) {
		this.type = type;
		this.required = required;
		this.length = length;
		this.columnName = columnName;
		this.name = name;
	}

	/**
	 * 取得id
	 *
	 * @return
	 */
	public String getId() {
		return name();
	}

	/**
	 * 取得 type
	 *
	 * @return 傳回 type
	 */
	public int getType() {
		return type;
	}

	/**
	 * 取得 length
	 *
	 * @return 傳回 length
	 */
	public int getLength() {
		return length;
	}

	/**
	 * 取得 name
	 *
	 * @return 傳回 name
	 */
	public String getName() {
		return name;
	}

	/**
	 * 取得 length
	 * 
	 * @return 傳回 length
	 */
	public int getRequired() {
		return required;
	}
	
}



