/*
 * ===========================================================================
 * IBM Confidential
 * AIS Source Materials
 * 
 * 
 * (C) Copyright IBM Corp. 2011.
 *
 * ===========================================================================
 */
package com.cosmos.file.ext;

import com.cosmos.file.bo.FileField;
import com.cosmos.file.bo.FileSection;
import com.ibm.tw.commons.util.StringUtils;

/**
 * <p>
 * CommonPayee File Section
 * </p>
 * 
 * @author Leo
 * @version 1.0, 2011/6/27
 * @see
 * @since
 */
public class CACTX602ExcelFileSection {

	/** 檔案區段 */
	private FileSection fileSection;

	public CACTX602ExcelFileSection(FileSection fileSection) {
		this.fileSection = fileSection;
	}

	/**
	 * 收受行代號
	 * 
	 * @return
	 */
	public String getRBank() {
		FileField fileField = fileSection.getField("rBank");
		if (fileField == null) {
			return null;
		}
		else {
			return StringUtils.trim(fileField.getValue());
		}
	}

	/**
	 * 委繳戶帳號
	 * 
	 * @return
	 */
	public String getRClno() {
		FileField fileField = fileSection.getField("rClno");
		if (fileField == null) {
			return null;
		}
		else {
			return StringUtils.trim(fileField.getValue());
		}
	}

	/**
	 * 收受者統一編號
	 * 
	 * @return
	 */
	public String getPId() {
		FileField fileField = fileSection.getField("pId");
		if (fileField == null) {
			return null;
		}
		else {
			return StringUtils.trim(fileField.getValue());
		}
	}

	/**
	 * 用戶號碼
	 * 
	 * @return
	 */
	public String getCNo() {
		FileField fileField = fileSection.getField("cNo");
		if (fileField == null) {
			return null;
		}
		else {
			return StringUtils.trim(fileField.getValue());
		}
	}

	/**
	 * 新增或取消 (僅核印使用) A:發動行新增授權扣款 D:發動行取消授權扣款 O:發動行新增舊有已簽約委繳戶資料 H:扣款行新增授權扣款
	 * E:扣款行取消授權扣款 M:發動行新增或異動扣款限額
	 * 
	 * @return
	 */
	public String getAdMark() {
		FileField fileField = fileSection.getField("adMark");
		if (fileField == null) {
			return null;
		}
		else {
			return StringUtils.trim(fileField.getValue());
		}
	}

	/**
	 * 發動者專用區
	 * 
	 * @return
	 */
	public String getNote() {
		FileField fileField = fileSection.getField("note");
		if (fileField == null) {
			return null;
		}
		else {
			return StringUtils.trim(fileField.getValue());
		}
	}

	/**
	 * 查詢專用區
	 * 
	 * @return
	 */
	public String getFiller() {
		FileField fileField = fileSection.getField("filler");
		if (fileField == null) {
			return null;
		}
		else {
			return fileField.getValue();
		}
	}

	/**
	 * 扣款上限
	 * 
	 * @return
	 */
	public String getTxAmt() {
		FileField fileField = fileSection.getField("txAmt");
		if (fileField == null) {
			return null;
		}
		else {
			return StringUtils.trim(fileField.getValue());
		}
	}

	/**
	 * 授權扣款終止日
	 * 
	 * @return
	 */
	public String getEDate() {
		FileField fileField = fileSection.getField("eDate");
		if (fileField == null) {
			return null;
		}
		else {
			return StringUtils.trim(fileField.getValue());
		}
	}

}
