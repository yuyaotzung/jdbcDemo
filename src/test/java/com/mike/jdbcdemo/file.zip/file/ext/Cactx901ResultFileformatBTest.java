/*
 * ===========================================================================
 * IBM Confidential
 * AIS Source Materials
 * 
 * 
 * (C) Copyright IBM Corp. 2018.
 *
 * ===========================================================================
 */
package com.cosmos.file.ext;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.util.Date;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;

import org.apache.commons.io.FileUtils;

import com.cosmos.code.CosmosCommonId;
import com.cosmos.file.bo.FileDetail;
import com.cosmos.file.bo.FileDoc;
import com.cosmos.file.bo.FileSection;
import com.cosmos.param.ISystemParam;
import com.cosmos.param.ext.CibParam;
import com.cosmos.persistence.CosmosDaoFactory;
import com.cosmos.persistence.b2c.dao.B2CSequenceDao;
import com.cosmos.persistence.b2c.dao.IB2CSequenceDao;
import com.cosmos.persistence.b2c.dao.ISystemParamDao;
import com.cosmos.persistence.b2c.entity.SystemParamEntity;
import com.cosmos.persistence.b2c.entity.pk.SystemParamEntityPk;
import com.cosmos.type.FieldGroup;
import com.cosmos.util.SFTPUtils;
import com.ibm.tw.commons.aop.AOPProxyFactory;
import com.ibm.tw.commons.exception.ActionException;
import com.ibm.tw.commons.exception.CryptException;
import com.ibm.tw.commons.persistence.exception.DatabaseException;
import com.ibm.tw.commons.util.ConvertUtils;
import com.ibm.tw.commons.util.DESUtils;
import com.ibm.tw.commons.util.StringUtils;
import com.ibm.tw.commons.util.time.DateUtils;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.SftpException;

/**
 * <p>
 * 台幣付委託 測試檔
 * </p>
 * 
 * @author Bear
 * @version 1.0, 2018/4/16
 * @see
 * @since
 */
public class Cactx901ResultFileformatBTest {

	// 台幣扣自入自、複委託(扣客戶入凱基)
	private static final String WORDKING_DIR = "0014";

	// Server
	static String server;

	// Port
	static int port;

	// 帳號
	static String user_put;

	// 密碼
	static String password_put;

	// 帳號
	static String user_get;

	// 密碼
	static String password_get;

	public static void main(String[] args) throws Throwable {

		init();

		// testExportFile();
		String fileName = "0014096013082018000000000001808130046036.TMP";
		testImportFile(fileName);

	}

	private static void init() {
		// Server
		server = getSystemParamValue(CibParam.FCS_SFTP_SERVER);
		// Port
		port = ConvertUtils.str2Int(getSystemParamValue(CibParam.FCS_SFTP_PORT));
		// 帳號
		user_put = getSystemParamValue(CibParam.FCS_SFTP_USER_PUT);
		// 密碼
		password_put = getSystemParamValue(CibParam.FCS_SFTP_PASSWORD_PUT);
		// 帳號
		user_get = getSystemParamValue(CibParam.FCS_SFTP_USER_GET);
		// 密碼
		password_get = getSystemParamValue(CibParam.FCS_SFTP_PASSWORD_GET);

	}

	private static void testExportFile() throws JSchException, SftpException, IOException, DatabaseException, ActionException {
		Cactx901ResultFileFormat fileFormat = new Cactx901ResultFileFormat("CACTX901");

		// 案件序號
		String flowDocId = generateCaseNo();

		// 交易日期
		Date txDate = new Date();

		prepareHeaders(fileFormat, txDate);
		prepareDetails(fileFormat, flowDocId);
		prepareFooters(fileFormat);
		byte[] data = new byte[0];

		data = fileFormat.toFile();

		String fileName = getFileName(txDate, flowDocId);

		System.out.println("fileName:" + fileName);

		// 備份檔案
		FileUtils.writeByteArrayToFile(new File("c:/ACHBACKUP/" + fileName + ".TXT"), data);

		ChannelSftp sftp = null;

		boolean result = false;
		ByteArrayInputStream is = new ByteArrayInputStream(data);

		try {
			sftp = SFTPUtils.connect(server, port, user_put, password_put, WORDKING_DIR);

			sftp.put(is, fileName + ".tmp");

			result = true;
			System.out.println("是否上傳成功 =" + result);
			is.close();

			if (!result) {
				System.err.println("上傳失敗");
			}

			try {
				if (result) {
					sftp.rename(fileName + ".tmp", fileName + ".TXT");
				}
			}
			catch (SftpException e) {
				e.printStackTrace();
				System.err.println("rename失敗, fileName:" + fileName);

			}

		}
		catch (JSchException e) {
			System.err.println("SFTP連線失敗");
			e.printStackTrace();
			throw e;
		}
		catch (SftpException e) {
			e.printStackTrace();
			throw e;
		}
		catch (IOException e) {
			e.printStackTrace();
			throw e;
		}
		finally {
			try {
				is.close();
				SFTPUtils.disconnect(sftp);
			}
			catch (JSchException e) {
				System.err.println("SFTP離線失敗");
				e.printStackTrace();
			}
			catch (IOException e) {
				System.err.println("ByteArrayInputStream close failed , fileName:" + fileName);
				e.printStackTrace();
			}
		}

	}

	private static void prepareHeaders(Cactx901ResultFileFormat fileFormat, Date txDate) {

		Cactx901ResultHeaderFileSection section = new Cactx901ResultHeaderFileSection();
		// 交易使用的分行號碼
		section.setBranchNo(StringUtils.leftPad(CosmosCommonId.branchNo, 5, "0"));
		// 交易使用的行員號碼 CNBANKING_企網銀(證券專區)90002720~90002724
		section.setTellerNo(StringUtils.leftPad("90002720", 8, "0"));
		// 交易使用的端末機號
		section.setTermNo(StringUtils.leftPad("000", 3, " "));
		// 交易日期
		section.setTxDate(DateUtils.formatDate(txDate, "ddMMyyyy"));
		// 委託單位代號
		section.setUnitNo(StringUtils.rightPad("9203", 5, " "));
		// 轉帳類型
		// 台幣扣自入自(衍伸商)轉帳類型：060
		// 台幣複委託轉帳類型：070
		section.setType(StringUtils.leftPad("070", 3, "0"));

		// 為了與畫面parse一致,讀入資料的secNo由1開始
		section.getFileSection().setSectionNo(1);

		fileFormat.addHeader(section);
	}

	private static void prepareDetails(Cactx901ResultFileFormat fileFormat, String flowDocId) {

		// 第一筆
		Cactx901ResultTxFileSection section = new Cactx901ResultTxFileSection();
		section.setBatchNo(StringUtils.leftPad(flowDocId, 24, "0"));
		section.setSerno(StringUtils.leftPad("00001", 5, "0"));
		section.setPayerAcctNo(StringUtils.leftPad("60190400000233", 16, "0"));
		section.setPayeeAcctNo(StringUtils.leftPad("9001000182514002", 16, "0"));
		section.setAmount(StringUtils.leftPad("3000000", 17, "0"));
		section.setPromoCode(StringUtils.rightPad("IZ", 2, " "));
		section.setRemarks(StringUtils.rightPad("remarks", 16, " "));
		section.setCheckId(StringUtils.rightPad("", 10, " "));
		section.setCheckName(StringUtils.rightPad("", 60, " "));
		section.setBancsStat(StringUtils.leftPad("9999", 4, "0"));
		section.setJrnlNo(StringUtils.leftPad("00000", 9, "0"));
		// 為了與畫面parse一致,讀入資料的secNo由1開始
		section.getFileSection().setSectionNo(1);

		fileFormat.addDetails(section);

	}

	private static void prepareFooters(Cactx901ResultFileFormat fileFormat) {
		Cactx901ResultFooterFileSection section = new Cactx901ResultFooterFileSection();
		section.setTotalAmt(StringUtils.leftPad("3000000", 17, "0"));
		section.setTotalCount(StringUtils.leftPad("1", 6, "0"));
		section.getFileSection().setSectionNo(1);
		fileFormat.addFooter(section);
	}

	private static void testImportFile(String fileName) throws JSchException, SftpException, IOException, ActionException {

		byte[] fileContent = null;
		ChannelSftp sftp = null;
		ByteArrayOutputStream os = new ByteArrayOutputStream();
		try {
			sftp = SFTPUtils.connect(server, port, user_get, password_get, "/");

			sftp.get(fileName, os);

			fileContent = os.toByteArray();

			if (fileContent == null) {
				System.err.println("sftp download file Error, fileName:" + fileName);
			}

		}
		catch (JSchException e) {
			System.err.println("SFTP連線失敗");
			e.printStackTrace();
			throw e;
		}
		catch (SftpException e) {
			e.printStackTrace();
			throw e;
		}
		finally {
			try {
				os.close();
				SFTPUtils.disconnect(sftp);
			}
			catch (JSchException e) {
				System.err.println("SFTP離線失敗");
				e.printStackTrace();
			}
			catch (IOException e) {
				System.err.println("ByteArrayOutputStream close failed , fileName:" + fileName);
				e.printStackTrace();
			}
		}

		Cactx901ResultFileFormat fileFormat = new Cactx901ResultFileFormat("CACTX901");

		boolean result = fileFormat.parseFile(fileContent);

		FileDoc fileDoc = fileFormat.getFileDoc();

		for (FileDetail fileDetail : fileDoc.getDetails()) {
			System.out.println("=================== " + fileDetail.getRowNo() + " ====================");

			// 
			FileSection fileSection = fileDetail.getFirstSection();
			if (fileDetail.getFirstSection().getFieldGroup() == FieldGroup.HEADER) {
				Cactx901ResultHeaderFileSection header = new Cactx901ResultHeaderFileSection(fileSection);
				System.out.println("getBranchNo:" + header.getBranchNo());
				System.out.println("getTellerNo:" + header.getTellerNo());
				System.out.println("getTermNo:" + header.getTermNo());
				System.out.println("getTxDate:" + header.getTxDate());
				System.out.println("getUnitNo:" + header.getUnitNo());
				System.out.println("getType:" + header.getType());
			}
			else if (fileDetail.getFirstSection().getFieldGroup() == FieldGroup.FOOTER) {
				Cactx901ResultFooterFileSection footer = new Cactx901ResultFooterFileSection(fileSection);
				System.out.println("getTotalCount:" + footer.getTotalCount());

				System.out.println("getTotalAmt:" + footer.getTotalAmt());

			}
			else {
				Cactx901ResultTxFileSection detail = new Cactx901ResultTxFileSection(fileSection);
				System.out.println("getBatchNo:" + detail.getBatchNo());
				System.out.println("getSerno:" + detail.getSerno());
				System.out.println("getPayerAccountNo:" + detail.getPayerAcctNo());
				System.out.println("getTxAmt:" + detail.getAmount());
				System.out.println("getRemarks:" + detail.getRemarks());
				System.out.println("getJournalNo:" + detail.getJrnlNo());
				System.out.println("getBancsStat:" + detail.getBancsStat());
			}

		}

		System.out.println("result:" + result);
	}

	/*
	 * 來源檔檔案名稱：9999(流程識別碼)+99999(主辦分行代碼)+交易日期(西元年DDMMYYYY)+999999999999999999999999
	 * (批號).TXT
	 */
	private static String getFileName(Date txDate, String batchNo) {

		return WORDKING_DIR + "0960" + DateUtils.formatDate(txDate, "ddMMyyyy") + StringUtils.leftPad(batchNo, 24, "0");
	}

	public static String generateCaseNo() throws DatabaseException {
		String value = "";
		IB2CSequenceDao dao = (IB2CSequenceDao) AOPProxyFactory.getDao(IB2CSequenceDao.class, B2CSequenceDao.class);
		String caseNoSeq = StringUtils.leftPad(String.valueOf(dao.getCaseNoSeq() % 10000000), 7, "0");
		value = DateUtils.getSimpleISODateStr(new Date()).substring(2) + caseNoSeq;
		return value;
	}

	/** 系統參數代碼表 */
	private static Map<SystemParamEntityPk, String> systemParamMap = null;

	/**
	 * 載入系統參數
	 */
	synchronized private static void loadSystemParamMap() {

		if (systemParamMap != null) {
			return;
		}

		systemParamMap = new Hashtable<SystemParamEntityPk, String>();

		ISystemParamDao dao = CosmosDaoFactory.getSystemParamDao();

		try {

			// System.err.println("loadSystemParamMap");

			List<SystemParamEntity> entities = dao.findAll();

			for (SystemParamEntity entity : entities) {

				SystemParamEntityPk pk = new SystemParamEntityPk(entity.getCategory(), entity.getKey());

				String value = StringUtils.trimToEmpty(entity.getValue());

				// 加入密碼 DECRYPT 的功能
				if (1 == entity.getPasswordFlag()) {
					value = DESUtils.decrypt(value);
				}

				systemParamMap.put(pk, value);

			}
		}
		catch (DatabaseException e) {
			throw new RuntimeException("cannot load SystemParam ", e);
		}
		catch (CryptException e) {
			throw new RuntimeException("cannot load SystemParam ", e);
		}

	}

	public static Map<SystemParamEntityPk, String> getSystemParamMap() {

		if (null == systemParamMap) {
			loadSystemParamMap();
		}
		return systemParamMap;
	}

	/**
	 * 取得參數值
	 * 
	 * @param param
	 * @return
	 */
	public static String getSystemParamValue(ISystemParam param) {

		SystemParamEntityPk pk = new SystemParamEntityPk(param.getCategory().getCode(), param.getKey());

		return getSystemParamMap().get(pk);
	}

}
