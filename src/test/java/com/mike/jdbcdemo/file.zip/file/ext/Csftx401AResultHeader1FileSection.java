/*
 * ===========================================================================
 * IBM Confidential
 * AIS Source Materials
 * 
 * 
 * (C) Copyright IBM Corp. 2018.
 *
 * ===========================================================================
 */
package com.cosmos.file.ext;

import com.cosmos.file.bo.FileField;
import com.cosmos.file.bo.FileSection;
import com.cosmos.file.def.Csftx401AResultHeader1FileDefinition;
import com.cosmos.file.def.IFileDefinition;
import com.cosmos.type.FieldGroup;
import com.ibm.tw.commons.util.StringUtils;



/**
 * <p> 外幣整批扣自入自、複委託扣帳-扣客戶入發動者(凱基) Header1 FileSection</p>
 *
 * @author  Bear
 * @version 1.0, 2018/6/5
 * @see	    
 * @since 
 */
public class Csftx401AResultHeader1FileSection {

	/** 檔案區段 */
	private FileSection fileSection;
	
	public Csftx401AResultHeader1FileSection() {
		fileSection = new FileSection();
		fileSection.setFieldGroup(FieldGroup.HEADER1);
	}
	
	public Csftx401AResultHeader1FileSection(FileSection fileSection) {
		this.fileSection = fileSection;
	}
	
	public FileSection getFileSection() {
		return fileSection;
	}
	
	
	//Data Indicator
	public String getDataIndicator() {
		return getValue(Csftx401AResultHeader1FileDefinition.DATA_INDICATOR);
	}
	
	public void setDataIndicator(String value) {
		setValue(Csftx401AResultHeader1FileDefinition.DATA_INDICATOR, value);
	}
	
	//  分行過帳標幟
	public String getColumn2() {
		return getValue(Csftx401AResultHeader1FileDefinition.COLUMN2);
	}
	
	public void setColumn2(String value) {
		setValue(Csftx401AResultHeader1FileDefinition.COLUMN2, value);
	}
	
	//	交易使用的分行號碼
	public String getBranchNo() {
		return getValue(Csftx401AResultHeader1FileDefinition.BRANCH_NO);
	}
	
	public void setBranchNo(String value) {
		setValue(Csftx401AResultHeader1FileDefinition.BRANCH_NO, value);
	}

//	交易使用的行員號碼
	public String getTellerNo() {
		return getValue(Csftx401AResultHeader1FileDefinition.TELLER_NO);
	}
	
	public void setTellerNo(String value) {
		setValue(Csftx401AResultHeader1FileDefinition.TELLER_NO, value);
	}
	
//	交易使用的端末機號
	public String getTermNo() {
		return getValue(Csftx401AResultHeader1FileDefinition.TERM_NO);
	}
	
	public void setTermNo(String value) {
		setValue(Csftx401AResultHeader1FileDefinition.TERM_NO, value);
	}
	
//	交易日期
	public String getTxDate() {
		return getValue(Csftx401AResultHeader1FileDefinition.TX_DATE);
	}
	
	public void setTxDate(String value) {
		setValue(Csftx401AResultHeader1FileDefinition.TX_DATE, value);
	}
	
//	授權主管行員號碼
	public String getColumn7() {
		return getValue(Csftx401AResultHeader1FileDefinition.COLUMN7);
	}
	
	public void setColumn7(String value) {
		setValue(Csftx401AResultHeader1FileDefinition.COLUMN7, value);
	}
	
	
//	原始檔名
	public String getColumn8() {
		return getValue(Csftx401AResultHeader1FileDefinition.COLUMN8);
	}
	
	public void setColumn8(String value) {
		setValue(Csftx401AResultHeader1FileDefinition.COLUMN8, value);
	}
	
	
//	檔案類別
	public String getColumn9() {
		return getValue(Csftx401AResultHeader1FileDefinition.COLUMN9);
	}
	
	public void setColumn9(String value) {
		setValue(Csftx401AResultHeader1FileDefinition.COLUMN9, value);
	}
	
//	處理註記
	public String getColumn10() {
		return getValue(Csftx401AResultHeader1FileDefinition.COLUMN10);
	}
	
	public void setColumn10(String value) {
		setValue(Csftx401AResultHeader1FileDefinition.COLUMN10, value);
	}
	
//	FILLER
	public String getFiller() {
		return getValue(Csftx401AResultHeader1FileDefinition.FILLER);
	}
	
	public void setFiller(String value) {
		setValue(Csftx401AResultHeader1FileDefinition.FILLER, value);
	}

	
	
	//========================================================
	// 以下可共用
	
	
	/**
	 * 
	 * @param fileDefinition
	 * @return
	 */
	private String getValue(IFileDefinition fileDefinition) {
		
		FileField fileField = fileSection.getField(fileDefinition.getId());
		if (fileField == null) {
			return null;
		}
		else {
			return StringUtils.trim(fileField.getValue());
		}
	}
	
	/**
	 * 
	 * @param fileDefinition
	 * @param value
	 */
	private void setValue(IFileDefinition fileDefinition, String value) {

		if (fileSection == null) {
			fileSection = new FileSection();
		}

		FileField field = fileSection.getField(fileDefinition.getId());
		if (field == null) {
			field = new FileField();
			field.setFieldId(fileDefinition.getId());
			field.setValue(value);
			fileSection.addField(field);
		}
		else {
			field.setValue(value);
		}
	}
	
	// 以上可共用
	//========================================================
}



 