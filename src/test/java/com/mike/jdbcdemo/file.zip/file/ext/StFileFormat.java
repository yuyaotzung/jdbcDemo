/*
 * ===========================================================================
 * IBM Confidential
 * AIS Source Materials
 * 
 * 
 * (C) Copyright IBM Corp. 2011.
 *
 * ===========================================================================
 */
package com.cosmos.file.ext;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;

import com.cosmos.code.CibErrorCode;
import com.cosmos.file.FileFormatNew;
import com.cosmos.file.bo.FileDetail;
import com.cosmos.type.FieldGroup;
import com.cosmos.type.TaskType;
import com.cosmos.type.TxBatchType;
import com.ibm.tw.commons.exception.ActionException;
import com.ibm.tw.commons.persistence.exception.DatabaseException;

/**
 * <p>
 * 多扣多入檔案格式
 * </p>
 * 
 * @author Leo
 * @version 1.0, 2011/6/8
 * @see
 * @since
 */
public abstract class StFileFormat extends FileFormatNew {

	/** */
	private List<StFileSection> details = new ArrayList<StFileSection>();

	/** 整批類型 */
	public static TxBatchType TX_BATCH_TYPE = TxBatchType.UNKNOWN;

	/**
	 * Constructor
	 * 
	 * @param loginUser
	 */
	public StFileFormat(int companyKey, String taskId) {
		super(companyKey, taskId, TX_BATCH_TYPE.getCode());
	}

	/**
	 * Constructor
	 * 
	 * @param fileFormatKey
	 */
	public StFileFormat(String fileFormatKey) throws DatabaseException {
		super(fileFormatKey);
	}

	@Override
	public FieldGroup getFormatCycle(int rowNo) {
		return null;
	}

	@Override
	public FieldGroup getFormatHead(int rowNo) {

		if (rowNo == getRows()) {
			return FieldGroup.FOOTER;
		}
		else {
			return FieldGroup.ST;
		}

	}

	@Override
	public TaskType getTaskType() {
		return TaskType.ST;
	}

	/**
	 * 取得尾筆
	 * 
	 * @return
	 */
	private FileDetail fetchFooter() {

		if (fileDoc == null) {

			System.err.println("===fileDoc is null=========");

		}
		else {

			System.err.println("===fileDoc is not null=========");
		}

		if (fileDoc.getDetails() == null) {

			System.err.println("===fileDoc.getDetails() is null=========");

		}
		else {

			System.err.println("===fileDoc.getDetails() is not null=========");
		}

		for (FileDetail detail : fileDoc.getDetails()) {
			if (detail.isFooter()) {
				return detail;
			}
		}
		return null;
	}

	/**
	 * 
	 * @return
	 * @throws ActionException
	 */
	public byte[] toFile() throws ActionException {

		byte[] dataBuff = new byte[0];

		FileDetail footer = fetchFooter();

		try {

			// 明細
			for (FileDetail detail : fileDoc.getDetails()) {
				if (!detail.isFooter()) {
					if (dataBuff.length > 0)
						dataBuff = concat(dataBuff, getLineSeparator().getBytes(ENCODING));
					dataBuff = concat(dataBuff, detailStringData(detail));
				}
			}

			// 尾筆
			if (footer != null) {

				// dataBuff = detailStringData(footer);

				if (dataBuff.length > 0)
					dataBuff = concat(dataBuff, getLineSeparator().getBytes(ENCODING));
				dataBuff = concat(dataBuff, detailStringData(footer));
			}

			return dataBuff;
		}
		catch (UnsupportedEncodingException e) {

			ActionException ex = getActionException(CibErrorCode.VALIDATE_SIZE_ERROR);

			throw ex;
		}
	}

	/**
	 * 加入明細
	 * 
	 * @param detail
	 */
	public void addDetails(StFileSection detail) {
		details.add(detail);
		FileDetail fileDetail = new FileDetail();
		fileDetail.addSection(detail.getFileSection());
		getFileDoc().addDetail(fileDetail);
	}

	/**
	 * 加入尾筆
	 * 
	 * @param detail
	 */
	public void addFooter(StFooterFileSection detail) {
		FileDetail fileDetail = new FileDetail();
		fileDetail.addSection(detail.getFileSection());
		getFileDoc().addDetail(fileDetail);
	}

}
