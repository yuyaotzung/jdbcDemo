/*
 * ===========================================================================
 * IBM Confidential
 * AIS Source Materials
 * 
 * 
 * (C) Copyright IBM Corp. 2018.
 *
 * ===========================================================================
 */
package com.cosmos.file.ext;

import com.cosmos.file.bo.FileField;
import com.cosmos.file.bo.FileSection;
import com.cosmos.file.def.Cactx102ResultN2NTxFileDefinition;
import com.cosmos.file.def.IFileDefinition;
import com.cosmos.type.FieldGroup;
import com.ibm.tw.commons.util.StringUtils;

/**
 * <p>
 * 整批多扣多入Tx格式
 * </p>
 * 
 * @author Bear
 * @version 1.0, 2018/4/10
 * @see
 * @since
 */
public class Cactx102ResultN2NTxFileSection {

	/** 檔案區段 */
	private FileSection fileSection;

	public Cactx102ResultN2NTxFileSection() {
		fileSection = new FileSection();
		fileSection.setFieldGroup(FieldGroup.TX);
	}

	public Cactx102ResultN2NTxFileSection(FileSection fileSection) {
		this.fileSection = fileSection;
	}

	public FileSection getFileSection() {
		return fileSection;
	}

	// 批號
	public String getBatchNo() {
		return getValue(Cactx102ResultN2NTxFileDefinition.BATCH_NO);
	}

	public void setBatchNo(String value) {
		setValue(Cactx102ResultN2NTxFileDefinition.BATCH_NO, value);
	}

	// 流水號
	public String getSerno() {
		return getValue(Cactx102ResultN2NTxFileDefinition.SERNO);
	}

	public void setSerno(String value) {
		setValue(Cactx102ResultN2NTxFileDefinition.SERNO, value);
	}

	// 付款通路
	public String getPayChanel() {
		return getValue(Cactx102ResultN2NTxFileDefinition.PAY_CHANEL);
	}

	public void setPayChanel(String value) {
		setValue(Cactx102ResultN2NTxFileDefinition.PAY_CHANEL, value);
	}

	// 付款人帳號
	public String getPayerAccountNo() {
		return getValue(Cactx102ResultN2NTxFileDefinition.PAYER_ACCOUNT_NO);
	}

	public void setPayerAccountNo(String value) {
		setValue(Cactx102ResultN2NTxFileDefinition.PAYER_ACCOUNT_NO, value);
	}

	// 付款人戶名
	public String getPayerName() {
		return getValue(Cactx102ResultN2NTxFileDefinition.PAYER_NAME);
	}

	public void setPayerName(String value) {
		setValue(Cactx102ResultN2NTxFileDefinition.PAYER_NAME, value);
	}

	// 付款人統編
	public String getPayerUid() {
		return getValue(Cactx102ResultN2NTxFileDefinition.PAYER_UID);
	}

	public void setPayerUid(String value) {
		setValue(Cactx102ResultN2NTxFileDefinition.PAYER_UID, value);
	}

	// 收款銀行代號
	public String getReceiveBankCode() {
		return getValue(Cactx102ResultN2NTxFileDefinition.RECEIVE_BANK_CODE);
	}

	public void setReceiveBankCode(String value) {
		setValue(Cactx102ResultN2NTxFileDefinition.RECEIVE_BANK_CODE, value);
	}

	// 轉入帳號
	public String getRollInAcct() {
		return getValue(Cactx102ResultN2NTxFileDefinition.ROLL_IN_ACCT);
	}

	public void setRollInAcct(String value) {
		setValue(Cactx102ResultN2NTxFileDefinition.ROLL_IN_ACCT, value);
	}

	// 交易金額
	public String getAmount() {
		return getValue(Cactx102ResultN2NTxFileDefinition.AMOUNT);
	}

	public void setAmount(String value) {
		setValue(Cactx102ResultN2NTxFileDefinition.AMOUNT, value);
	}

	// 提示碼
	public String getPromoCode() {
		return getValue(Cactx102ResultN2NTxFileDefinition.PROMO_CODE);
	}

	public void setPromoCode(String value) {
		setValue(Cactx102ResultN2NTxFileDefinition.PROMO_CODE, value);
	}

	// 存摺附註
	public String getRemarks() {
		return getValue(Cactx102ResultN2NTxFileDefinition.REMARKS);
	}

	public void setRemarks(String value) {
		setValue(Cactx102ResultN2NTxFileDefinition.REMARKS, value);
	}

	// 轉入附註
	public String getRemarks1() {
		return getValue(Cactx102ResultN2NTxFileDefinition.REMARKS1);
	}

	public void setRemarks1(String value) {
		setValue(Cactx102ResultN2NTxFileDefinition.REMARKS1, value);
	}

	// 檢核ID
	public String getCheckId() {
		return getValue(Cactx102ResultN2NTxFileDefinition.CHECK_ID);
	}

	public void setCheckId(String value) {
		setValue(Cactx102ResultN2NTxFileDefinition.CHECK_ID, value);
	}

	// 檢核戶名
	public String getCheckName() {
		return getValue(Cactx102ResultN2NTxFileDefinition.CHECK_NAME);
	}

	public void setCheckName(String value) {
		setValue(Cactx102ResultN2NTxFileDefinition.CHECK_NAME, value);
	}

	// 櫃員手續費/匯款手續費
	public String getFee() {
		return getValue(Cactx102ResultN2NTxFileDefinition.FEE);
	}

	public void setFee(String value) {
		setValue(Cactx102ResultN2NTxFileDefinition.FEE, value);
	}

	// 附言
	public String getPostScript() {
		return getValue(Cactx102ResultN2NTxFileDefinition.POST_SCRIPT);
	}

	public void setPostScript(String value) {
		setValue(Cactx102ResultN2NTxFileDefinition.POST_SCRIPT, value);
	}

	// BaNCS中心執行結果
	public String getBancsStat() {
		return getValue(Cactx102ResultN2NTxFileDefinition.BANCS_STAT);
	}

	public void setBancsStat(String value) {
		setValue(Cactx102ResultN2NTxFileDefinition.BANCS_STAT, value);
	}

	// 匯款處理結果
	public String getFepResult() {
		return getValue(Cactx102ResultN2NTxFileDefinition.FEP_RESULT);
	}

	public void setFepResult(String value) {
		setValue(Cactx102ResultN2NTxFileDefinition.FEP_RESULT, value);
	}

	// 匯款編號
	public String getFepNo() {
		return getValue(Cactx102ResultN2NTxFileDefinition.FEP_NO);
	}

	public void setFepNo(String value) {
		setValue(Cactx102ResultN2NTxFileDefinition.FEP_NO, value);
	}

	// 交易序號
	public String getJrnlNo() {
		return getValue(Cactx102ResultN2NTxFileDefinition.JRNL_NO);
	}

	public void setJrnlNo(String value) {
		setValue(Cactx102ResultN2NTxFileDefinition.JRNL_NO, value);
	}

	// ========================================================
	// 以下可共用

	/**
	 * 
	 * @param fileDefinition
	 * @return
	 */
	private String getValue(IFileDefinition fileDefinition) {

		FileField fileField = fileSection.getField(fileDefinition.getId());
		if (fileField == null) {
			return null;
		}
		else {
			return StringUtils.trim(fileField.getValue());
		}
	}

	/**
	 * 
	 * @param fileDefinition
	 * @param value
	 */
	private void setValue(IFileDefinition fileDefinition, String value) {

		if (fileSection == null) {
			fileSection = new FileSection();
		}

		FileField field = fileSection.getField(fileDefinition.getId());
		if (field == null) {
			field = new FileField();
			field.setFieldId(fileDefinition.getId());
			field.setValue(value);
			fileSection.addField(field);
		}
		else {
			field.setValue(value);
		}
	}

	// 以上可共用
	// ========================================================
}
