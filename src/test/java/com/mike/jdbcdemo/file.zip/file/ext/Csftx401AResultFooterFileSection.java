/*
 * ===========================================================================
 * IBM Confidential
 * AIS Source Materials
 * 
 * 
 * (C) Copyright IBM Corp. 2018.
 *
 * ===========================================================================
 */
package com.cosmos.file.ext;

import com.cosmos.file.bo.FileField;
import com.cosmos.file.bo.FileSection;
import com.cosmos.file.def.Csftx401AResultFooterFileDefinition;
import com.cosmos.file.def.IFileDefinition;
import com.cosmos.type.FieldGroup;
import com.ibm.tw.commons.util.StringUtils;



/**
 * <p>  外幣整批扣自入自、複委託扣帳-扣客戶入發動者(凱基)  description</p>
 *
 * @author  Bear
 * @version 1.0, 2018/6/5
 * @see	    
 * @since 
 */
public class Csftx401AResultFooterFileSection {
	
	/** 檔案區段 */
	private FileSection fileSection;
	
	public Csftx401AResultFooterFileSection() {
		fileSection = new FileSection();
		fileSection.setFieldGroup(FieldGroup.FOOTER);
	}
	
	public Csftx401AResultFooterFileSection(FileSection fileSection) {
		this.fileSection = fileSection;
	}
	
	public FileSection getFileSection() {
		return fileSection;
	}
	
//	Data Indicator
	public String getDataIndicator() {
		return getValue(Csftx401AResultFooterFileDefinition.DATA_INDICATOR);
	}
	
	public void setDataIndicator(String value) {
		setValue(Csftx401AResultFooterFileDefinition.DATA_INDICATOR, value);
	}
	
//	明細總筆數
	public String getTotalCount() {
		return getValue(Csftx401AResultFooterFileDefinition.TOTAL_COUNT);
	}
	
	public void setTotalCount(String value) {
		setValue(Csftx401AResultFooterFileDefinition.TOTAL_COUNT, value);
	}
	
//	明細總金額
	public String getTotalAmt() {
		return getValue(Csftx401AResultFooterFileDefinition.TOTAL_AMT);
	}
	
	public void setTotalAmt(String value) {
		setValue(Csftx401AResultFooterFileDefinition.TOTAL_AMT, value);
	}
	
	
//	FILLER
	public String getFiller() {
		return getValue(Csftx401AResultFooterFileDefinition.FILLER);
	}
	
	public void setFiller(String value) {
		setValue(Csftx401AResultFooterFileDefinition.FILLER, value);
	}

	//========================================================
	// 以下可共用
	
	
	/**
	 * 
	 * @param fileDefinition
	 * @return
	 */
	private String getValue(IFileDefinition fileDefinition) {
		
		FileField fileField = fileSection.getField(fileDefinition.getId());
		if (fileField == null) {
			return null;
		}
		else {
			return StringUtils.trim(fileField.getValue());
		}
	}
	
	/**
	 * 
	 * @param fileDefinition
	 * @param value
	 */
	private void setValue(IFileDefinition fileDefinition, String value) {

		if (fileSection == null) {
			fileSection = new FileSection();
		}

		FileField field = fileSection.getField(fileDefinition.getId());
		if (field == null) {
			field = new FileField();
			field.setFieldId(fileDefinition.getId());
			field.setValue(value);
			fileSection.addField(field);
		}
		else {
			field.setValue(value);
		}
	}
	
	// 以上可共用
	//========================================================

}



 