/*
 * ===========================================================================
 * IBM Confidential
 * AIS Source Materials
 *
 *
 * (C) Copyright IBM Corp. 2011.
 *
 * ===========================================================================
 */
package com.cosmos.file.ext;

import com.cosmos.file.bo.FileField;
import com.cosmos.file.bo.FileSection;
import com.cosmos.file.def.CactxB01ResultTxFileDefinition;
import com.cosmos.file.def.IFileDefinition;
import com.cosmos.type.FieldGroup;
import com.ibm.tw.commons.util.StringUtils;

/**
 * <p>
 * FISC整批代收格式(明細錄)
 * </p>
 * 
 * @author Hank
 * @version 1.0, 2016/106
 * @see
 * @since
 */
public class CactxB01ResultTxFileSection {

	/** 檔案區段 */
	private FileSection fileSection;

	public CactxB01ResultTxFileSection() {

		fileSection = new FileSection();
		fileSection.setFieldGroup(FieldGroup.TX);
	}

	public CactxB01ResultTxFileSection(FileSection fileSection) {
		this.fileSection = fileSection;
	}

	public FileSection getFileSection() {
		return fileSection;
	}

	// 區別碼
	public String getSecNo() {
		return getValue(CactxB01ResultTxFileDefinition.SECNO);
	}

	public void setSecNo(String value) {
		setValue(CactxB01ResultTxFileDefinition.SECNO, value);
	}

	// 委託單位
	public String getPunit() {
		return getValue(CactxB01ResultTxFileDefinition.PUNIT);
	}

	public void setPunit(String value) {
		setValue(CactxB01ResultTxFileDefinition.PUNIT, value);
	}

	// 收件單位
	public String getRunit() {
		return getValue(CactxB01ResultTxFileDefinition.RUNIT);
	}

	public void setRunit(String value) {
		setValue(CactxB01ResultTxFileDefinition.RUNIT, value);
	}

	// 交易日期
	public String getTxDate() {
		return getValue(CactxB01ResultTxFileDefinition.TXDATE);
	}

	public void setTxDate(String value) {
		setValue(CactxB01ResultTxFileDefinition.TXDATE, value);
	}

	// 費用類別
	public String getPaymentType() {
		return getValue(CactxB01ResultTxFileDefinition.PAYMENT_TYPE);
	}

	public void setPaymentType(String value) {
		setValue(CactxB01ResultTxFileDefinition.PAYMENT_TYPE, value);
	}

	// 交易序號
	public String getTxno() {
		return getValue(CactxB01ResultTxFileDefinition.TXNO);
	}

	public void setTxno(String value) {
		setValue(CactxB01ResultTxFileDefinition.TXNO, value);
	}

	// 固定為+號
	public String getChk1() {
		return getValue(CactxB01ResultTxFileDefinition.CHK1);
	}

	public void setChk1(String value) {
		setValue(CactxB01ResultTxFileDefinition.CHK1, value);
	}

	// 交易金額
	public String getTxAmt() {
		return getValue(CactxB01ResultTxFileDefinition.TXAMT);
	}

	public void setTxAmt(String value) {
		setValue(CactxB01ResultTxFileDefinition.TXAMT, value);
	}

	// 委託單位區別
	public String getPUnitSec() {
		return getValue(CactxB01ResultTxFileDefinition.PUNIT_SEC);
	}

	public void setPUnitSec(String value) {
		setValue(CactxB01ResultTxFileDefinition.PUNIT_SEC, value);
	}

	// 委託單位代號
	public String getPUnitNo() {
		return getValue(CactxB01ResultTxFileDefinition.PUNIT_NO);
	}

	public void setPUnitNo(String value) {
		setValue(CactxB01ResultTxFileDefinition.PUNIT_NO, value);
	}

	// 實際入/扣帳日期
	public String getExcdDate() {
		return getValue(CactxB01ResultTxFileDefinition.EXCDATE);
	}

	public void setExcdDate(String value) {
		setValue(CactxB01ResultTxFileDefinition.EXCDATE, value);
	}

	// 回應代碼
	public String getStatusCode() {
		return getValue(CactxB01ResultTxFileDefinition.STATUSCODE);
	}

	public void setStatusCode(String value) {
		setValue(CactxB01ResultTxFileDefinition.STATUSCODE, value);
	}

	// 轉帳行代碼
	public String getPayerBankId() {
		return getValue(CactxB01ResultTxFileDefinition.PAYER_BANKID);
	}

	public void setPayerBankId(String value) {
		setValue(CactxB01ResultTxFileDefinition.PAYER_BANKID, value);
	}

	// 轉帳號
	public String getPayerAccNo() {
		return getValue(CactxB01ResultTxFileDefinition.PAYER_ACCNO);
	}

	public void setPayerAccNo(String value) {
		setValue(CactxB01ResultTxFileDefinition.PAYER_ACCNO, value);
	}

	// 帳戶ID
	public String getPayerId() {
		return getValue(CactxB01ResultTxFileDefinition.PAYER_ID);
	}

	public void setPayerId(String value) {
		setValue(CactxB01ResultTxFileDefinition.PAYER_ID, value);
	}

	// 銷帳編號
	public String getPaymentId() {
		return getValue(CactxB01ResultTxFileDefinition.PAYMENT_ID);
	}

	public void setPaymentId(String value) {
		setValue(CactxB01ResultTxFileDefinition.PAYMENT_ID, value);
	}

	// 費用代號
	public String getPaymentCode() {
		return getValue(CactxB01ResultTxFileDefinition.PAYMENT_CODE);
	}

	public void setPaymentCode(String value) {
		setValue(CactxB01ResultTxFileDefinition.PAYMENT_CODE, value);
	}

	// 銀行專用區
	public String getBankData() {
		return getValue(CactxB01ResultTxFileDefinition.BANK_DATA);
	}

	public void setBankData(String value) {
		setValue(CactxB01ResultTxFileDefinition.BANK_DATA, value);
	}

	// 事業單位專用資料區
	public String getBuData() {
		return getValue(CactxB01ResultTxFileDefinition.BU_DATA);
	}

	public void setBuData(String value) {
		setValue(CactxB01ResultTxFileDefinition.BU_DATA, value);
	}

	// ========================================================
	// 以下可共用

	/**
	 * 
	 * @param fileDefinition
	 * @return
	 */
	private String getValue(IFileDefinition fileDefinition) {
		FileField fileField = fileSection.getField(fileDefinition.getId());
		if (fileField == null) {
			return null;
		}
		else {
			return StringUtils.trim(fileField.getValue());
		}
	}

	/**
	 * 
	 * @param fileDefinition
	 * @param value
	 */
	private void setValue(IFileDefinition fileDefinition, String value) {

		if (fileSection == null) {
			fileSection = new FileSection();
		}

		FileField field = fileSection.getField(fileDefinition.getId());
		if (field == null) {
			field = new FileField();
			field.setFieldId(fileDefinition.getId());
			field.setValue(value);
			fileSection.addField(field);
		}
		else {
			field.setValue(value);
		}
	}

}
