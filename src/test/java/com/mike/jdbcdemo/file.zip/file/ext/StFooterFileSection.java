/*
 * ===========================================================================
 * IBM Confidential
 * AIS Source Materials
 * 
 * 
 * (C) Copyright IBM Corp. 2011.
 *
 * ===========================================================================
 */
package com.cosmos.file.ext;

import com.cosmos.file.bo.FileField;
import com.cosmos.file.bo.FileSection;
import com.cosmos.type.FieldGroup;
import com.ibm.tw.commons.util.StringUtils;

/**
 * <p>
 * 台幣自行授權扣帳檔案上傳檔案 尾筆資料
 * </p>
 * 
 * @author BearChen
 * @version 1.0, 2011/6/27
 * @see
 * @since
 */
public class StFooterFileSection {

	/** 檔案區段 */
	private FileSection fileSection;

	public StFooterFileSection(FileSection fileSection) {
		this.fileSection = fileSection;
	}

	public StFooterFileSection(FieldGroup fieldGroup) {
		fileSection = new FileSection();
		fileSection.setFieldGroup(fieldGroup);
	}

	/**
	 * 保留欄1
	 * 
	 * @return
	 */
	public String getMemo1() {
		FileField fileField = fileSection.getField("footerMemo1");
		if (fileField == null) {
			return null;
		}
		else {
			return StringUtils.trim(fileField.getValue());
		}
	}

	/**
	 * 設定保留欄1
	 * 
	 * @param value
	 */
	public void setMemo1(String value) {
		setValue("footerMemo1", value);
	}

	/**
	 * 轉帳總筆數
	 * 
	 * @return
	 */
	public String getCount() {
		FileField fileField = fileSection.getField("footerCount");
		if (fileField == null) {
			return null;
		}
		else {
			return StringUtils.trim(fileField.getValue());
		}
	}

	/**
	 * 設定轉帳總筆數
	 * 
	 * @param value
	 */
	public void setCount(String value) {
		setValue("footerCount", value);
	}

	/**
	 * 轉帳代碼
	 * 
	 * @return
	 */
	public String getTransCode() {
		FileField fileField = fileSection.getField("footerTransCode");
		if (fileField == null) {
			return null;
		}
		else {
			return fileField.getValue();
		}
	}

	/**
	 * 設定轉帳代碼
	 * 
	 * @param value
	 */
	public void setTransCode(String value) {
		setValue("footerTransCode", value);
	}

	/**
	 * 交易日期
	 * 
	 * @return
	 */
	public String getTxDate() {
		FileField fileField = fileSection.getField("footerTxDate");
		if (fileField == null) {
			return null;
		}
		else {
			return fileField.getValue();
		}
	}

	/**
	 * 設定交易日期
	 * 
	 * @param value
	 */
	public void setTxDate(String value) {
		setValue("footerTxDate", value);
	}

	/**
	 * 帳號轉帳類別代號 1115 為入帳 1315為扣帳
	 * 
	 * @return
	 */
	public String getAccountType() {
		FileField fileField = fileSection.getField("footerAccountType");
		if (fileField == null) {
			return null;
		}
		else {
			return fileField.getValue();
		}
	}

	/**
	 * 設定帳號轉帳類別代號 1115 為入帳 1315為扣帳
	 * 
	 * @param value
	 */
	public void setAccountType(String value) {
		setValue("footerAccountType", value);
	}

	/**
	 * 交易金額
	 * 
	 * @return
	 */
	public String getTxAmt() {
		FileField fileField = fileSection.getField("footerTxAmt");
		if (fileField == null) {
			return null;
		}
		else {
			return fileField.getValue();
		}
	}

	/**
	 * 設定 交易金額
	 * 
	 * @param value
	 */
	public void setTxAmt(String value) {
		setValue("footerTxAmt", value);
	}

	/**
	 * 發動者統編
	 * 
	 * @return
	 */
	public String getUid() {
		FileField fileField = fileSection.getField("footerUid");
		if (fileField == null) {
			return null;
		}
		else {
			return StringUtils.trim(fileField.getValue());
		}
	}

	/**
	 * 設定發動者統編
	 * 
	 * @param value
	 */
	public void setUid(String value) {
		setValue("footerUid", value);
	}

	/**
	 * 轉帳業務種類
	 * 
	 * @return
	 */
	public String getTTransType() {
		FileField fileField = fileSection.getField("footerTransType");
		if (fileField == null) {
			return null;
		}
		else {
			return StringUtils.trim(fileField.getValue());
		}
	}

	/**
	 * 設定轉帳業務種類
	 * 
	 * @param value
	 */
	public void setTransType(String value) {
		setValue("footerTransType", value);
	}

	/**
	 * 保留欄2
	 * 
	 * @return
	 */
	public String getMemo2() {
		FileField fileField = fileSection.getField("footerMemo2");
		if (fileField == null) {
			return null;
		}
		else {
			return StringUtils.trim(fileField.getValue());
		}
	}

	/**
	 * 設定保留欄2
	 * 
	 * @param value
	 */
	public void setMemo2(String value) {
		setValue("footerMemo2", value);
	}

	public FileSection getFileSection() {
		return fileSection;
	}

	/**
	 * 
	 * @param fieldId
	 * @param value
	 */
	private void setValue(String fieldId, String value) {

		if (fileSection == null) {
			fileSection = new FileSection();
		}

		FileField field = fileSection.getField(fieldId);
		if (field == null) {
			field = new FileField();
			field.setFieldId(fieldId);
			field.setValue(value);
			fileSection.addField(field);
		}
		else {
			field.setValue(value);
		}
	}
}
