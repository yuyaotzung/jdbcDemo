/*
 * ===========================================================================
 * IBM Confidential
 * AIS Source Materials
 * 
 * 
 * (C) Copyright IBM Corp. 2011.
 *
 * ===========================================================================
 */
package com.cosmos.file.ext;

import com.cosmos.file.bo.FileField;
import com.cosmos.file.bo.FileSection;
import com.cosmos.type.FieldGroup;
import com.ibm.tw.commons.util.StringUtils;

/**
 * <p>
 * 證券款檔案上傳
 * </p>
 * 
 * @author BearChen
 * @version 1.0, 2011/6/27
 * @see
 * @since
 */
public class PBSHeaderFileSection {

	/** 檔案區段 */
	private FileSection fileSection;

	public PBSHeaderFileSection(FileSection fileSection) {
		this.fileSection = fileSection;
	}

	public PBSHeaderFileSection(FieldGroup fieldGroup) {
		fileSection = new FileSection();
		fileSection.setFieldGroup(fieldGroup);
	}

	public FileSection getFileSection() {
		return fileSection;
	}

	/**
	 * 客戶銀行付款帳號
	 * 
	 * @return
	 */
	public String getTotalCount() {
		FileField fileField = fileSection.getField("totalCount");
		if (fileField == null) {
			return null;
		}
		else {
			return StringUtils.trim(fileField.getValue());
		}
	}

	/**
	 * 券商股款轉帳代碼
	 * 
	 * @return
	 */
	public String getPayeeTransId() {
		FileField fileField = fileSection.getField("payeeTransIdHeader");
		if (fileField == null) {
			return null;
		}
		else {
			return StringUtils.trim(fileField.getValue());
		}
	}

	/**
	 * 交易日期
	 * 
	 * @return
	 */
	public String getTxDate() {
		FileField fileField = fileSection.getField("txDateHeader");
		if (fileField == null) {
			return null;
		}
		else {
			return fileField.getValue();
		}
	}

	/**
	 * 帳號轉帳類別代號 1115為入帳 1315為扣帳
	 * 
	 * @return
	 */
	public String getPayeeAccountTypeId() {
		FileField fileField = fileSection.getField("payeeAccountTypeIdH");
		if (fileField == null) {
			return null;
		}
		else {
			return fileField.getValue();
		}
	}

	/**
	 * 交易金額
	 * 
	 * @return
	 */
	public String getTotalAmt() {
		FileField fileField = fileSection.getField("totalAmt");
		if (fileField == null) {
			return null;
		}
		else {
			return fileField.getValue();
		}
	}

	/**
	 * 券商統編
	 * 
	 * @return
	 */
	public String getPayeeUid() {
		FileField fileField = fileSection.getField("payeeUidHeader");
		if (fileField == null) {
			return null;
		}
		else {
			return StringUtils.trim(fileField.getValue());
		}
	}

	/**
	 * 轉帳業務種類
	 * 
	 * @return
	 */
	public String getTransType() {
		FileField fileField = fileSection.getField("transTypeHeader");
		if (fileField == null) {
			return null;
		}
		else {
			return StringUtils.trim(fileField.getValue());
		}
	}

	/**
	 * 設定轉帳業務種類
	 * 
	 * @param value
	 */
	public void setTransType(String value) {
		setValue("transTypeHeader", value);
	}

	/**
	 * 設定總筆數
	 * 
	 * @param value
	 */
	public void setTotalCount(String value) {
		setValue("totalCount", value);
	}

	/**
	 * 設定券商股款轉帳代碼
	 * 
	 * @param value
	 */
	public void setPayeeTransId(String value) {
		setValue("payeeTransIdHeader", value);
	}

	/**
	 * 設定交易日期
	 * 
	 * @param value
	 */
	public void setTxDate(String value) {
		setValue("txDateHeader", value);
	}

	/**
	 * 設定帳號轉帳類別代號 1115為入帳 1315為扣帳
	 * 
	 * @param value
	 */
	public void setPayeeAccountTypeId(String value) {
		setValue("payeeAccountTypeIdH", value);
	}

	/**
	 * 設定交易金額
	 * 
	 * @param value
	 */
	public void setTotalAmt(String value) {
		setValue("totalAmt", value);
	}

	/**
	 * 設定券商統編
	 * 
	 * @param value
	 */
	public void setPayeeUid(String value) {
		setValue("payeeUidHeader", value);
	}

	/**
	 * 
	 * @param fieldId
	 * @param value
	 */
	private void setValue(String fieldId, String value) {

		if (fileSection == null) {
			fileSection = new FileSection();
		}

		FileField field = fileSection.getField(fieldId);
		if (field == null) {
			field = new FileField();
			field.setFieldId(fieldId);
			field.setValue(value);
			fileSection.addField(field);
		}
		else {
			field.setValue(value);
		}
	}

}
