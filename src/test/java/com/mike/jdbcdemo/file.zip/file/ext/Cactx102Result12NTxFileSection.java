/*
 * ===========================================================================
 * IBM Confidential
 * AIS Source Materials
 * 
 * 
 * (C) Copyright IBM Corp. 2018.
 *
 * ===========================================================================
 */
package com.cosmos.file.ext;

import com.cosmos.file.bo.FileField;
import com.cosmos.file.bo.FileSection;
import com.cosmos.file.def.Cactx102Result12NTxFileDefinition;
import com.cosmos.file.def.IFileDefinition;
import com.cosmos.type.FieldGroup;
import com.ibm.tw.commons.util.StringUtils;



/**
 * <p> 整批多扣多入Tx格式 </p>
 *
 * @author  Bear
 * @version 1.0, 2018/4/10
 * @see	    
 * @since 
 */
public class Cactx102Result12NTxFileSection {
	/** 檔案區段 */
	private FileSection fileSection;
	
	public Cactx102Result12NTxFileSection(){
		fileSection = new FileSection();
		fileSection.setFieldGroup(FieldGroup.TX);
	}
	
	public Cactx102Result12NTxFileSection(FileSection fileSection) {
		this.fileSection = fileSection;
	}
	
	public FileSection getFileSection() {
		return fileSection;
	}
	//批號
	public String getBatchNo() {
		return getValue(Cactx102Result12NTxFileDefinition.BATCH_NO);
	}
	
	public void setBatchNo(String value) {
		setValue(Cactx102Result12NTxFileDefinition.BATCH_NO, value);
	}
	
	//流水號
	public String getSerno() {
		return getValue(Cactx102Result12NTxFileDefinition.SERNO);
	}
	
	public void setSerno(String value) {
		setValue(Cactx102Result12NTxFileDefinition.SERNO, value);
	}
	
	//付款通路
	public String getPayChanel() {
		return getValue(Cactx102Result12NTxFileDefinition.PAY_CHANEL);
	}
	
	public void setPayChanel(String value) {
		setValue(Cactx102Result12NTxFileDefinition.PAY_CHANEL, value);
	}
	
	//收款銀行代號
	public String getReceiveBankCode() {
		return getValue(Cactx102Result12NTxFileDefinition.RECEIVE_BANK_CODE);
	}
	
	public void setReceiveBankCode(String value) {
		setValue(Cactx102Result12NTxFileDefinition.RECEIVE_BANK_CODE, value);
	}
	
	//轉入帳號
	public String getRollInAcct() {
		return getValue(Cactx102Result12NTxFileDefinition.ROLL_IN_ACCT);
	}
	
	public void setRollInAcct(String value) {
		setValue(Cactx102Result12NTxFileDefinition.ROLL_IN_ACCT, value);
	}
	
	//交易金額
	public String getAmount() {
		return getValue(Cactx102Result12NTxFileDefinition.AMOUNT);
	}
	
	public void setAmount(String value) {
		setValue(Cactx102Result12NTxFileDefinition.AMOUNT, value);
	}
	
	//提示碼
	public String getPromoCode() {
		return getValue(Cactx102Result12NTxFileDefinition.PROMO_CODE);
	}
	
	public void setPromoCode(String value) {
		setValue(Cactx102Result12NTxFileDefinition.PROMO_CODE, value);
	}

	//存摺附註
	public String getRemarks() {
		return getValue(Cactx102Result12NTxFileDefinition.REMARKS);
	}
	
	public void setRemarks(String value) {
		setValue(Cactx102Result12NTxFileDefinition.REMARKS, value);
	}
	
	//檢核ID
	public String getCheckId() {
		return getValue(Cactx102Result12NTxFileDefinition.CHECK_ID);
	}
	
	public void setCheckId(String value) {
		setValue(Cactx102Result12NTxFileDefinition.CHECK_ID, value);
	}
	
	//檢核戶名
	public String getCheckName() {
		return getValue(Cactx102Result12NTxFileDefinition.CHECK_NAME);
	}
	
	public void setCheckName(String value) {
		setValue(Cactx102Result12NTxFileDefinition.CHECK_NAME, value);
	}
	
	//櫃員手續費/匯款手續費
	public String getFee() {
		return getValue(Cactx102Result12NTxFileDefinition.FEE);
	}
	
	public void setFee(String value) {
		setValue(Cactx102Result12NTxFileDefinition.FEE, value);
	}
	
	//附言
	public String getPostScript() {
		return getValue(Cactx102Result12NTxFileDefinition.POST_SCRIPT);
	}
	
	public void setPostScript(String value) {
		setValue(Cactx102Result12NTxFileDefinition.POST_SCRIPT, value);
	}
	
	//BaNCS中心執行結果BANCS-STAT
	public String getBancsStat() {
		return getValue(Cactx102Result12NTxFileDefinition.BANCS_STAT);
	}
	
	public void setBancsStat(String value) {
		setValue(Cactx102Result12NTxFileDefinition.BANCS_STAT, value);
	}
	
	//匯款處理結果
	public String getFepResult() {
		return getValue(Cactx102Result12NTxFileDefinition.FEP_RESULT);
	}
	
	public void setFepResult(String value) {
		setValue(Cactx102Result12NTxFileDefinition.FEP_RESULT, value);
	}
	
	//匯款編號
	public String getFepNo() {
		return getValue(Cactx102Result12NTxFileDefinition.FEP_NO);
	}
	
	public void setFepNo(String value) {
		setValue(Cactx102Result12NTxFileDefinition.FEP_NO, value);
	}
	
	//交易序號
	public String getJrnlNo() {
		return getValue(Cactx102Result12NTxFileDefinition.JRNL_NO);
	}
	
	public void setJrnlNo(String value) {
		setValue(Cactx102Result12NTxFileDefinition.JRNL_NO, value);
	}
	
	
	//========================================================
	// 以下可共用
	
	
	/**
	 * 
	 * @param fileDefinition
	 * @return
	 */
	private String getValue(IFileDefinition fileDefinition) {
		
		FileField fileField = fileSection.getField(fileDefinition.getId());
		if (fileField == null) {
			return null;
		}
		else {
			return StringUtils.trim(fileField.getValue());
		}
	}
	
	/**
	 * 
	 * @param fileDefinition
	 * @param value
	 */
	private void setValue(IFileDefinition fileDefinition, String value) {

		if (fileSection == null) {
			fileSection = new FileSection();
		}

		FileField field = fileSection.getField(fileDefinition.getId());
		if (field == null) {
			field = new FileField();
			field.setFieldId(fileDefinition.getId());
			field.setValue(value);
			fileSection.addField(field);
		}
		else {
			field.setValue(value);
		}
	}
	
	// 以上可共用
	//========================================================
}



 