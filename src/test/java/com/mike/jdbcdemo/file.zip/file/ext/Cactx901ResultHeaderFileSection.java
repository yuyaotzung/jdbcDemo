/*
 * ===========================================================================
 * IBM Confidential
 * AIS Source Materials
 * 
 * 
 * (C) Copyright IBM Corp. 2018.
 *
 * ===========================================================================
 */
package com.cosmos.file.ext;

import com.cosmos.file.bo.FileField;
import com.cosmos.file.bo.FileSection;
import com.cosmos.file.def.Cactx901ResultHeaderFileDefinition;
import com.cosmos.file.def.IFileDefinition;
import com.cosmos.type.FieldGroup;
import com.ibm.tw.commons.util.StringUtils;



/**
 * <p> 台幣整批扣自入自、複委託扣帳 </p>
 *
 * @author  Bear
 * @version 1.0, 2018/4/16
 * @see	    
 * @since 
 */
public class Cactx901ResultHeaderFileSection {
	
	/** 檔案區段 */
	private FileSection fileSection;	
	
	public Cactx901ResultHeaderFileSection(){
		
		fileSection = new FileSection();
		fileSection.setFieldGroup(FieldGroup.HEADER);
	}
	
	public Cactx901ResultHeaderFileSection(FileSection fileSection) {
		this.fileSection = fileSection;
	}
	
	public FileSection getFileSection() {
		return fileSection;
	}
	
	//交易使用的分行號碼
	public String getBranchNo() {
		return getValue(Cactx901ResultHeaderFileDefinition.BRANCH_NO);
	}
	
	public void setBranchNo(String value) {
		setValue(Cactx901ResultHeaderFileDefinition.BRANCH_NO, value);
	}
	
	//交易使用的行員號碼
	public String getTellerNo() {
		return getValue(Cactx901ResultHeaderFileDefinition.TELLER_NO);
	}
	
	public void setTellerNo(String value) {
		setValue(Cactx901ResultHeaderFileDefinition.TELLER_NO, value);
	}

	//交易使用的端末機號
	public String getTermNo() {
		return getValue(Cactx901ResultHeaderFileDefinition.TERM_NO);
	}
	
	public void setTermNo(String value) {
		setValue(Cactx901ResultHeaderFileDefinition.TERM_NO, value);
	}
	
	//交易日期
	public String getTxDate() {
		return getValue(Cactx901ResultHeaderFileDefinition.TX_DATE);
	}
	
	public void setTxDate(String value) {
		setValue(Cactx901ResultHeaderFileDefinition.TX_DATE, value);
	}
	
	//委託單位代號
	public String getUnitNo() {
		return getValue(Cactx901ResultHeaderFileDefinition.UNIT_NO);
	}
	
	public void setUnitNo(String value) {
		setValue(Cactx901ResultHeaderFileDefinition.UNIT_NO, value);
	}
	
	//轉帳類型
	public String getType() {
		return getValue(Cactx901ResultHeaderFileDefinition.TYPE);
	}
	
	public void setType(String value) {
		setValue(Cactx901ResultHeaderFileDefinition.TYPE, value);
	}
	
	//========================================================
	// 以下可共用
	
	
	/**
	 * 
	 * @param fileDefinition
	 * @return
	 */
	private String getValue(IFileDefinition fileDefinition) {
		FileField fileField = fileSection.getField(fileDefinition.getId());
		if (fileField == null) {
			return null;
		}
		else {
			return StringUtils.trim(fileField.getValue());
		}
	}
	
	
	/**
	 * 
	 * @param fileDefinition
	 * @param value
	 */
	private void setValue(IFileDefinition fileDefinition, String value) {

		if (fileSection == null) {
			fileSection = new FileSection();
		}

		FileField field = fileSection.getField(fileDefinition.getId());
		if (field == null) {
			field = new FileField();
			field.setFieldId(fileDefinition.getId());
			field.setValue(value);
			fileSection.addField(field);
		}
		else {
			field.setValue(value);
		}
	}
	
	// 以上可共用
	//========================================================
	

}



 