/*
 * ===========================================================================
 * IBM Confidential
 * AIS Source Materials
 * 
 * 
 * (C) Copyright IBM Corp. 2018.
 *
 * ===========================================================================
 */
package com.cosmos.file.ext;

import com.cosmos.file.bo.FileField;
import com.cosmos.file.bo.FileSection;
import com.cosmos.file.def.DgdfTxFileDefinition;
import com.cosmos.file.def.IFileDefinition;
import com.cosmos.type.FieldGroup;
import com.ibm.tw.commons.util.StringUtils;

/**
 * <p>
 * 臨櫃證券Tx格式
 * </p>
 * 
 * @author Bear
 * @version 1.0, 2018/4/10
 * @see
 * @since
 */
public class DgdfTxFileSection {

	/** 檔案區段 */
	private FileSection fileSection;

	public DgdfTxFileSection() {
		fileSection = new FileSection();
		fileSection.setFieldGroup(FieldGroup.TX);
	}

	public DgdfTxFileSection(FileSection fileSection) {
		this.fileSection = fileSection;
	}

	public FileSection getFileSection() {
		return fileSection;
	}

	// 轉入帳號
	public String getPayerAccountNo() {
		return getValue(DgdfTxFileDefinition.payerAccountNo);
	}

	public void setPayerAccountNo(String value) {
		setValue(DgdfTxFileDefinition.payerAccountNo, value);
	}

	/**
	 * 付款款人統編
	 * 
	 * @return
	 */
	public String getPayerUid() {
		return getValue(DgdfTxFileDefinition.payerUid);

	}

	public void setPayerUid(String value) {
		setValue(DgdfTxFileDefinition.payerUid, value);
	}

	/**
	 * 轉帳代碼 B
	 * 
	 * @return
	 */
	public String getPayeeTransId() {
		return getValue(DgdfTxFileDefinition.payeeTransId);

	}

	public void setPayeeTransId(String value) {
		setValue(DgdfTxFileDefinition.payeeTransId, value);
	}

	/**
	 * 交易日期
	 * 
	 * @return
	 */
	public String getTxDate() {
		return getValue(DgdfTxFileDefinition.txDate);

	}

	public void setTxDate(String value) {
		setValue(DgdfTxFileDefinition.txDate, value);
	}

	/**
	 * 轉帳類別
	 * 
	 * @return
	 */
	public String getPayeeAccountTypeId() {
		return getValue(DgdfTxFileDefinition.payeeAccountTypeId);

	}

	public void setPayeeAccountTypeId(String value) {
		setValue(DgdfTxFileDefinition.payeeAccountTypeId, value);
	}

	// 交易金額
	public String getTxAmt() {
		return getValue(DgdfTxFileDefinition.txAmt);
	}

	public void setTxAmt(String value) {
		setValue(DgdfTxFileDefinition.txAmt, value);
	}

	/**
	 * 收款人統編
	 * 
	 * @return
	 */
	public String getPayeeUid() {
		return getValue(DgdfTxFileDefinition.payeeUid);

	}

	public void setPayeeUid(String value) {
		setValue(DgdfTxFileDefinition.payeeUid, value);
	}

	/**
	 * 轉帳業務種類
	 * 
	 * @return
	 */
	public String getTransType() {
		return getValue(DgdfTxFileDefinition.transType);

	}

	public void setTransType(String value) {
		setValue(DgdfTxFileDefinition.transType, value);
	}

	/**
	 * 預留
	 * 
	 * @return
	 */
	public String getMark() {
		return getValue(DgdfTxFileDefinition.mark);

	}

	public void setMark(String value) {
		setValue(DgdfTxFileDefinition.mark, value);
	}

	/**
	 * 回覆碼
	 * 
	 * @return
	 */
	public String getReturnCode() {
		return getValue(DgdfTxFileDefinition.returnCode);

	}

	public void setReturnCode(String value) {
		setValue(DgdfTxFileDefinition.returnCode, value);
	}

	/**
	 * 客戶證券戶號
	 * 
	 * @return
	 */
	public String getPbsOwnerId() {
		return getValue(DgdfTxFileDefinition.pbsOwnerId);

	}

	public void setPbsOwnerId(String value) {
		setValue(DgdfTxFileDefinition.pbsOwnerId, value);
	}

	/**
	 * 股票代碼
	 * 
	 * @return
	 */
	public String getStocksId() {
		return getValue(DgdfTxFileDefinition.stocksId);

	}

	public void setStocksId(String value) {
		setValue(DgdfTxFileDefinition.stocksId, value);
	}

	// ========================================================
	// 以下可共用

	/**
	 * 
	 * @param fileDefinition
	 * @return
	 */
	private String getValue(IFileDefinition fileDefinition) {

		FileField fileField = fileSection.getField(fileDefinition.getId());
		if (fileField == null) {
			return null;
		}
		else {
			return StringUtils.trim(fileField.getValue());
		}
	}

	/**
	 * 
	 * @param fileDefinition
	 * @param value
	 */
	private void setValue(IFileDefinition fileDefinition, String value) {

		if (fileSection == null) {
			fileSection = new FileSection();
		}

		FileField field = fileSection.getField(fileDefinition.getId());
		if (field == null) {
			field = new FileField();
			field.setFieldId(fileDefinition.getId());
			field.setValue(value);
			fileSection.addField(field);
		}
		else {
			field.setValue(value);
		}
	}

	// 以上可共用
	// ========================================================
}
