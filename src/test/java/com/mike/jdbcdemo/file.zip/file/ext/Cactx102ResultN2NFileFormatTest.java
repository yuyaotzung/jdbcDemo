/*
 * ===========================================================================
 * IBM Confidential
 * AIS Source Materials
 * 
 * 
 * (C) Copyright IBM Corp. 2018.
 *
 * ===========================================================================
 */
package com.cosmos.file.ext;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.util.Date;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;

import org.apache.commons.io.FileUtils;

import com.cosmos.file.bo.FileDetail;
import com.cosmos.file.bo.FileDoc;
import com.cosmos.file.bo.FileSection;
import com.cosmos.param.ISystemParam;
import com.cosmos.param.ext.CibParam;
import com.cosmos.persistence.CosmosDaoFactory;
import com.cosmos.persistence.b2c.dao.B2CSequenceDao;
import com.cosmos.persistence.b2c.dao.IB2CSequenceDao;
import com.cosmos.persistence.b2c.dao.ISystemParamDao;
import com.cosmos.persistence.b2c.entity.SystemParamEntity;
import com.cosmos.persistence.b2c.entity.pk.SystemParamEntityPk;
import com.cosmos.type.FieldGroup;
import com.cosmos.util.SFTPUtils;
import com.ibm.tw.commons.aop.AOPProxyFactory;
import com.ibm.tw.commons.exception.ActionException;
import com.ibm.tw.commons.exception.CryptException;
import com.ibm.tw.commons.persistence.exception.DatabaseException;
import com.ibm.tw.commons.util.ConvertUtils;
import com.ibm.tw.commons.util.DESUtils;
import com.ibm.tw.commons.util.StringUtils;
import com.ibm.tw.commons.util.time.DateUtils;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.SftpException;

/**
 * <p>
 * TODO description
 * </p>
 * 
 * @author Bear
 * @version 1.0, 2018/4/10
 * @see
 * @since
 */
public class Cactx102ResultN2NFileFormatTest {

	// 多扣多入資料夾
	private static final String WORDKING_DIR = "0004";

	// Server
	static String server;

	// Port
	static int port;

	// 帳號
	static String user_put;

	// 密碼
	static String password_put;

	// 帳號
	static String user_get;

	// 密碼
	static String password_get;

	public static void main(String[] args) throws Throwable {

		init();

		// testExportFile();

		String fileName = "0004096022082018201808220010000794026000.TMP";

		testImportFile(fileName);

	}

	private static void init() {
		// Server
		server = getSystemParamValue(CibParam.FCS_SFTP_SERVER);
		// Port
		port = ConvertUtils.str2Int(getSystemParamValue(CibParam.FCS_SFTP_PORT));
		// 帳號
		user_put = getSystemParamValue(CibParam.FCS_SFTP_USER_PUT);
		// 密碼
		password_put = getSystemParamValue(CibParam.FCS_SFTP_PASSWORD_PUT);
		// 帳號
		user_get = getSystemParamValue(CibParam.FCS_SFTP_USER_GET);
		// 密碼
		password_get = getSystemParamValue(CibParam.FCS_SFTP_PASSWORD_GET);

	}

	private static void testExportFile() throws JSchException, SftpException, IOException, DatabaseException, ActionException {
		Cactx102ResultN2NFileFormat fileFormat = new Cactx102ResultN2NFileFormat("CACTX102");

		// 案件序號
		String flowDocId = generateCaseNo();

		// 交易日期
		Date txDate = new Date();

		prepareHeaders(fileFormat, flowDocId, txDate);
		prepareDetails(fileFormat, flowDocId);
		prepareFooters(fileFormat);
		byte[] data = new byte[0];

		data = fileFormat.toFile();

		String fileName = getFileName(txDate, flowDocId);

		System.out.println("fileName:" + fileName);

		// TODO 備份路徑??
		// 備份檔案
		FileUtils.writeByteArrayToFile(new File("C:/ACHBACKUP/" + fileName + ".TXT"), data);

		ChannelSftp sftp = null;

		boolean result = false;
		ByteArrayInputStream is = new ByteArrayInputStream(data);

		try {
			sftp = SFTPUtils.connect(server, port, user_put, password_put, WORDKING_DIR);

			sftp.put(is, fileName + ".tmp");

			result = true;
			System.out.println("是否上傳成功 =" + result);
			is.close();

			if (!result) {
				System.err.println("上傳失敗");
			}

			try {
				if (result) {
					sftp.rename(fileName + ".tmp", fileName + ".TXT");
				}
			}
			catch (SftpException e) {
				e.printStackTrace();
				System.err.println("rename失敗, fileName:" + fileName);

			}

		}
		catch (JSchException e) {
			System.err.println("SFTP連線失敗");
			e.printStackTrace();
			throw e;
		}
		catch (SftpException e) {
			e.printStackTrace();
			throw e;
		}
		catch (IOException e) {
			e.printStackTrace();
			throw e;
		}
		finally {
			try {
				is.close();
				SFTPUtils.disconnect(sftp);
			}
			catch (JSchException e) {
				System.err.println("SFTP離線失敗");
				e.printStackTrace();
			}
			catch (IOException e) {
				System.err.println("ByteArrayInputStream close failed , fileName:" + fileName);
				e.printStackTrace();
			}
		}
	}

	private static void prepareHeaders(Cactx102ResultN2NFileFormat fileFormat, String flowDocId, Date txDate) {

		Cactx102ResultN2NHeaderFileSection section = new Cactx102ResultN2NHeaderFileSection();
		// 交易使用的分行號碼
		section.setBranchNo(StringUtils.leftPad("00960", 5, "0"));
		// 交易使用的行員號碼
		section.setTellerNo(StringUtils.leftPad("90002535", 8, "0"));
		// 交易使用的端末機號
		section.setTermNo(StringUtils.leftPad("000", 3, "0"));
		// 交易日期
		section.setTxDate(DateUtils.formatDate(txDate, "ddMMyyyy"));
		// 為了與畫面parse一致,讀入資料的secNo由1開始
		section.getFileSection().setSectionNo(1);

		fileFormat.addHeader(section);
	}

	private static void prepareDetails(Cactx102ResultN2NFileFormat fileFormat, String flowDocId) {

		// 第一筆
		Cactx102ResultN2NTxFileSection section = new Cactx102ResultN2NTxFileSection();
		section.setBatchNo(StringUtils.leftPad(flowDocId, 24, "0"));
		section.setSerno(StringUtils.leftPad("00001", 5, "0"));
		section.setPayChanel(StringUtils.rightPad("1", 1, " ")); // 1：自行轉帳 ,
		// 2：跨行匯款
		section.setPayerAccountNo(StringUtils.leftPad("60090100000280", 14, "0"));// 付款人帳號
		section.setPayerName(StringUtils.rightPad("開立聯屬存款有限公司", 76, " "));// 付款人戶名
		section.setPayerUid(StringUtils.rightPad("00021407", 10, " "));// 付款人統編
		section.setReceiveBankCode(StringUtils.leftPad("8090000", 7, "0"));// 收款銀行代號
		section.setRollInAcct(StringUtils.leftPad("60090100000268", 16, "0"));// 轉入帳號
		section.setAmount(StringUtils.leftPad("40000000000000", 17, "0"));// 交易金額
		// 9(14)V9(3)
		section.setPromoCode(StringUtils.rightPad("IZ", 2, " "));// 提示碼
		section.setRemarks(StringUtils.rightPad("remark", 16, " "));// 存摺附註
		section.setCheckId(StringUtils.rightPad("00007030", 10, " "));// 檢核ID
		section.setCheckName(StringUtils.rightPad("", 60, " "));// 檢核戶名
		section.setFee(StringUtils.leftPad("0", 5, "0"));// 櫃員手續費/匯款手續費
		section.setPostScript(StringUtils.rightPad("memo", 76, " "));// 附言
		section.setBancsStat(StringUtils.leftPad("9999", 4, "0"));// BaNCS中心執行結果
		section.setFepResult(StringUtils.rightPad("", 4, " "));// 匯款處理結果
		section.setFepNo(StringUtils.rightPad("       ", 7, " "));// 匯款編號
		section.setJrnlNo(StringUtils.leftPad("000000000", 9, "0"));// 交易序號
		// 為了與畫面parse一致,讀入資料的secNo由1開始
		section.getFileSection().setSectionNo(1);

		fileFormat.addDetails(section);

		// 第二筆
		Cactx102ResultN2NTxFileSection section2 = new Cactx102ResultN2NTxFileSection();
		section2.setBatchNo(StringUtils.leftPad(flowDocId, 24, "0"));
		section2.setSerno(StringUtils.leftPad("00002", 5, "0"));
		section2.setPayChanel(StringUtils.rightPad("2", 1, " ")); // 1：自行轉帳 ,
		// 2：跨行匯款
		section2.setPayerAccountNo(StringUtils.leftPad("60090100000280", 14, "0"));// 付款人帳號
		section2.setPayerName(StringUtils.rightPad("開立聯屬存款有限公司", 76, " "));// 付款人戶名
		section2.setPayerUid(StringUtils.rightPad("00021407", 10, " "));// 付款人統編
		section2.setReceiveBankCode(StringUtils.leftPad("0210018", 7, "0"));// 收款銀行代號
		section2.setRollInAcct(StringUtils.leftPad("00123456789012", 16, "0"));// 轉入帳號
		section2.setAmount(StringUtils.leftPad("3000000", 17, "0"));// 交易金額
		// 9(14)V9(3)
		section2.setPromoCode(StringUtils.rightPad("IZ", 2, " "));// 提示碼
		section2.setRemarks(StringUtils.rightPad("remark2", 16, " "));// 存摺附註
		section2.setCheckId(StringUtils.rightPad("", 10, " "));// 檢核ID
		section2.setCheckName(StringUtils.rightPad("謝美美", 60, " "));// 檢核戶名
		section2.setFee(StringUtils.leftPad("0", 5, "0"));// 櫃員手續費/匯款手續費
		section2.setPostScript(StringUtils.rightPad("memo2", 76, " "));// 附言
		section2.setBancsStat(StringUtils.leftPad("9999", 4, "0"));// BaNCS中心執行結果
		section2.setFepResult(StringUtils.rightPad("", 4, " "));// 匯款處理結果
		section2.setFepNo(StringUtils.rightPad("       ", 7, " "));// 匯款編號
		section2.setJrnlNo(StringUtils.leftPad("000000000", 9, "0"));// 交易序號
		// 為了與畫面parse一致,讀入資料的secNo由1開始
		section2.getFileSection().setSectionNo(1);

		fileFormat.addDetails(section2);

		// 第三筆
		Cactx102ResultN2NTxFileSection section3 = new Cactx102ResultN2NTxFileSection();
		section3.setBatchNo(StringUtils.leftPad(flowDocId, 24, "0"));
		section3.setSerno(StringUtils.leftPad("00003", 5, "0"));
		section3.setPayChanel(StringUtils.rightPad("1", 1, " ")); // 1：自行轉帳 ,
		// 2：跨行匯款
		section3.setPayerAccountNo(StringUtils.leftPad("60000100000000", 14, "0"));// 付款人帳號
		section3.setPayerName(StringUtils.rightPad("開立聯屬存款有限公司", 76, " "));// 付款人戶名
		section3.setPayerUid(StringUtils.rightPad("00021407", 10, " "));// 付款人統編
		section3.setReceiveBankCode(StringUtils.leftPad("8090000", 7, "0"));// 收款銀行代號
		section3.setRollInAcct(StringUtils.leftPad("60090100000268", 16, "0"));// 轉入帳號
		section3.setAmount(StringUtils.leftPad("3000000", 17, "0"));// 交易金額
		// 9(14)V9(3)
		section3.setPromoCode(StringUtils.rightPad("IZ", 2, " "));// 提示碼
		section3.setRemarks(StringUtils.rightPad("remark", 16, " "));// 存摺附註
		section3.setCheckId(StringUtils.rightPad("00007030", 10, " "));// 檢核ID
		section3.setCheckName(StringUtils.rightPad("", 60, " "));// 檢核戶名
		section3.setFee(StringUtils.leftPad("0", 5, "0"));// 櫃員手續費/匯款手續費
		section3.setPostScript(StringUtils.rightPad("memo", 76, " "));// 附言
		section3.setBancsStat(StringUtils.leftPad("9999", 4, "0"));// BaNCS中心執行結果
		section3.setFepResult(StringUtils.rightPad("", 4, " "));// 匯款處理結果
		section3.setFepNo(StringUtils.rightPad("       ", 7, " "));// 匯款編號
		section3.setJrnlNo(StringUtils.leftPad("000000000", 9, "0"));// 交易序號
		// 為了與畫面parse一致,讀入資料的secNo由1開始
		section3.getFileSection().setSectionNo(1);

		fileFormat.addDetails(section3);

	}

	private static void prepareFooters(Cactx102ResultN2NFileFormat fileFormat) {
		Cactx102ResultN2NFooterFileSection section = new Cactx102ResultN2NFooterFileSection();
		// section.setTotalAmt(StringUtils.leftPad("6000000500",17,"0"));
		section.setTotalAmt(StringUtils.leftPad("40000006000000", 17, "0"));
		section.setTotalCount(StringUtils.leftPad("3", 6, "0"));
		section.getFileSection().setSectionNo(1);
		fileFormat.addFooter(section);
	}

	private static void testImportFile(String fileName) throws JSchException, SftpException, IOException, ActionException {

		 byte[] fileContent = FileUtils.readFileToByteArray(new
		 File("C:/ACHBACKUP/0004096004102018201810040010000800375000.TXT"));

//		byte[] fileContent = null;
//		ChannelSftp sftp = null;
//		ByteArrayOutputStream os = new ByteArrayOutputStream();
//		try {
//			sftp = SFTPUtils.connect(server, port, user_get, password_get, "/");
//
//			sftp.get(fileName, os);
//
//			fileContent = os.toByteArray();
//
//			if (fileContent == null) {
//				System.err.println("sftp download file Error, fileName:" + fileName);
//			}
//
//		}
//		catch (JSchException e) {
//			System.err.println("SFTP連線失敗");
//			e.printStackTrace();
//			throw e;
//		}
//		catch (SftpException e) {
//			e.printStackTrace();
//			throw e;
//		}
//		finally {
//			try {
//				os.close();
//				SFTPUtils.disconnect(sftp);
//			}
//			catch (JSchException e) {
//				System.err.println("SFTP離線失敗");
//				e.printStackTrace();
//			}
//			catch (IOException e) {
//				System.err.println("ByteArrayOutputStream close failed , fileName:" + fileName);
//				e.printStackTrace();
//			}
//		}

		
		
		
		Cactx102ResultN2NFileFormat fileFormat = new Cactx102ResultN2NFileFormat("CACTX102");
		boolean result = fileFormat.parseFile(fileContent);

		FileDoc fileDoc = fileFormat.getFileDoc();

		for (FileDetail fileDetail : fileDoc.getDetails()) {
			System.out.println("=================== " + fileDetail.getRowNo() + " ====================");

			// 
			FileSection fileSection = fileDetail.getFirstSection();
			if (fileDetail.getFirstSection().getFieldGroup() == FieldGroup.HEADER) {
				Cactx102ResultN2NHeaderFileSection header = new Cactx102ResultN2NHeaderFileSection(fileSection);
				System.out.println("getBranchNo:" + header.getBranchNo());

			}
			else if (fileDetail.getFirstSection().getFieldGroup() == FieldGroup.FOOTER) {
				Cactx102ResultN2NFooterFileSection footer = new Cactx102ResultN2NFooterFileSection(fileSection);
				System.out.println("getTotalCount:" + footer.getTotalCount());
				System.out.println("getTotalAmt:" + footer.getTotalAmt());

			}
			else {
				Cactx102ResultN2NTxFileSection detail = new Cactx102ResultN2NTxFileSection(fileSection);
				System.out.println("getBatchNo:" + detail.getBatchNo());
				System.out.println("getSerno:" + detail.getSerno());
				System.out.println("getPayChanel:" + detail.getPayChanel());
				System.out.println("getPayerAccountNo:" + detail.getPayerAccountNo());
				System.out.println("getPayerName:" + detail.getPayerName());
				System.out.println("getPayerUid:" + detail.getPayerUid());
				System.out.println("getReceiveBankCode:" + detail.getReceiveBankCode());
				System.out.println("getTxAmt:" + detail.getAmount());
				System.out.println("getRemarks:" + detail.getRemarks());
				System.out.println("getJournalNo:" + detail.getJrnlNo());
				System.out.println("getBancsStat:" + detail.getBancsStat());
				System.out.println("getFepResult:" + detail.getFepResult());
			}

		}

		System.out.println("result:" + result);
	}

	/*
	 * 來源檔檔案名稱：9999(流程識別碼)+9999(主辦分行代碼)+交易日期(西元年DDMMYYYY)+999999999999999999999999
	 * (批號).TXT
	 */
	private static String getFileName(Date txDate, String batchNo) {

		return WORDKING_DIR + "0960" + DateUtils.formatDate(txDate, "ddMMyyyy") + StringUtils.leftPad(batchNo, 24, "0");
	}

	public static String generateCaseNo() throws DatabaseException {
		String value = "";
		IB2CSequenceDao dao = (IB2CSequenceDao) AOPProxyFactory.getDao(IB2CSequenceDao.class, B2CSequenceDao.class);
		String caseNoSeq = StringUtils.leftPad(String.valueOf(dao.getCaseNoSeq() % 10000000), 7, "0");
		value = DateUtils.getSimpleISODateStr(new Date()).substring(2) + caseNoSeq;
		return value;
	}

	/** 系統參數代碼表 */
	private static Map<SystemParamEntityPk, String> systemParamMap = null;

	/**
	 * 載入系統參數
	 */
	synchronized private static void loadSystemParamMap() {

		if (systemParamMap != null) {
			return;
		}

		systemParamMap = new Hashtable<SystemParamEntityPk, String>();

		ISystemParamDao dao = CosmosDaoFactory.getSystemParamDao();

		try {

			// System.err.println("loadSystemParamMap");

			List<SystemParamEntity> entities = dao.findAll();

			for (SystemParamEntity entity : entities) {

				SystemParamEntityPk pk = new SystemParamEntityPk(entity.getCategory(), entity.getKey());

				String value = StringUtils.trimToEmpty(entity.getValue());

				// 加入密碼 DECRYPT 的功能
				if (1 == entity.getPasswordFlag()) {
					value = DESUtils.decrypt(value);
				}

				systemParamMap.put(pk, value);

			}
		}
		catch (DatabaseException e) {
			throw new RuntimeException("cannot load SystemParam ", e);
		}
		catch (CryptException e) {
			throw new RuntimeException("cannot load SystemParam ", e);
		}

	}

	public static Map<SystemParamEntityPk, String> getSystemParamMap() {

		if (null == systemParamMap) {
			loadSystemParamMap();
		}
		return systemParamMap;
	}

	/**
	 * 取得參數值
	 * 
	 * @param param
	 * @return
	 */
	public static String getSystemParamValue(ISystemParam param) {

		SystemParamEntityPk pk = new SystemParamEntityPk(param.getCategory().getCode(), param.getKey());

		return getSystemParamMap().get(pk);
	}
}
