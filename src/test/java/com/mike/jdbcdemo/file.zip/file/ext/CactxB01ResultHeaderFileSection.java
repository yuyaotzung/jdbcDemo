/*
 * ===========================================================================
 * IBM Confidential
 * AIS Source Materials
 *
 *
 * (C) Copyright IBM Corp. 2011.
 *
 * ===========================================================================
 */
package com.cosmos.file.ext;

import com.cosmos.file.bo.FileField;
import com.cosmos.file.bo.FileSection;
import com.cosmos.file.def.CactxB01ResultHeaderFileDefinition;
import com.cosmos.file.def.IFileDefinition;
import com.cosmos.type.FieldGroup;
import com.ibm.tw.commons.util.StringUtils;

/**
 * <p>
 * FISC整批代收格式(首錄)
 * </p>
 * 
 * @author Hank
 * @version 1.0, 2016/106
 * @see
 * @since
 */
public class CactxB01ResultHeaderFileSection {

	/** 檔案區段 */
	private FileSection fileSection;

	public CactxB01ResultHeaderFileSection() {

		fileSection = new FileSection();
		fileSection.setFieldGroup(FieldGroup.HEADER);
	}

	public CactxB01ResultHeaderFileSection(FileSection fileSection) {
		this.fileSection = fileSection;
	}

	public FileSection getFileSection() {
		return fileSection;
	}

	// 區別碼
	public String getSecNo() {
		return getValue(CactxB01ResultHeaderFileDefinition.SECNO);
	}

	public void setSecNo(String value) {
		setValue(CactxB01ResultHeaderFileDefinition.SECNO, value);
	}

	// 委託單位
	public String getPunit() {
		return getValue(CactxB01ResultHeaderFileDefinition.PUNIT);
	}

	public void setPunit(String value) {
		setValue(CactxB01ResultHeaderFileDefinition.PUNIT, value);
	}

	// 收件單位
	public String getRunit() {
		return getValue(CactxB01ResultHeaderFileDefinition.RUNIT);
	}

	public void setRunit(String value) {
		setValue(CactxB01ResultHeaderFileDefinition.RUNIT, value);
	}

	// 交易日期
	public String getTxDate() {
		return getValue(CactxB01ResultHeaderFileDefinition.TXDATE);
	}

	public void setTxDate(String value) {
		setValue(CactxB01ResultHeaderFileDefinition.TXDATE, value);
	}

	// 費用類別
	public String getPaymentType() {
		return getValue(CactxB01ResultHeaderFileDefinition.PAYMENTTYPE);
	}

	public void setPaymentType(String value) {
		setValue(CactxB01ResultHeaderFileDefinition.PAYMENTTYPE, value);
	}

	// 性質別
	public String getType() {
		return getValue(CactxB01ResultHeaderFileDefinition.TYPE);
	}

	public void setType(String value) {
		setValue(CactxB01ResultHeaderFileDefinition.TYPE, value);
	}

	// 檔案批號
	public String getBatchNo() {
		return getValue(CactxB01ResultHeaderFileDefinition.BATCHNO);
	}

	public void setBatchNo(String value) {
		setValue(CactxB01ResultHeaderFileDefinition.BATCHNO, value);
	}

	// 保留欄
	public String getFiller() {
		return getValue(CactxB01ResultHeaderFileDefinition.FILLER);
	}

	public void setFiller(String value) {
		setValue(CactxB01ResultHeaderFileDefinition.FILLER, value);
	}

	// ========================================================
	// 以下可共用

	/**
	 * 
	 * @param fileDefinition
	 * @return
	 */
	private String getValue(IFileDefinition fileDefinition) {
		FileField fileField = fileSection.getField(fileDefinition.getId());
		if (fileField == null) {
			return null;
		}
		else {
			return StringUtils.trim(fileField.getValue());
		}
	}

	/**
	 * 
	 * @param fileDefinition
	 * @param value
	 */
	private void setValue(IFileDefinition fileDefinition, String value) {

		if (fileSection == null) {
			fileSection = new FileSection();
		}

		FileField field = fileSection.getField(fileDefinition.getId());
		if (field == null) {
			field = new FileField();
			field.setFieldId(fileDefinition.getId());
			field.setValue(value);
			fileSection.addField(field);
		}
		else {
			field.setValue(value);
		}
	}

}
