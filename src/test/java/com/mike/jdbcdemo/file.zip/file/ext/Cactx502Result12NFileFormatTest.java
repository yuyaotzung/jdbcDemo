/*
 * ===========================================================================
 * IBM Confidential
 * AIS Source Materials
 * 
 * 
 * (C) Copyright IBM Corp. 2018.
 *
 * ===========================================================================
 */
package com.cosmos.file.ext;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.util.Date;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;

import org.apache.commons.io.FileUtils;

import com.cosmos.file.bo.FileDetail;
import com.cosmos.file.bo.FileDoc;
import com.cosmos.file.bo.FileSection;
import com.cosmos.param.ISystemParam;
import com.cosmos.param.ext.CibParam;
import com.cosmos.persistence.CosmosDaoFactory;
import com.cosmos.persistence.b2c.dao.B2CSequenceDao;
import com.cosmos.persistence.b2c.dao.IB2CSequenceDao;
import com.cosmos.persistence.b2c.dao.ISystemParamDao;
import com.cosmos.persistence.b2c.entity.SystemParamEntity;
import com.cosmos.persistence.b2c.entity.pk.SystemParamEntityPk;
import com.cosmos.type.FieldGroup;
import com.cosmos.util.SFTPUtils;
import com.ibm.tw.commons.aop.AOPProxyFactory;
import com.ibm.tw.commons.exception.ActionException;
import com.ibm.tw.commons.exception.CryptException;
import com.ibm.tw.commons.persistence.exception.DatabaseException;
import com.ibm.tw.commons.util.ConvertUtils;
import com.ibm.tw.commons.util.DESUtils;
import com.ibm.tw.commons.util.StringUtils;
import com.ibm.tw.commons.util.time.DateUtils;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.SftpException;

/**
 * <p>
 * 外幣整批一扣多入
 * </p>
 * 
 * @author Bear
 * @version 1.0, 2018/7/12
 * @see
 * @since
 */
public class Cactx502Result12NFileFormatTest {

	// 一扣多入資料夾
	private static final String WORDKING_DIR = "0027";

	// Server
	static String server;

	// Port
	static int port;

	// 帳號
	static String user_put;

	// 密碼
	static String password_put;

	// 帳號
	static String user_get;

	// 密碼
	static String password_get;

	public static void main(String[] args) throws Throwable {

		init();

		// 產出檔案請使用Cactx50212NMain
		// testExportFile();

		String fileName = "0027001420082018201808200010000793754000.TMP";
		testImportFile(fileName);

	}

	private static void init() {
		// Server
		server = getSystemParamValue(CibParam.FCS_SFTP_SERVER);
		// Port
		port = ConvertUtils.str2Int(getSystemParamValue(CibParam.FCS_SFTP_PORT));
		// 帳號
		user_put = getSystemParamValue(CibParam.FCS_SFTP_USER_PUT);
		// 密碼
		password_put = getSystemParamValue(CibParam.FCS_SFTP_PASSWORD_PUT);
		// 帳號
		user_get = getSystemParamValue(CibParam.FCS_SFTP_USER_GET);
		// 密碼
		password_get = getSystemParamValue(CibParam.FCS_SFTP_PASSWORD_GET);

	}

	private static void testExportFile() throws JSchException, SftpException, IOException, DatabaseException, ActionException {
		Cactx502Result12NFileFormat fileFormat = new Cactx502Result12NFileFormat("CACTX502");

		// 案件序號
		String flowDocId = generateCaseNo();

		// 交易日期
		Date txDate = new Date();

		prepareHeaders(fileFormat, flowDocId, txDate);
		prepareDetails(fileFormat, flowDocId);
		prepareFooters(fileFormat);
		byte[] data = new byte[0];

		data = fileFormat.toFile();

		String fileName = getFileName(txDate, flowDocId);

		System.out.println("fileName:" + fileName);

		// TODO 備份路徑??
		// 備份檔案
		FileUtils.writeByteArrayToFile(new File("C:/ACHBACKUP/" + fileName + ".TXT"), data);

		ChannelSftp sftp = null;

		boolean result = false;
		ByteArrayInputStream is = new ByteArrayInputStream(data);

		try {
			sftp = SFTPUtils.connect(server, port, user_put, password_put, WORDKING_DIR);

			sftp.put(is, fileName + ".tmp");

			result = true;
			System.out.println("是否上傳成功 =" + result);
			is.close();

			if (!result) {
				System.err.println("上傳失敗");
			}

			try {
				if (result) {
					sftp.rename(fileName + ".tmp", fileName + ".TXT");
				}
			}
			catch (SftpException e) {
				e.printStackTrace();
				System.err.println("rename失敗, fileName:" + fileName);

			}

		}
		catch (JSchException e) {
			System.err.println("SFTP連線失敗");
			e.printStackTrace();
			throw e;
		}
		catch (SftpException e) {
			e.printStackTrace();
			throw e;
		}
		catch (IOException e) {
			e.printStackTrace();
			throw e;
		}
		finally {
			try {
				is.close();
				SFTPUtils.disconnect(sftp);
			}
			catch (JSchException e) {
				System.err.println("SFTP離線失敗");
				e.printStackTrace();
			}
			catch (IOException e) {
				System.err.println("ByteArrayInputStream close failed , fileName:" + fileName);
				e.printStackTrace();
			}
		}
	}

	private static void prepareHeaders(Cactx502Result12NFileFormat fileFormat, String flowDocId, Date txDate) {

		Cactx502Result12NHeaderFileSection section = new Cactx502Result12NHeaderFileSection();
		// 交易使用的分行號碼
		// TRANS_BRANCH
		section.setBranchNo(StringUtils.leftPad("0001", 5, "0"));
		// 交易使用的行員號碼
		section.setTellerNo(StringUtils.leftPad("90002535", 8, "0"));
		// 交易使用的端末機號
		section.setTermNo(StringUtils.leftPad("999", 3, "0"));
		// 交易日期
		section.setTxDate(DateUtils.formatDate(txDate, "ddMMyyyy"));
		// 為了與畫面parse一致,讀入資料的secNo由1開始
		section.getFileSection().setSectionNo(1);
		section.setPayAcct(StringUtils.leftPad("60010100008208", 14, "0"));// 付款人帳號
		section.setPayAcctCurrcode("USD");// 付款帳號幣別
		section.setPayName(StringUtils.rightPad("開立聯屬存款有限公司", 76, " "));// 付款人戶名

		section.setRateType1(StringUtils.rightPad("00021407", 10, " "));// 轉出匯率類型

		fileFormat.addHeader(section);

	}

	private static void prepareDetails(Cactx502Result12NFileFormat fileFormat, String flowDocId) {
		// 第一筆
		Cactx502Result12NTxFileSection section = new Cactx502Result12NTxFileSection();
		section.setPbmtBatchNo(StringUtils.leftPad(flowDocId, 24, "0"));// 批號PBMT-BATCH-NO
		section.setPbmtSerno(StringUtils.leftPad("00001", 5, "0"));// 流水號
		section.setPayChanel(StringUtils.rightPad("1", 1, " ")); // 1：自行轉帳,2：跨行匯款

		section.setReceiveBankCode(StringUtils.leftPad("8100364", 7, "0"));// 收款銀行代號
		section.setRollInAcct(StringUtils.leftPad("60090100000268", 16, "0"));// 轉入帳號
		section.setRollInAcctCurrcode(StringUtils.leftPad("USD", 3, "0"));// 轉入帳號幣別
		section.setAmount(StringUtils.leftPad("1000000", 17, "0"));// 交易金額=1000
		section.setPromoCode(StringUtils.rightPad("00", 2, " "));// 提示碼? TODO
		section.setRemarks(StringUtils.rightPad("remarks", 16, " "));// 存摺附註??
		// section.setCheckId(StringUtils.rightPad("", 10, " "));// 檢核ID
		// section.setCheckName(StringUtils.rightPad("", 60, " "));// 檢核戶名
		section.setFee(StringUtils.leftPad("00500", 5, "0"));// 櫃員手續費/匯款手續費
		section.setCBRClass1(StringUtils.rightPad("A", 3, " "));// "匯款分類一1
		section.setSourceOfFundSub(StringUtils.rightPad("A", 1, " "));// 匯款分類細項
		section.setCBRSubCode1(StringUtils.rightPad("A", 1, " "));// 匯款分類69x細分類
		section.setCBRREQ1(StringUtils.rightPad("A", 1, " "));// 申報註記1
		section.setCBRTxnType1(StringUtils.rightPad("Z", 1, " "));// 交易類型1
		section.setCBRCountry2(StringUtils.rightPad("01", 2, " "));// 匯款地國別2
		section.setCBRREQ2(StringUtils.rightPad("01", 1, " "));// 申報註記2
		section.setPostScript(StringUtils.rightPad("memo", 76, " "));// 附言
		section.setBancsStat(StringUtils.rightPad("9999", 4, " "));// BaNCS中心執行結果
		// section.setFrn56uResult(StringUtils.rightPad("9999", 4, " "));//
		// 匯款處理結果(他行)
		section.setNefxStat("");
		section.setEsbStat("");
		section.setTxntNo(StringUtils.rightPad("0000001", 7, " "));// 交易編號
		section.setJrnlNo(StringUtils.rightPad("000000000", 9, " "));// 交易序號
		section.setPayeeBankName(StringUtils.rightPad("凱基銀行", 70, " "));// 受款銀行名稱
		section.setPayeeBankName(StringUtils.rightPad("受款銀行地址...", 70, " "));// 受款銀行地址
		section.setCommission(StringUtils.leftPad("1000", 14, "0"));// 手續費扣款幣金額
		section.setCommissionBcu(StringUtils.leftPad("1000", 14, "0"));// 手續費本位幣金額
		section.setPostage(StringUtils.leftPad("1000", 14, "0"));// 郵電費扣款幣金額
		section.setPostageBcu(StringUtils.leftPad("1000", 14, "0"));// 郵電費本位幣金額
		section.setTotChg(StringUtils.leftPad("1000", 14, "0"));// 費用總金額
		section.setTotPayAmt(StringUtils.leftPad("1000", 16, "0"));// 總扣款金額
		section.setEquUsdAmt(StringUtils.leftPad("33", 16, "0"));// 等值美金金額
		section.setEquTwdAmt(StringUtils.leftPad("1000", 16, "0"));// 等值台幣金額
		section.setPayeeEmail(StringUtils.rightPad("email@com.tw", 200, " "));// 收款人Email
		section.setPayeeAddr(StringUtils.rightPad("受款人地址", 70, " "));// 受款人地址
		section.setPayeeTel(StringUtils.rightPad("1234567", 35, " "));// 受款人電話
		section.setCnaps(StringUtils.rightPad("1234567", 14, " "));// 大陸現代化支付系統帳號
		section.setPaymentDetails(StringUtils.rightPad("附言", 140, " "));// 附言
		section.setCbTradeType(StringUtils.rightPad("A", 1, " "));// 外匯性質
		section.setOppoKind(StringUtils.rightPad("A", 1, " "));// 受款人身份別
		section.setPayeeBankSwift(StringUtils.rightPad("SWIFT", 11, " "));// 受款銀行SWIFT
		section.setPayeeBankAcno(StringUtils.rightPad("", 34, " "));// 受款銀行清算代碼
		section.setIntrBankSwift(StringUtils.rightPad("SWIFT", 11, " "));// 中間銀行SWIFT
		section.setDeductFeeFlag(StringUtils.rightPad("Y", 1, " "));// 內扣外繳
		section.setApplicationId(StringUtils.rightPad("A", 4, " "));// 發動端平台代號
		section.setCustName(StringUtils.rightPad("english name", 70, " "));// 客戶英文名稱
		section.setCustAddr(StringUtils.rightPad("english addr", 70, " "));// 客戶英文地址
		section.setTxntType(StringUtils.rightPad("1", 1, " "));// 交易類型
		section.setBsnUnit(StringUtils.rightPad("000", 4, " "));// 客戶所屬分行別
		section.setValidDate(StringUtils.rightPad("20180713", 8, " "));// 交易生效日
		section.setRemitCcy(StringUtils.rightPad("USD", 3, " "));// 匯款幣別
		section.setPayCcy(StringUtils.rightPad("USD", 3, " "));// 付款幣別
		section.setExCntrno(StringUtils.rightPad("00000123", 16, " "));// 議價編號
		section.setExrate(StringUtils.leftPad("1", 13, "0"));// 成交匯率
		section.setSpreadBSpot(StringUtils.leftPad("1", 13, "0"));// 買匯匯率優惠
		section.setSpreadSSpot(StringUtils.leftPad("1", 13, "0"));// 賣匯匯率優惠
		section.setSourceOfFund(StringUtils.rightPad("1", 3, " "));// 匯款分類
		section.setFullPayment(StringUtils.rightPad("Y", 1, " "));// 匯出匯款方式
		section.setCustTel(StringUtils.rightPad("0911222333", 14, " "));// 客戶聯絡電話
		section.setCustBirthday(StringUtils.rightPad("19830101", 8, " "));// 客戶生日
		section.setCustKindCbMemo(StringUtils.rightPad("01", 2, " "));// 客戶身份別
		section.setRsdntIssueDate(StringUtils.rightPad("01", 8, " "));// 居留證核發日期
		section.setRsdntValidDate(StringUtils.rightPad("01", 8, " "));// 居留證有效期限
		// 為了與畫面parse一致,讀入資料的secNo由1開始
		section.getFileSection().setSectionNo(1);

		fileFormat.addDetails(section);

	}

	private static void prepareFooters(Cactx502Result12NFileFormat fileFormat) {
		Cactx502Result12NFooterFileSection section = new Cactx502Result12NFooterFileSection();
		section.setTotalAmt(StringUtils.leftPad("10000000", 17, "0"));
		section.setTotalCount(StringUtils.leftPad("3", 6, "0"));
		section.getFileSection().setSectionNo(1);
		fileFormat.addFooter(section);
	}

	private static void testImportFile(String fileName) throws JSchException, SftpException, IOException, ActionException {

		// byte[] fileContent = FileUtils.readFileToByteArray(new
		// File("C:/ACHBACKUP/"+fileName));

		byte[] fileContent = null;
		ChannelSftp sftp = null;
		ByteArrayOutputStream os = new ByteArrayOutputStream();
		try {
			sftp = SFTPUtils.connect(server, port, user_get, password_get, "/");

			sftp.get(fileName, os);

			fileContent = os.toByteArray();

			if (fileContent == null) {
				System.err.println("sftp download file Error, fileName:" + fileName);
			}

		}
		catch (JSchException e) {
			System.err.println("SFTP連線失敗");
			e.printStackTrace();
			throw e;
		}
		catch (SftpException e) {
			e.printStackTrace();
			throw e;
		}
		finally {
			try {
				os.close();
				SFTPUtils.disconnect(sftp);
			}
			catch (JSchException e) {
				System.err.println("SFTP離線失敗");
				e.printStackTrace();
			}
			catch (IOException e) {
				System.err.println("ByteArrayOutputStream close failed , fileName:" + fileName);
				e.printStackTrace();
			}
		}

		Cactx502Result12NFileFormat fileFormat = new Cactx502Result12NFileFormat("CACTX502");
		boolean result = fileFormat.parseFile(fileContent);

		System.out.println("result:" + result);

		FileDoc fileDoc = fileFormat.getFileDoc();

		for (FileDetail fileDetail : fileDoc.getDetails()) {
			System.out.println("=================== " + fileDetail.getRowNo() + " ====================");

			FileSection fileSection = fileDetail.getFirstSection();
			if (fileDetail.getFirstSection().getFieldGroup() == FieldGroup.HEADER) {
				Cactx502Result12NHeaderFileSection header = new Cactx502Result12NHeaderFileSection(fileSection);
				System.out.println("==========Header==========");
				System.out.println("getBranchNo:" + header.getBranchNo());
				System.out.println("getPayerAccountNo:" + header.getPayAcct());
				System.out.println("getPayerName:" + header.getPayName());

			}
			else if (fileDetail.getFirstSection().getFieldGroup() == FieldGroup.FOOTER) {
				Cactx502Result12NFooterFileSection footer = new Cactx502Result12NFooterFileSection(fileSection);
				System.out.println("==========Footer==========");
				System.out.println("getTotalCount:" + footer.getTotalCount());
				System.out.println("getTotalAmt:" + footer.getTotalAmt());

			}
			else {
				Cactx502Result12NTxFileSection detail = new Cactx502Result12NTxFileSection(fileSection);
				System.out.println("==========Tx==========");
				System.out.println("getBatchNo:" + detail.getPbmtBatchNo());
				System.out.println("getSerno:" + detail.getPbmtSerno());
				System.out.println("getPayChanel:" + detail.getPayChanel());

				System.out.println("getReceiveBankCode:" + detail.getReceiveBankCode());
				System.out.println("getTxAmt:" + detail.getAmount());
				System.out.println("getRemarks:" + detail.getRemarks());
				System.out.println("BaNCS中心執行結果getBancsStat:" + detail.getBancsStat());
				System.out.println("getNefxStat:" + detail.getNefxStat());
				System.out.println("getEsbStat:" + detail.getEsbStat());
				System.out.println("交易序號getJournalNo:" + detail.getJrnlNo());
				System.out.println("getTxntNo:" + detail.getTxntNo());
				System.out.println("getEquTwdAmt:" + detail.getEquTwdAmt());
				System.out.println("getEquUsdAmt:" + detail.getEquUsdAmt());

				System.out.println("getCommission:" + detail.getCommission());
				System.out.println("getCommissionBcu:" + detail.getCommissionBcu());
				System.out.println("getPostage:" + detail.getPostage());
				System.out.println("getPostageBcu:" + detail.getPostageBcu());
				System.out.println("getTotChg:" + detail.getTotChg());
				System.out.println("getTotPayAmt:" + detail.getTotPayAmt());

				System.out.println("getBdSeq:" + detail.getBdSeq());
			}

		}

	}

	/*
	 * 來源檔檔案名稱：9999(流程識別碼)+9999(主辦分行代碼)+交易日期(西元年DDMMYYYY)+999999999999999999999999
	 * (批號).TXT
	 */
	private static String getFileName(Date txDate, String batchNo) {

		return WORDKING_DIR + "0001" + DateUtils.formatDate(txDate, "ddMMyyyy") + StringUtils.leftPad(batchNo, 24, "0");
	}

	public static String generateCaseNo() throws DatabaseException {
		String value = "";
		IB2CSequenceDao dao = (IB2CSequenceDao) AOPProxyFactory.getDao(IB2CSequenceDao.class, B2CSequenceDao.class);
		String caseNoSeq = StringUtils.leftPad(String.valueOf(dao.getCaseNoSeq() % 10000000), 7, "0");
		value = DateUtils.getSimpleISODateStr(new Date()).substring(2) + caseNoSeq;
		return value;
	}

	/** 系統參數代碼表 */
	private static Map<SystemParamEntityPk, String> systemParamMap = null;

	/**
	 * 載入系統參數
	 */
	synchronized private static void loadSystemParamMap() {

		if (systemParamMap != null) {
			return;
		}

		systemParamMap = new Hashtable<SystemParamEntityPk, String>();

		ISystemParamDao dao = CosmosDaoFactory.getSystemParamDao();

		try {

			// System.err.println("loadSystemParamMap");

			List<SystemParamEntity> entities = dao.findAll();

			for (SystemParamEntity entity : entities) {

				SystemParamEntityPk pk = new SystemParamEntityPk(entity.getCategory(), entity.getKey());

				String value = StringUtils.trimToEmpty(entity.getValue());

				// 加入密碼 DECRYPT 的功能
				if (1 == entity.getPasswordFlag()) {
					value = DESUtils.decrypt(value);
				}

				systemParamMap.put(pk, value);

			}
		}
		catch (DatabaseException e) {
			throw new RuntimeException("cannot load SystemParam ", e);
		}
		catch (CryptException e) {
			throw new RuntimeException("cannot load SystemParam ", e);
		}

	}

	public static Map<SystemParamEntityPk, String> getSystemParamMap() {

		if (null == systemParamMap) {
			loadSystemParamMap();
		}
		return systemParamMap;
	}

	/**
	 * 取得參數值
	 * 
	 * @param param
	 * @return
	 */
	public static String getSystemParamValue(ISystemParam param) {

		SystemParamEntityPk pk = new SystemParamEntityPk(param.getCategory().getCode(), param.getKey());

		return getSystemParamMap().get(pk);
	}
}
