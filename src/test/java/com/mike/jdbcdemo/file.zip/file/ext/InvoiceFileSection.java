/*
 * ===========================================================================
 * IBM Confidential
 * AIS Source Materials
 * 
 * 
 * (C) Copyright IBM Corp. 2011.
 *
 * ===========================================================================
 */
package com.cosmos.file.ext;

import com.cosmos.file.bo.FileField;
import com.cosmos.file.bo.FileSection;
import com.ibm.tw.commons.util.StringUtils;

/**
 * <p>
 * Invoice File Section
 * </p>
 * 
 * @author Leo
 * @version 1.0, 2011/6/27
 * @see
 * @since
 */
public class InvoiceFileSection {

	/** 檔案區段 */
	private FileSection fileSection;

	public InvoiceFileSection(FileSection fileSection) {
		this.fileSection = fileSection;
	}

	/**
	 * 發票金額
	 * 
	 * @return
	 */
	public String getInvoiceAmt() {
		FileField fileField = fileSection.getField("invoiceAmt");
		if (fileField == null) {
			return null;
		}
		else {
			return fileField.getValue();
		}
	}

	/**
	 * 發票日期
	 * 
	 * @return
	 */
	public String getInvoiceDate() {
		FileField fileField = fileSection.getField("invoiceDate");
		if (fileField == null) {
			return null;
		}
		else {
			return fileField.getValue();
		}
	}

	/**
	 * 發票號碼
	 * 
	 * @return
	 */
	public String getInvoiceNo() {
		FileField fileField = fileSection.getField("invoiceNo");
		if (fileField == null) {
			return null;
		}
		else {
			return StringUtils.trim(fileField.getValue());
		}
	}

	/**
	 * 備註
	 * 
	 * @return
	 */
	public String getInvoiceRemark() {
		FileField fileField = fileSection.getField("invoiceRemark");
		if (fileField == null) {
			return null;
		}
		else {
			return StringUtils.trim(fileField.getValue());
		}
	}
}
