/*
 * ===========================================================================
 * IBM Confidential
 * AIS Source Materials
 * 
 * 
 * (C) Copyright IBM Corp. 2011.
 *
 * ===========================================================================
 */
package com.cosmos.file.ext;

import com.cosmos.file.bo.FileField;
import com.cosmos.file.bo.FileSection;
import com.cosmos.type.FieldGroup;
import com.ibm.tw.commons.util.StringUtils;

/**
 * <p>
 * 外幣自行授權扣帳檔案上傳檔案 明細資料
 * </p>
 * 
 * @author BearChen
 * @version 1.0, 2011/6/27
 * @see
 * @since
 */
public class SfFileSection {

	/** 檔案區段 */
	private FileSection fileSection;

	public SfFileSection(FileSection fileSection) {
		this.fileSection = fileSection;
	}

	public SfFileSection(FieldGroup fieldGroup) {
		fileSection = new FileSection();
		fileSection.setFieldGroup(fieldGroup);
	}

	/**
	 * 自定義序號
	 * 
	 * @return
	 */
	public String getUploadSN() {
		FileField fileField = fileSection.getField("uploadSN");
		if (fileField == null) {
			return null;
		}
		else {
			return StringUtils.trim(fileField.getValue()).toUpperCase();
		}
	}

	/**
	 * 設定自定義序號
	 * 
	 * @param value
	 */
	public void setUploadSN(String value) {
		setValue("uploadSN", value);
	}

	/**
	 * 發動者統編
	 * 
	 * @return
	 */
	public String getPayeeUid() {
		FileField fileField = fileSection.getField("payeeUid");
		if (fileField == null) {
			return null;
		}
		else {
			return StringUtils.trim(fileField.getValue());
		}
	}

	/**
	 * 設定發動者統編
	 * 
	 * @param value
	 */
	public void setPayeeUid(String value) {
		setValue("payeeUid", value);
	}

	/**
	 * 交易日期
	 * 
	 * @return
	 */
	public String getTxDate() {
		FileField fileField = fileSection.getField("txDate");
		if (fileField == null) {
			return null;
		}
		else {
			return fileField.getValue();
		}
	}

	/**
	 * 設定交易日期
	 * 
	 * @param value
	 */
	public void setTxDate(String value) {
		setValue("txDate", value);
	}

	/**
	 * 交易金額
	 * 
	 * @return
	 */
	public String getTxAmt() {
		FileField fileField = fileSection.getField("txAmt");
		if (fileField == null) {
			return null;
		}
		else {
			return fileField.getValue();
		}
	}

	/**
	 * 設定交易金額
	 * 
	 * @param value
	 */
	public void setTxAmt(String value) {
		setValue("txAmt", value);
	}

	/**
	 * 交易金額幣別
	 * 
	 * @return
	 */
	public String getTxCcy() {
		FileField fileField = fileSection.getField("txCcy");
		if (fileField == null) {
			return null;
		}
		else {
			return fileField.getValue();
		}
	}

	/**
	 * 設定交易金額幣別
	 * 
	 * @param value
	 */
	public void setTxCcy(String value) {
		setValue("txCcy", value);
	}

	/**
	 * 扣帳客戶之統編
	 * 
	 * @return
	 */
	public String getPayerUid() {
		FileField fileField = fileSection.getField("payerUid");
		if (fileField == null) {
			return null;
		}
		else {
			return StringUtils.trim(fileField.getValue());
		}
	}

	/**
	 * 設定扣帳客戶之統編
	 * 
	 * @param value
	 */
	public void setPayerUid(String value) {
		setValue("payerUid", value);
	}

	/**
	 * 扣帳帳號
	 * 
	 * @return
	 */
	public String getPayerAccount() {
		FileField fileField = fileSection.getField("payerAccount");
		if (fileField == null) {
			return null;
		}
		else {

			String payerAccount = StringUtils.trim(fileField.getValue());

			if (StringUtils.length(payerAccount) == 16) {

				payerAccount = StringUtils.substring(payerAccount, 2, 16);

			}

			if (StringUtils.length(payerAccount) == 12) {

				payerAccount = StringUtils.leftPad(payerAccount, 14, "0");

			}

			return payerAccount;
		}
	}

	/**
	 * 設定扣帳帳號
	 * 
	 * @param value
	 */
	public void setPayerAccount(String value) {
		setValue("payerAccount", value);
	}

	/**
	 * 交易類別代號
	 * 
	 * @return
	 */
	public String getTransType() {
		FileField fileField = fileSection.getField("transType");
		if (fileField == null) {
			return null;
		}
		else {
			return StringUtils.trim(fileField.getValue());
		}
	}

	/**
	 * 設定交易類別代號
	 * 
	 * @param value
	 */
	public void setTransType(String value) {
		setValue("transType", value);
	}

	/**
	 * 產品代號
	 * 
	 * @return
	 */
	public String getProdType() {
		FileField fileField = fileSection.getField("prodType");
		if (fileField == null) {
			return null;
		}
		else {
			return StringUtils.trim(fileField.getValue());
		}
	}

	/**
	 * 設定產品代號
	 * 
	 * @param value
	 */
	public void setProdType(String value) {
		setValue("prodType", value);
	}

	/**
	 *保留欄
	 * 
	 * @return
	 */
	public String getRemark() {
		FileField fileField = fileSection.getField("remark");
		if (fileField == null) {
			return null;
		}
		else {
			return StringUtils.trim(fileField.getValue());
		}
	}

	/**
	 * 保留欄
	 * 
	 * @param value
	 */
	public void setRemark(String value) {
		setValue("remark", value);
	}

	/**
	 * 入帳摘要說明代號
	 * 
	 * @return
	 */
	public String getPayeeMemo() {
		FileField fileField = fileSection.getField("payeeMemo");
		if (fileField == null) {
			return null;
		}
		else {
			return StringUtils.trim(fileField.getValue());
		}
	}

	/**
	 * 設定入帳摘要說明代號
	 * 
	 * @param value
	 */
	public void setPayeeMemo(String value) {
		setValue("payeeMemo", value);
	}

	/**
	 * 入帳摘要說明
	 * 
	 * @return
	 */
	public String getPayeeDesc() {
		FileField fileField = fileSection.getField("payeeDesc");
		if (fileField == null) {
			return null;
		}
		else {
			return StringUtils.trim(fileField.getValue());
		}
	}

	/**
	 * 設定入帳摘要說明
	 * 
	 * @param value
	 */
	public void setPayeeDesc(String value) {
		setValue("payeeDesc", value);
	}

	/**
	 * 扣帳摘要說明代號
	 * 
	 * @return
	 */
	public String getPayerMemo() {
		FileField fileField = fileSection.getField("payerMemo");
		if (fileField == null) {
			return null;
		}
		else {
			return StringUtils.trim(fileField.getValue());
		}
	}

	/**
	 * 設定扣帳摘要說明代號
	 * 
	 * @param value
	 */
	public void setPayerMemo(String value) {
		setValue("payerMemo", value);
	}

	/**
	 * 扣帳摘要說明
	 * 
	 * @return
	 */
	public String getPayerDesc() {
		FileField fileField = fileSection.getField("payerDesc");
		if (fileField == null) {
			return null;
		}
		else {
			return StringUtils.trim(fileField.getValue());
		}
	}

	/**
	 * 設定扣帳摘要說明
	 * 
	 * @param value
	 */
	public void setPayerDesc(String value) {
		setValue("payerDesc", value);
	}

	/**
	 * 發動者公司交易參考編號
	 * 
	 * @return
	 */
	public String getRefNo() {
		FileField fileField = fileSection.getField("refNo");
		if (fileField == null) {
			return null;
		}
		else {
			return StringUtils.trim(fileField.getValue());
		}
	}

	/**
	 * 設定發動者公司交易參考編號
	 * 
	 * @param value
	 */
	public void setRefNo(String value) {
		setValue("refNo", value);
	}

	/**
	 * 結果欄
	 * 
	 * @return
	 */
	public String getResult() {
		FileField fileField = fileSection.getField("result");
		if (fileField == null) {
			return null;
		}
		else {
			return StringUtils.trim(fileField.getValue());
		}
	}

	/**
	 * 設定結果欄
	 * 
	 * @param value
	 */
	public void setResult(String value) {
		setValue("result", value);
	}

	/**
	 * 結果欄
	 * 
	 * @return
	 */
	public String getResultCode() {
		FileField fileField = fileSection.getField("resultCode");
		if (fileField == null) {
			return null;
		}
		else {
			return StringUtils.trim(fileField.getValue());
		}
	}

	/**
	 * 設定結果欄
	 * 
	 * @param value
	 */
	public void setResultCode(String value) {
		setValue("resultCode", value);
	}

	public FileSection getFileSection() {
		return fileSection;
	}

	/**
	 * 發動者帳號
	 * 
	 * @return
	 */
	public String getPayeeAccount() {
		FileField fileField = fileSection.getField("payeeAccount");
		if (fileField == null) {
			return null;
		}
		else {
			String payeeAccount = StringUtils.trim(fileField.getValue());

			if (StringUtils.length(payeeAccount) == 16) {

				payeeAccount = StringUtils.substring(payeeAccount, 2, 16);

			}

			if (StringUtils.length(payeeAccount) == 12) {

				payeeAccount = StringUtils.leftPad(payeeAccount, 14, "0");

			}

			return payeeAccount;
		}
	}

	/**
	 * 設定發動者帳號
	 * 
	 * @param value
	 */
	public void setPayeeAccount(String value) {
		setValue("payeeAccount", value);
	}

	/**
	 * 批號
	 * 
	 * @return
	 */
	public String getPayeeNo() {
		FileField fileField = fileSection.getField("payeeNo");
		if (fileField == null) {
			return null;
		}
		else {
			return StringUtils.trim(fileField.getValue());
		}
	}

	/**
	 * 設定批號
	 * 
	 * @param value
	 */
	public void setPayeeNo(String value) {
		setValue("payeeNo", value);
	}

	/**
	 * 批號
	 * 
	 * @return
	 */
	public String getBatchNo() {
		FileField fileField = fileSection.getField("batchNo");
		if (fileField == null) {
			return null;
		}
		else {
			return StringUtils.trim(fileField.getValue());
		}
	}

	/**
	 * 設定批號
	 * 
	 * @param value
	 */
	public void setBatchNo(String value) {
		setValue("batchNo", value);
	}

	/**
	 * 轉帳類別 -扣客戶 +入客戶
	 * 
	 * @return
	 */
	public String getType() {
		FileField fileField = fileSection.getField("type");
		if (fileField == null) {
			return null;
		}
		else {
			String val = StringUtils.trim(fileField.getValue());
			if (StringUtils.equals("1", val)) {
				val = "-";
			}
			else if (StringUtils.equals("2", val)) {
				val = "+";
			}
			return val;
		}
	}

	/**
	 * 設定轉帳類別
	 * 
	 * @param value
	 */
	public void setType(String value) {
		setValue("type", value);
	}

	/**
	 * 
	 * @param fieldId
	 * @param value
	 */
	private void setValue(String fieldId, String value) {

		if (fileSection == null) {
			fileSection = new FileSection();
		}

		FileField field = fileSection.getField(fieldId);
		if (field == null) {
			field = new FileField();
			field.setFieldId(fieldId);
			field.setValue(value);
			fileSection.addField(field);
		}
		else {
			field.setValue(value);
		}
	}

}
