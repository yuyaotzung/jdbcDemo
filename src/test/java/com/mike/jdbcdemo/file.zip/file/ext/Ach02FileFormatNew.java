/*
 * ===========================================================================
 * IBM Confidential
 * AIS Source Materials
 *
 *
 * (C) Copyright IBM Corp. 2011.
 *
 * ===========================================================================
 */
package com.cosmos.file.ext;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;

import com.cosmos.file.FileFormatDetail;
import com.cosmos.file.FileFormatNew;
import com.cosmos.file.bo.FileDetail;
import com.cosmos.file.bo.FileDoc;
import com.cosmos.file.bo.FileSection;
import com.cosmos.persistence.b2c.entity.FileFormatDetailEntity;
import com.cosmos.persistence.b2c.entity.FileFormatFieldEntity;
import com.cosmos.tx.AchDetailDoc;
import com.cosmos.type.AchTxType;
import com.cosmos.type.AchType;
import com.cosmos.type.FieldGroup;
import com.cosmos.type.TaskType;
import com.cosmos.type.TxBatchType;
import com.ibm.tw.commons.exception.ActionException;
import com.ibm.tw.commons.util.ConvertUtils;
import com.ibm.tw.commons.util.time.DateUtils;

/**
 * <p>
 * ACH核印檔案解析
 * </p>
 * 
 * @author KK
 * @version 1.0, 2020/1/30
 * @see
 * @since
 */
public class Ach02FileFormatNew extends FileFormatNew {

	public Ach02FileFormatNew(String taskId) {
		super(0, taskId, TxBatchType.UNKNOWN.getCode());
		detailGroup = loadDetailGroup();
	}

	private final TaskType taskType = TaskType.ACH01;

	/** 明細錄資料 */
	private List<AchDetailDoc> details = new ArrayList<AchDetailDoc>();

	/** 明細錄資料 */

	/**
	 * 載入檔案定義
	 * 
	 * @return
	 */
	private Map<FieldGroup, List<FileFormatDetail>> loadDetailGroup() {
		Map<FieldGroup, List<FileFormatDetail>> detailGroup = new HashMap<FieldGroup, List<FileFormatDetail>>();

		// Header
		FieldGroup fieldGroup = FieldGroup.HEADER;
		detailGroup.put(fieldGroup, toFileFormatDetails(taskType, fieldGroup, Ach02MasterFileSectionNew.values()));

		// Tx
		fieldGroup = FieldGroup.TX;
		detailGroup.put(fieldGroup, toFileFormatDetails(taskType, fieldGroup, Ach02TxFileSectionNew.values()));

		// Footer
		fieldGroup = FieldGroup.FOOTER;
		detailGroup.put(fieldGroup, toFileFormatDetails(taskType, fieldGroup, Ach02FooterFileSectionNew.values()));

		return detailGroup;
	}

	/**
	 * 轉換為FileFormatDetail
	 * 
	 * @param taskType
	 * @param fieldGroup
	 * @param sections
	 * @return
	 */
	private List<FileFormatDetail> toFileFormatDetails(TaskType taskType, FieldGroup fieldGroup, IAchFileDefinition[] sections) {
		List<FileFormatDetail> fileFormatDetails = new ArrayList<FileFormatDetail>();

		int orderNo = 1;
		int startPosition = 0;
		for (IAchFileDefinition section : sections) {
			FileFormatDetail fileFormatDetail = toFileFormatDetail(taskType, fieldGroup, section.getId(), section.getName(), orderNo++, section.getType(), section.getRequired(), section.getLength(), startPosition);
			fileFormatDetails.add(fileFormatDetail);
			startPosition += section.getLength();
		}

		return fileFormatDetails;
	}

	/**
	 * 轉換為FileFormatDetail
	 * 
	 * @param taskType
	 * @param fieldGroup
	 * @param fieldId
	 * @param fieldName
	 * @param orderNo
	 * @param type
	 * @param length
	 * @param startPosition
	 * @return
	 */
	private FileFormatDetail toFileFormatDetail(TaskType taskType, FieldGroup fieldGroup, String fieldId, String fieldName, int orderNo, int type, int required, int length, int startPosition) {
		// detail
		FileFormatDetailEntity detail = new FileFormatDetailEntity();
		detail.setFieldId(fieldId);
		detail.setFieldName(fieldName);
		detail.setOrderNo(orderNo);
		detail.setLength(length);
		detail.setStartPosition(startPosition);
		detail.setEndPosition(startPosition + detail.getLength() - 1);

		// field
		FileFormatFieldEntity field = new FileFormatFieldEntity();
		field.setFieldGroup(fieldGroup.getCode());
		field.setFieldId(fieldId);
		field.setTaskType(taskType.getCode());
		field.setType(type);
		field.setDefaultLength(length);
		field.setRequired(required);

		FileFormatDetail fileFormatDetail = new FileFormatDetail(taskType, detail, field);
		return fileFormatDetail;
	}

	/**
	 * 判斷是否為資料頭一筆
	 * 
	 * @param rowNo
	 * @return
	 */
	@Override
	public FieldGroup getFormatHead(int rowNo) {

		if (rowNo == 1) {
			return FieldGroup.HEADER;
		}
		else if (rowNo == getRows()) {
			return FieldGroup.FOOTER;
		}
		else {
			return FieldGroup.TX;
		}
	}

	@Override
	public FieldGroup getFormatCycle(int rowNo) {
		return null;
	}

	@Override
	public TaskType getTaskType() {
		return taskType;
	}

	@Override
	protected void validateDetailSize(FileDoc fileDoc) throws ActionException {

	}

	@Override
	protected void validateCustom(FileDoc fileDoc) throws ActionException {

	}

	@Override
	protected void validateDetailContent(FileDetail fileDetail) throws ActionException {

	}

	@Override
	protected void putData(FileDoc fileDoc) {

		// 將檔案資料轉為整批多扣多入明細資料 ,i為行號
		logger.info("fileDoc.rows()=" + fileDoc.rows());

		// 同ACH代繳授權扣款提回檔(ACHR02)檔案規格，不包含首尾筆
		// for (int i = 1; i <= fileDoc.rows(); i++) {
		// logger.info("fileDoc.rows()=" + fileDoc.getDetail(i).getRowNo());
		for (int i = 2; i < fileDoc.getDetails().size(); i++) {
			AchDetailDoc detail = new AchDetailDoc();
			putDetail(detail, fileDoc.getDetail(i), i);
			// putHeadData(detail, fileDoc.getFirstDetail());
			details.add(detail);
		}

	}

	/**
	 * 
	 * @param txDetailDoc
	 * @param fileDetail
	 */
	private void putHeadData(AchDetailDoc txDetailDoc, FileDetail fileDetail) {

		putHead(txDetailDoc, fileDetail.getFirstSection());
	}

	/**
	 * 
	 * @param detail
	 * @param header
	 */
	private void putHead(AchDetailDoc detail, FileSection header) {

		String tDateFieldValue = header.getField(Ach02MasterFileSectionNew.TDATE.getId()).getStringValue();

		int iYear = ConvertUtils.str2Int(tDateFieldValue.substring(0, 4)) + 1911;
		int iMonth = ConvertUtils.str2Int(tDateFieldValue.substring(4, 6));
		int iDay = ConvertUtils.str2Int(tDateFieldValue.substring(6));

		Date txDate = DateUtils.getDate(iYear, iMonth, iDay);

		detail.setTxDate(txDate);
		detail.settDate(tDateFieldValue);

		String rorgFieldValue = header.getField(Ach02MasterFileSectionNew.RORG.getId()).getStringValue();
		detail.setP_Rorg(rorgFieldValue);
		
		//String verno = header.getField(Ach02MasterFileSectionNew.VERNO.getId()).getStringValue();
		String verno = "V10";
		detail.setVerno(verno);
		
		// String fillerFieldValue =
		// header.getField(NewAchP01MasterFileSection.FILLER.getId()).getStringValue();
		// detail.setFiller(fillerFieldValue);

	}

	private void putDetail(AchDetailDoc txDetailDoc, FileDetail fileDetail, int i) {

		putDocDetail(txDetailDoc, fileDetail.getFirstSection(), i);

	}

	private void putDocDetail(AchDetailDoc detail, FileSection section, int row) {

		detail.setSn(row);

		// 交易序號
		String seqFieldValue = section.getField(Ach02TxFileSectionNew.SEQ.getId()).getStringValue();
		detail.setSeq(seqFieldValue);

		// 交易代號
		String txIdFieldValue = section.getField(Ach02TxFileSectionNew.TIX.getId()).getStringValue();
		detail.setTxId(txIdFieldValue);

		// 發動者統一編號
		String cIdFieldValue = section.getField(Ach02TxFileSectionNew.CID.getId()).getStringValue();
		detail.setcId(cIdFieldValue);

		// 提回行代號
		String rBankFieldValue = section.getField(Ach02TxFileSectionNew.RBANK.getId()).getStringValue();
		detail.setrBank(rBankFieldValue);

		// 委繳戶帳號
		String rClnoFieldValue = section.getField(Ach02TxFileSectionNew.RCLNO.getId()).getStringValue();
		detail.setrClno(rClnoFieldValue);

		// 委繳戶統一編號
		String pidFieldValue = section.getField(Ach02TxFileSectionNew.RID.getId()).getStringValue();
		detail.setpId(pidFieldValue);

		// 用戶號碼
		String cNoFieldValue = section.getField(Ach02TxFileSectionNew.USERNO.getId()).getStringValue();
		if (StringUtils.isNotBlank(cNoFieldValue)) {
			detail.setcNo(cNoFieldValue);
		}

		// 新增或取消
		String adMarkFieldValue = section.getField(Ach02TxFileSectionNew.ADMARK.getId()).getStringValue();
		if (StringUtils.isNotBlank(adMarkFieldValue)) {
			detail.setAdMark(adMarkFieldValue);
		}

		// 資料製作日期
		String pDateFieldValue = section.getField(Ach02TxFileSectionNew.DATE.getId()).getStringValue();
		if (StringUtils.isNotBlank(pDateFieldValue)) {
			detail.setpDate(pDateFieldValue);
		}

		// 提出行代號
		String pBankFieldValue = section.getField(Ach02TxFileSectionNew.PBANK.getId()).getStringValue();
		if (StringUtils.isNotBlank(pBankFieldValue)) {
			detail.setpBank(pBankFieldValue);
		}

		// 發動者專用區
		String noteFieldValue = section.getField(Ach02TxFileSectionNew.NOTE.getId()).getStringValue();
		if (StringUtils.isNotBlank(noteFieldValue)) {
			// detail.setNote(noteFieldValue);
			detail.setAchSeqKey(ConvertUtils.str2Long(noteFieldValue));
		}

		// 交易型態
		int type = AchType.UNKNOWN.getType();
		String typeFieldValue = section.getField(Ach02TxFileSectionNew.TYPE.getId()).getStringValue();
		if (StringUtils.equals(typeFieldValue, "N")) {
			type = AchType.N.getType();
		}
		else if (StringUtils.equals(typeFieldValue, "R")) {
			type = AchType.R.getType();
		}

		detail.setType(type);

		// 交易類別
		int txType = AchTxType.RG.getType();

		detail.setTxType(txType);

		// 回覆訊息
		String rCodeFieldValue = section.getField(Ach02TxFileSectionNew.RCODE.getId()).getStringValue();
		if (StringUtils.isNotBlank(rCodeFieldValue)) {
			detail.setrCode(rCodeFieldValue);
		}

		// 每筆扣款限額.
		String amtFieldValue = section.getField(Ach02TxFileSectionNew.LIMITAMT.getId()).getStringValue();
		if (StringUtils.isNotBlank(amtFieldValue)) {
			detail.setTxAmt(ConvertUtils.str2BigDecimal(amtFieldValue));
		}
		
		// 委繳帳戶性質
		String cnType = section.getField(Ach02TxFileSectionNew.CNTYPE.getId()).getStringValue();
		if (StringUtils.isNotBlank(cnType)) {
			detail.setCnType(cnType);
		}
		
		// 授權扣款終止日
		String eDate = section.getField(Ach02TxFileSectionNew.EDATE.getId()).getStringValue();
		if (StringUtils.isNotBlank(eDate)) {
			detail.setEDate(eDate);
		}
		
		// 發動行專用區
		String noteB = section.getField(Ach02TxFileSectionNew.NOTEB.getId()).getStringValue();
		if (StringUtils.isNotBlank(noteB)) {
			detail.setNoteB(noteB);
		}

		// 備用
		String fillerFieldValue = section.getField(Ach02TxFileSectionNew.FILLER.getId()).getStringValue();
		if (StringUtils.isNotBlank(fillerFieldValue)) {
			detail.setFiller(fillerFieldValue);
		}

	}

	public List<AchDetailDoc> getDetails() {
		return details;
	}

	public void setDetails(List<AchDetailDoc> details) {
		this.details = details;
	}

}
