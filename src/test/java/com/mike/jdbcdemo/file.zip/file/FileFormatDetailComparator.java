/*
 * ===========================================================================
 * IBM Confidential
 * AIS Source Materials
 * 
 * 
 * (C) Copyright IBM Corp. 2011.
 *
 * ===========================================================================
 */
package com.cosmos.file;

import java.util.Comparator;



/**
 * <p>FileFormatDetailEntity Comparator</p>
 * 依照OrderNo由小到大排序
 * 
 * @author  Leo
 * @version 1.0, 2011/6/8
 * @see	    
 * @since 
 */
public class FileFormatDetailComparator implements Comparator<FileFormatDetail> {

	@Override
	public int compare(FileFormatDetail detail1, FileFormatDetail detail2) {
		return detail1.getOrderNo() - detail2.getOrderNo();
	}

}



 