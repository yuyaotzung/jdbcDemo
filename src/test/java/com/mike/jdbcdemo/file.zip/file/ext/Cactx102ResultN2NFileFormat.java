/*
 * ===========================================================================
 * IBM Confidential
 * AIS Source Materials
 * 
 * 
 * (C) Copyright IBM Corp. 2018.
 *
 * ===========================================================================
 */
package com.cosmos.file.ext;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.cosmos.code.CibErrorCode;
import com.cosmos.file.FileFormatDetail;
import com.cosmos.file.FileFormatNew;
import com.cosmos.file.bo.FileDetail;
import com.cosmos.file.bo.FileDoc;
import com.cosmos.file.bo.FileSection;
import com.cosmos.file.def.Cactx102ResultN2NFooterFileDefinition;
import com.cosmos.file.def.Cactx102ResultN2NHeaderFileDefinition;
import com.cosmos.file.def.Cactx102ResultN2NTxFileDefinition;
import com.cosmos.file.def.IFileDefinition;
import com.cosmos.persistence.b2c.entity.FileFormatDetailEntity;
import com.cosmos.persistence.b2c.entity.FileFormatFieldEntity;
import com.cosmos.tx.TxDetailDoc;
import com.cosmos.type.FieldGroup;
import com.cosmos.type.TaskType;
import com.cosmos.type.TxBatchType;
import com.ibm.tw.commons.exception.ActionException;
import com.ibm.tw.commons.util.ConvertUtils;

/**
 * <p>
 * 整批多扣多入
 * </p>
 * 
 * @author Bear
 * @version 1.0, 2018/4/9
 * @see
 * @since
 */
public class Cactx102ResultN2NFileFormat extends FileFormatNew {

	private final TaskType taskType = TaskType.BN2N;

	/** 明細資料 */
	private List<TxDetailDoc> details = new ArrayList<TxDetailDoc>();

	public Cactx102ResultN2NFileFormat(String taskId) {
		super(0, taskId, TxBatchType.UNKNOWN.getCode());
		detailGroup = loadDetailGroup();
	}

	/**
	 * 載入檔案定義
	 * 
	 * @return
	 */
	private Map<FieldGroup, List<FileFormatDetail>> loadDetailGroup() {
		Map<FieldGroup, List<FileFormatDetail>> detailGroup = new HashMap<FieldGroup, List<FileFormatDetail>>();

		// Header
		detailGroup.put(FieldGroup.HEADER, toFileFormatDetails(taskType, FieldGroup.HEADER, Cactx102ResultN2NHeaderFileDefinition.values()));

		// Tx
		detailGroup.put(FieldGroup.TX, toFileFormatDetails(taskType, FieldGroup.TX, Cactx102ResultN2NTxFileDefinition.values()));

		// Footer
		detailGroup.put(FieldGroup.FOOTER, toFileFormatDetails(taskType, FieldGroup.FOOTER, Cactx102ResultN2NFooterFileDefinition.values()));

		return detailGroup;
	}

	/**
	 * 轉換為FileFormatDetail
	 * 
	 * @param taskType
	 * @param fieldGroup
	 * @param sections
	 * @return
	 */
	private List<FileFormatDetail> toFileFormatDetails(TaskType taskType, FieldGroup fieldGroup, IFileDefinition[] sections) {
		List<FileFormatDetail> fileFormatDetails = new ArrayList<FileFormatDetail>();

		int orderNo = 1;
		// 對應DB讀取資料,需由1開始
		int startPosition = 1;
		for (IFileDefinition section : sections) {
			FileFormatDetail fileFormatDetail = toFileFormatDetail(taskType, fieldGroup, section.getId(), section.getName(), orderNo++, section.getType(), section.getRequired(), section.getLength(), startPosition);
			fileFormatDetails.add(fileFormatDetail);
			startPosition += section.getLength();
		}

		return fileFormatDetails;
	}

	/**
	 * 轉換為FileFormatDetail
	 * 
	 * @param taskType
	 * @param fieldGroup
	 * @param fieldId
	 * @param fieldName
	 * @param orderNo
	 * @param type
	 * @param length
	 * @param startPosition
	 * @return
	 */
	private FileFormatDetail toFileFormatDetail(TaskType taskType, FieldGroup fieldGroup, String fieldId, String fieldName, int orderNo, int type, int required, int length, int startPosition) {
		// detail
		FileFormatDetailEntity detail = new FileFormatDetailEntity();
		detail.setFieldId(fieldId);
		detail.setFieldName(fieldName);
		detail.setOrderNo(orderNo);
		detail.setLength(length);
		detail.setStartPosition(startPosition);
		detail.setEndPosition(startPosition + detail.getLength() - 1);

		// field
		FileFormatFieldEntity field = new FileFormatFieldEntity();
		field.setFieldGroup(fieldGroup.getCode());
		field.setFieldId(fieldId);
		field.setTaskType(taskType.getCode());
		field.setType(type);
		field.setDefaultLength(length);
		field.setRequired(required);

		FileFormatDetail fileFormatDetail = new FileFormatDetail(taskType, detail, field);
		return fileFormatDetail;
	}

	@Override
	public FieldGroup getFormatCycle(int rowNo) {
		return null;
	}

	@Override
	public FieldGroup getFormatHead(int rowNo) {
		if (rowNo == 1) {
			return FieldGroup.HEADER;
		}
		else if (rowNo == getRows()) {
			return FieldGroup.FOOTER;
		}
		else {
			return FieldGroup.TX;
		}
	}

	@Override
	public TaskType getTaskType() {
		return taskType;
	}

	@Override
	protected void putData(FileDoc fileDoc) {

		// 將檔案資料轉為整批多扣多入明細資料 ,i為行號
		// 第一行為header,所以由i=2開始
		for (int i = 2; i <= fileDoc.rows(); i++) {
			if (i != fileDoc.rows()) {// 最後一行為footer
				TxDetailDoc detail = new TxDetailDoc();
				putDetail(detail, fileDoc.getDetail(i), i);
				details.add(detail);
			}

		}
	}

	protected void putDetail(TxDetailDoc txDetailDoc, FileDetail fileDetail, int i) {
		putDocDetail(txDetailDoc, fileDetail.getFirstSection(), i);
	}

	protected void putDocDetail(TxDetailDoc detail, FileSection section, int row) {
		Cactx102ResultN2NTxFileSection fileSection = new Cactx102ResultN2NTxFileSection(section);

		// 批號
		detail.setLastPmtId(fileSection.getBatchNo());
		// 流水號
		detail.setTxNo(Integer.valueOf(fileSection.getSerno()));
		// 付款通路
		detail.setPayerKind(Integer.valueOf(fileSection.getPayChanel()));
		// 付款人帳號
		detail.setPayerAccountNo(fileSection.getPayerAccountNo());
		// 付款人戶名
		detail.setPayerName(fileSection.getPayerName());
		// 付款人統編
		detail.setPayerUid(fileSection.getPayerUid());
		// 收款銀行代號
		detail.setPayeeBankId(fileSection.getReceiveBankCode());
		// 轉入帳號
		detail.setPayeeAccountNo(fileSection.getRollInAcct());
		// 交易金額
		detail.setTxAmt(ConvertUtils.str2BigDecimal(fileSection.getAmount(), 0));
		// 提示碼
		detail.setTxAmt(ConvertUtils.str2BigDecimal(fileSection.getPromoCode(), 0));

		// PROMO_NO(1, 0, 2, "", "提示碼"),
		// MEMO(1, 0, 16, "", "存摺附註"),
		// VALID_ID(1, 0, 10, "", "檢核ID"),
		// VALID_PAYEE_NAME(1, 0, 60, "", "檢核戶名"),
		// FEE(1, 0, 5, "", "櫃員手續費/匯款手續費"),

		// 附言
		detail.setPayeeMemo(fileSection.getPostScript());

		// BANCS_STATUS(1, 0, 4, "", "BaNCS中心執行結果BANCS-STAT"),
		// TXN_STATUS(1, 0, 4, "", "匯款處理結果"),
		// TXN_NO(1, 0, 7, "", "匯款編號"),
		// JOURNAL_NO(1, 0, 9, "", "交易序號"),
		// TOTAL_COUNT(1, 0, 9, "", "上傳總筆數"),
		// TOTAL_AMT(1, 0, 17, "", "上傳總金額")

	}

	@Override
	protected String getReadFromEncoding() {
		return "UTF-8";
	}

	/**
	 * DATA TO FILE
	 * 
	 * @return
	 * @throws ActionException
	 */
	public byte[] toFile() throws ActionException {

		byte[] dataBuff = new byte[0];

		// 取得首筆
		FileDetail header = getFileDoc().getDetails().get(0);
		FileDetail footer = fetchFooter();
		try {

			// 首筆
			if (header != null) {
				dataBuff = detailStringData(header);
			}

			// 明細
			for (FileDetail detail : fileDoc.getDetails()) {
				if (detail.getFirstSection().getFieldGroup().compareTo(FieldGroup.HEADER) == 0 || detail.getFirstSection().getFieldGroup().compareTo(FieldGroup.FOOTER) == 0) {
					// 如果是header或footer則略過
					continue;
				}

				if (dataBuff.length > 0) {
					dataBuff = concat(dataBuff, getLineSeparator().getBytes(ENCODING));
				}

				dataBuff = concat(dataBuff, detailStringData(detail));
			}

			// 尾筆
			if (footer != null) {

				// dataBuff = detailStringData(footer);

				if (dataBuff.length > 0)
					dataBuff = concat(dataBuff, getLineSeparator().getBytes(ENCODING));
				dataBuff = concat(dataBuff, detailStringData(footer));
			}

			return dataBuff;
		}
		catch (UnsupportedEncodingException e) {

			ActionException ex = getActionException(CibErrorCode.VALIDATE_SIZE_ERROR);

			throw ex;
		}
	}

	/**
	 * 取得尾筆
	 * 
	 * @return
	 */
	private FileDetail fetchFooter() {

		// if (fileDoc == null) {
		//
		// System.err.println("===fileDoc is null=========");
		//
		// }
		// else {
		//
		// System.err.println("===fileDoc is not null=========");
		// }
		//
		// if (fileDoc.getDetails() == null) {
		//
		// System.err.println("===fileDoc.getDetails() is null=========");
		//
		// }
		// else {
		//
		// System.err.println("===fileDoc.getDetails() is not null=========");
		// }

		for (FileDetail detail : fileDoc.getDetails()) {
			if (detail.isFooter()) {
				return detail;
			}
		}
		return null;
	}

	/**
	 * 加入首筆
	 * 
	 * @param detail
	 */
	public void addHeader(Cactx102ResultN2NHeaderFileSection detail) {
		FileDetail fileDetail = new FileDetail();
		fileDetail.addSection(detail.getFileSection());
		getFileDoc().getDetails().add(0, fileDetail); // 加入首筆
	}

	/**
	 * 加入明細
	 * 
	 * @param detail
	 */
	public void addDetails(Cactx102ResultN2NTxFileSection detail) {
		FileDetail fileDetail = new FileDetail();
		fileDetail.addSection(detail.getFileSection());
		getFileDoc().addDetail(fileDetail); // ?? 是否需要
	}

	/**
	 * 加入Footer
	 * 
	 * @param detail
	 */
	public void addFooter(Cactx102ResultN2NFooterFileSection detail) {
		FileDetail fileDetail = new FileDetail();
		fileDetail.addSection(detail.getFileSection());
		getFileDoc().addDetail(fileDetail);
	}

	@Override
	protected void validateCustom(FileDoc fileDoc) throws ActionException {
		// TODO 自動產生方法 Stub

	}

	@Override
	protected void validateDetailContent(FileDetail fileDetail) throws ActionException {
		// TODO 自動產生方法 Stub

	}

	@Override
	protected void validateDetailSize(FileDoc fileDoc) throws ActionException {
		// TODO 自動產生方法 Stub

	}

}
