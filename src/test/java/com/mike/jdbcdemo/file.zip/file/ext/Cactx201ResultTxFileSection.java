/*
 * ===========================================================================
 * IBM Confidential
 * AIS Source Materials
 * 
 * 
 * (C) Copyright IBM Corp. 2018.
 *
 * ===========================================================================
 */
package com.cosmos.file.ext;

import com.cosmos.file.bo.FileField;
import com.cosmos.file.bo.FileSection;
import com.cosmos.file.def.Cactx201ResultTxFileDefinition;
import com.cosmos.file.def.IFileDefinition;
import com.cosmos.type.FieldGroup;
import com.ibm.tw.commons.util.StringUtils;



/**
 * <p> 整批薪資入帳</p>
 *
 * @author  Bear
 * @version 1.0, 2018/4/26
 * @see	    
 * @since 
 */
public class Cactx201ResultTxFileSection {
	/** 檔案區段 */
	private FileSection fileSection;
	
	public Cactx201ResultTxFileSection(){
		fileSection = new FileSection();
		fileSection.setFieldGroup(FieldGroup.TX);
	}
	
	public Cactx201ResultTxFileSection(FileSection fileSection) {
		this.fileSection = fileSection;
	}
	
	public FileSection getFileSection() {
		return fileSection;
	}
	
	//批號
	public String getBatchNo() {
		return getValue(Cactx201ResultTxFileDefinition.BATCH_NO);
	}
	
	public void setBatchNo(String value) {
		setValue(Cactx201ResultTxFileDefinition.BATCH_NO, value);
	}
	
	//流水號
	public String getSerno() {
		return getValue(Cactx201ResultTxFileDefinition.SERNO);
	}
	
	public void setSerno(String value) {
		setValue(Cactx201ResultTxFileDefinition.SERNO, value);
	}
	
	//付款通路
	public String getPayChanel() {
		return getValue(Cactx201ResultTxFileDefinition.PAY_CHANEL);
	}
	
	public void setPayChanel(String value) {
		setValue(Cactx201ResultTxFileDefinition.PAY_CHANEL, value);
	}
	
	//收款銀行代號
	public String getReceiveBankCode() {
		return getValue(Cactx201ResultTxFileDefinition.RECEIVE_BANK_CODE);
	}
	
	public void setReceiveBankCode(String value) {
		setValue(Cactx201ResultTxFileDefinition.RECEIVE_BANK_CODE, value);
	}
	
	//入薪員工入帳帳號
	public String getPayeeAcctNo() {
		return getValue(Cactx201ResultTxFileDefinition.PAYEE_ACCT_NO);
	}
	
	public void setPayeeAcctNo(String value) {
		setValue(Cactx201ResultTxFileDefinition.PAYEE_ACCT_NO, value);
	}
	
	//入薪員工身分證號
	public String getPayeeUid() {
		return getValue(Cactx201ResultTxFileDefinition.PAYEE_UID);
	}
	
	public void setPayeeUid(String value) {
		setValue(Cactx201ResultTxFileDefinition.PAYEE_UID, value);
	}
	
	//入薪員工戶名
	public String getPayeeName() {
		return getValue(Cactx201ResultTxFileDefinition.PAYEE_NAME);
	}
	
	public void setPayeeName(String value) {
		setValue(Cactx201ResultTxFileDefinition.PAYEE_NAME, value);
	}
	
	//入帳金額
	public String getTxnAmt() {
		return getValue(Cactx201ResultTxFileDefinition.TXN_AMT);
	}
	
	public void setTxnAmt(String value) {
		setValue(Cactx201ResultTxFileDefinition.TXN_AMT, value);
	}
	
	//櫃員手續費/匯款手續費
	public String getFee() {
		return getValue(Cactx201ResultTxFileDefinition.FEE);
	}
	
	public void setFee(String value) {
		setValue(Cactx201ResultTxFileDefinition.FEE, value);
	}
	
	//附言
	public String getPostScript() {
		return getValue(Cactx201ResultTxFileDefinition.POST_SCRIPT);
	}
	
	public void setPostScript(String value) {
		setValue(Cactx201ResultTxFileDefinition.POST_SCRIPT, value);
	}
	
	//薪資入帳回覆代碼
	public String getRetCode() {
		return getValue(Cactx201ResultTxFileDefinition.RET_CODE);
	}
	
	public void setRetCode(String value) {
		setValue(Cactx201ResultTxFileDefinition.RET_CODE, value);
	}
	
	
	//匯款處理結果
	public String getFepResult() {
		return getValue(Cactx201ResultTxFileDefinition.FEP_RESULT);
	}
	
	public void setFepResult(String value) {
		setValue(Cactx201ResultTxFileDefinition.FEP_RESULT, value);
	}
	
	//匯款編號
	public String getFepNo() {
		return getValue(Cactx201ResultTxFileDefinition.FEP_NO);
	}
	
	public void setFepNo(String value) {
		setValue(Cactx201ResultTxFileDefinition.FEP_NO, value);
	}
	
	//交易序號
	public String getJrnlNo() {
		return getValue(Cactx201ResultTxFileDefinition.JRNL_NO);
	}
	
	public void setJrnlNo(String value) {
		setValue(Cactx201ResultTxFileDefinition.JRNL_NO, value);
	}
	
	
	//========================================================
	// 以下可共用
	
	
	/**
	 * 
	 * @param fileDefinition
	 * @return
	 */
	private String getValue(IFileDefinition fileDefinition) {
		
		FileField fileField = fileSection.getField(fileDefinition.getId());
		if (fileField == null) {
			return null;
		}
		else {
			return StringUtils.trim(fileField.getValue());
		}
	}
	
	/**
	 * 
	 * @param fileDefinition
	 * @param value
	 */
	private void setValue(IFileDefinition fileDefinition, String value) {

		if (fileSection == null) {
			fileSection = new FileSection();
		}

		FileField field = fileSection.getField(fileDefinition.getId());
		if (field == null) {
			field = new FileField();
			field.setFieldId(fileDefinition.getId());
			field.setValue(value);
			fileSection.addField(field);
		}
		else {
			field.setValue(value);
		}
	}
	
	// 以上可共用
	//========================================================
}



 