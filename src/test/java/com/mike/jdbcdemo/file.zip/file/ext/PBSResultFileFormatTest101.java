/*
 * ===========================================================================
 * IBM Confidential
 * AIS Source Materials
 * 
 * 
 * (C) Copyright IBM Corp. 2018.
 *
 * ===========================================================================
 */
package com.cosmos.file.ext;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.util.Date;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;

import org.apache.commons.io.FileUtils;

import com.cosmos.code.CosmosCommonId;
import com.cosmos.file.bo.FileDetail;
import com.cosmos.file.bo.FileDoc;
import com.cosmos.file.bo.FileSection;
import com.cosmos.param.ISystemParam;
import com.cosmos.param.ext.CibParam;
import com.cosmos.persistence.CosmosDaoFactory;
import com.cosmos.persistence.b2c.dao.B2CSequenceDao;
import com.cosmos.persistence.b2c.dao.IB2CSequenceDao;
import com.cosmos.persistence.b2c.dao.ISystemParamDao;
import com.cosmos.persistence.b2c.entity.SystemParamEntity;
import com.cosmos.persistence.b2c.entity.pk.SystemParamEntityPk;
import com.cosmos.type.FieldGroup;
import com.cosmos.util.CosmosTxUtils;
import com.cosmos.util.SFTPUtils;
import com.ibm.tw.commons.aop.AOPProxyFactory;
import com.ibm.tw.commons.exception.ActionException;
import com.ibm.tw.commons.exception.CryptException;
import com.ibm.tw.commons.persistence.exception.DatabaseException;
import com.ibm.tw.commons.util.ConvertUtils;
import com.ibm.tw.commons.util.DESUtils;
import com.ibm.tw.commons.util.StringUtils;
import com.ibm.tw.commons.util.time.DateUtils;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.SftpException;

/**
 * <p>
 * PBSResultFileFormat 匯出匯入測試
 * </p>
 * 
 * @author monica
 * @version 1.0, Feb 22, 2018
 * @see
 * @since
 */
public class PBSResultFileFormatTest101 {

	// 證卷資料夾
	private static final String WORDKING_DIR = "0013";

	// 預檢資料夾
	private static final String WORDKING_DIR_T1 = "0038";

	// Server
	static String server;

	// Port
	static int port;

	// 帳號
	static String user_put;

	// 密碼
	static String password_put;

	// 帳號
	static String user_get;

	// 密碼
	static String password_get;

	public static void main(String[] args) throws Throwable {

		init();

		testExportFile();

		// String fileName = "0038000118072018000000000001807170043911.TMP";
		// testImportFile(fileName);

	}

	private static void init() {
		// Server
		server = getSystemParamValue(CibParam.FCS_SFTP_SERVER);
		// Port
		port = ConvertUtils.str2Int(getSystemParamValue(CibParam.FCS_SFTP_PORT));
		// 帳號
		user_put = getSystemParamValue(CibParam.FCS_SFTP_USER_PUT);
		// 密碼
		password_put = getSystemParamValue(CibParam.FCS_SFTP_PASSWORD_PUT);
		// 帳號
		user_get = getSystemParamValue(CibParam.FCS_SFTP_USER_GET);
		// 密碼
		password_get = getSystemParamValue(CibParam.FCS_SFTP_PASSWORD_GET);

		System.err.println(server);
		System.err.println(port);
		System.err.println(user_put);
		System.err.println(password_put);

	}

	private static void testImportFile(String fileName) throws JSchException, SftpException, IOException, ActionException {

		// byte[] fileContent = FileUtils.readFileToByteArray(new
		// File("D:/ACHBACKUP/"+fileName));

		byte[] fileContent = null;
		ChannelSftp sftp = null;
		ByteArrayOutputStream os = new ByteArrayOutputStream();
		try {
			sftp = SFTPUtils.connect(server, port, user_get, password_get, "/");

			sftp.get(fileName, os);

			fileContent = os.toByteArray();

			if (fileContent == null) {
				System.err.println("sftp download file Error, fileName:" + fileName);
			}

		}
		catch (JSchException e) {
			System.err.println("SFTP連線失敗");
			e.printStackTrace();
			throw e;
		}
		catch (SftpException e) {
			e.printStackTrace();
			throw e;
		}
		finally {
			try {
				os.close();
				SFTPUtils.disconnect(sftp);
			}
			catch (JSchException e) {
				System.err.println("SFTP離線失敗");
				e.printStackTrace();
			}
			catch (IOException e) {
				System.err.println("ByteArrayOutputStream close failed , fileName:" + fileName);
				e.printStackTrace();
			}
		}

		PBSResultFileFormat fileFormat = new PBSResultFileFormat("CSFTX101");
		boolean result = fileFormat.parseFile(fileContent);

		FileDoc fileDoc = fileFormat.getFileDoc();

		for (FileDetail fileDetail : fileDoc.getDetails()) {
			System.out.println("=================== " + fileDetail.getRowNo() + " ====================");

			// 
			FileSection fileSection = fileDetail.getFirstSection();
			if (fileDetail.getFirstSection().getFieldGroup() == FieldGroup.HEADER) {
				PBSResultHeaderFileSection header = new PBSResultHeaderFileSection(fileSection);
				System.out.println("getBatchNo:" + header.getBatchNo());
				System.out.println("getHeadSecAgentCode:" + header.getHeadSecAgentCode());
				System.out.println("getSecAgentCode:" + header.getSecAgentCode());
				System.out.println("getAccountNo:" + header.getAccountNo());
				System.out.println("getBranchNo:" + header.getBranchNo());
				System.out.println("getTellerNo:" + header.getTellerNo());
				System.out.println("getTermNo:" + header.getTermNo());
				System.out.println("getTotalCount:" + header.getTotalCount());
				System.out.println("getTxDate:" + header.getTxDate());
				System.out.println("getTransType:" + header.getTransType());
			}
			else {
				PBSResultTxFileSection detail = new PBSResultTxFileSection(fileSection);
				System.out.println("getBatchNo:" + detail.getBatchNo());
				System.out.println("getSerno:" + detail.getSerno());
				System.out.println("getPayerAccountNo:" + detail.getPayerAccountNo());
				System.out.println("getPayerIdNo:" + detail.getPayerIdNo());
				System.out.println("getPayeeAccountTypeId:" + detail.getPayeeAccountTypeId());
				System.out.println("getTxAmt:" + detail.getTxAmt());
				System.out.println("getTransType:" + detail.getTransType());
				System.out.println("getShopId:" + detail.getShopId());
				System.out.println("getPayeeAccountNo:" + detail.getPayeeAccountNo());
				System.out.println("getStockId:" + detail.getStockId());
				System.out.println("getPromoCode:" + detail.getPromoCode());
				System.out.println("getRemark:" + detail.getRemark());
				System.out.println("getAccountId:" + detail.getAccountId());
				System.out.println("getAccountName:" + detail.getAccountName());
				System.out.println("getPhone1:" + detail.getPhone1());
				System.out.println("getPhone2:" + detail.getPhone2());
				System.out.println("getTxnStatus:" + detail.getTxnStatus());
				System.out.println("getAccountBal:" + detail.getAccountBal());
				System.out.println("getErrorCode:" + detail.getErrorCode());
				System.out.println("getJournalNo:" + detail.getJrnlNo());
				System.out.println("getTransType:" + detail.getTransType());
			}

		}

		System.out.println("result:" + result);
	}

	private static void testExportFile() throws JSchException, SftpException, IOException, DatabaseException, ActionException {

		PBSResultFileFormat fileFormat = new PBSResultFileFormat("CSFTX101");
		PBSResultFileFormat fileFormatT1 = new PBSResultFileFormat("CSFTX101");

		// 案件序號
		String flowDocId = generateCaseNo();

		// 交易日期
		// ███████ For Test: 這裡暫時 hard code。每次上傳時，皆手動給交易日 (T+2天 扣款, T+1天 預檢）
		// Date txDate = new Date();
		Date txDate = CosmosTxUtils.getNextBusinessDay();
		Date txDateT1 = new Date();

		prepareHeaders(fileFormat, flowDocId, txDate);
		prepareDetails(fileFormat, flowDocId);
		prepareHeaders(fileFormatT1, flowDocId, txDateT1);
		prepareDetails(fileFormatT1, flowDocId);

		byte[] data = new byte[0];
		data = fileFormat.toFile();

		String fileName = getFileName(txDate, flowDocId);

		System.out.println("fileName:" + fileName);

		// TODO 備份路徑??
		// 備份檔案
		FileUtils.writeByteArrayToFile(new File("C:/ACHBACKUP/" + fileName + ".TXT"), data);

		ChannelSftp sftp = null;

		boolean result = false;
		ByteArrayInputStream is = new ByteArrayInputStream(data);

		try {
			sftp = SFTPUtils.connect(server, port, user_put, password_put, WORDKING_DIR);

			sftp.put(is, fileName + ".tmp");

			result = true;
			System.out.println("是否上傳成功 =" + result);
			is.close();

			if (!result) {
				System.err.println("上傳失敗");
			}

			try {
				if (result) {
					sftp.rename(fileName + ".tmp", fileName + ".TXT");
				}
			}
			catch (SftpException e) {
				e.printStackTrace();
				System.err.println("rename失敗, fileName:" + fileName);

			}

		}
		catch (JSchException e) {
			System.err.println("SFTP連線失敗");
			e.printStackTrace();
			throw e;
		}
		catch (SftpException e) {
			e.printStackTrace();
			throw e;
		}
		catch (IOException e) {
			e.printStackTrace();
			throw e;
		}
		finally {
			try {
				is.close();
				SFTPUtils.disconnect(sftp);
			}
			catch (JSchException e) {
				System.err.println("SFTP離線失敗");
				e.printStackTrace();
			}
			catch (IOException e) {
				System.err.println("ByteArrayInputStream close failed , fileName:" + fileName);
				e.printStackTrace();
			}
		}

		// ██預檢██████████████████████████████████████████████████████

		data = fileFormatT1.toFile();

		String fileNameT1 = getFileNameT1(txDateT1, flowDocId);
		System.out.println("fileNameT1: " + fileNameT1);
		// 備份檔案
		FileUtils.writeByteArrayToFile(new File("C:/ACHBACKUP/" + fileNameT1 + ".TXT"), data);

		result = false;
		is = new ByteArrayInputStream(data);

		try {
			sftp = SFTPUtils.connect(server, port, user_put, password_put, WORDKING_DIR_T1);

			sftp.put(is, fileNameT1 + ".tmp");

			result = true;
			System.out.println("是否上傳成功 =" + result);
			is.close();

			if (!result) {
				System.err.println("上傳失敗");
			}

			try {
				if (result) {
					sftp.rename(fileNameT1 + ".tmp", fileNameT1 + ".TXT");
				}
			}
			catch (SftpException e) {
				e.printStackTrace();
				System.err.println("rename失敗, fileName:" + fileNameT1);

			}

		}
		catch (JSchException e) {
			System.err.println("SFTP連線失敗");
			e.printStackTrace();
			throw e;
		}
		catch (SftpException e) {
			e.printStackTrace();
			throw e;
		}
		catch (IOException e) {
			e.printStackTrace();
			throw e;
		}
		finally {
			try {
				is.close();
				SFTPUtils.disconnect(sftp);
			}
			catch (JSchException e) {
				System.err.println("SFTP離線失敗");
				e.printStackTrace();
			}
			catch (IOException e) {
				System.err.println("ByteArrayInputStream close failed , fileName:" + fileNameT1);
				e.printStackTrace();
			}
		}

	}

	private static void prepareHeaders(PBSResultFileFormat fileFormat, String flowDocId, Date txDate) {

		PBSResultHeaderFileSection section = new PBSResultHeaderFileSection();
		// 批號PBMT-BATCH-NO flowDocId
		section.setBatchNo(StringUtils.leftPad(flowDocId, 24, "0"));
		// 母公司券商代號
		section.setHeadSecAgentCode(StringUtils.rightPad("9203", 5, " "));
		// 委託單位代號(券商代號)
		section.setSecAgentCode(StringUtils.rightPad("9237", 5, " "));
		// 證券清算帳號
		section.setAccountNo(StringUtils.leftPad("9009000700000002", 16, "0"));
		// 分行號碼
		section.setBranchNo(StringUtils.leftPad("00009", 5, "0"));
		// 行員號碼
		section.setTellerNo(StringUtils.leftPad(CosmosCommonId.tellerNo, 8, "0"));
		// 交易端末機號
		section.setTermNo(StringUtils.leftPad("000", 3, "0"));
		// 轉帳總筆數
		section.setTotalCount(StringUtils.leftPad("1", 15, "0"));
		// 轉帳日期(扣款日期)
		section.setTxDate(DateUtils.formatDate(txDate, "yyyyMMdd"));

		// 轉帳業務種類
		// █ 測試上傳，分別101, 102種類上傳2種
		section.setTransType(StringUtils.rightPad("101", 3, " "));

		// 為了與畫面parse一致,讀入資料的secNo由1開始
		section.getFileSection().setSectionNo(1);

		fileFormat.addHeader(section);
	}

	private static void prepareDetails(PBSResultFileFormat fileFormat, String flowDocId) {

		PBSResultTxFileSection section = new PBSResultTxFileSection();

		// 批號PBMT-BATCH-NO
		section.setBatchNo(StringUtils.leftPad(flowDocId, 24, "0"));
		// 流水號PBMT-SERNO
		section.setSerno(StringUtils.leftPad("1", 5, "0"));
		// 客戶銀行轉帳帳號
		section.setPayerAccountNo(StringUtils.leftPad("60090400001332", 14, "0"));

		// 客戶之統一編號
		section.setPayerIdNo(StringUtils.rightPad("P182422958", 10, " "));

		// 入扣帳種類
		section.setPayeeAccountTypeId("1115");

		// 交易金額
		section.setTxAmt(StringUtils.leftPad("1200", 11, "0"));

		// 轉帳業務種類
		section.setTransType("101");

		// 營業員代號??
		section.setShopId(StringUtils.leftPad("123", 10, "0"));

		// 證券戶號(客戶)??
		section.setPayeeAccountNo(StringUtils.rightPad(" ", 7, " "));

		// 股票代號??
		section.setStockId(StringUtils.rightPad("1234567", 7, " "));

		// 存摺摘要
		section.setPromoCode("RA"); // 股票價金

		// 附註
		section.setRemark(StringUtils.rightPad("", 16, " "));

		// 帳號ID-回饋檔更新
		section.setAccountId(StringUtils.rightPad("", 10, " "));

		// 帳號戶名-回饋檔更新
		section.setAccountName(StringUtils.rightPad("", 60, " "));

		// 聯絡電話1-回饋檔更新
		section.setPhone1(StringUtils.rightPad("", 14, " "));
		// 聯絡電話2-回饋檔更新
		section.setPhone2(StringUtils.rightPad("", 14, " "));

		// 執行結果-回饋檔更新
		section.setTxnStatus(StringUtils.rightPad("", 2, " "));

		// 帳號餘額-回饋檔更新
		section.setAccountBal(StringUtils.leftPad("", 17, "0"));

		// 錯誤代碼-回饋檔更新
		section.setErrorCode(StringUtils.rightPad("", 4, "0"));

		// 交易序號-回饋檔更新
		section.setJrnlNo(StringUtils.rightPad("", 9, " "));

		// 為了與畫面parse一致,讀入資料的secNo由1開始
		section.getFileSection().setSectionNo(1);

		fileFormat.addDetails(section);
	}

	/*
	 * 來源檔檔案名稱：9999(流程識別碼)+99999(主辦分行代碼)+交易日期(西元年DDMMYYYY)+999999999999999999999999
	 * (批號).TXT
	 */
	private static String getFileName(Date txDate, String batchNo) {

		return WORDKING_DIR + "0960" + DateUtils.formatDate(txDate, "ddMMyyyy") + StringUtils.leftPad(batchNo, 24, "0");
	}

	private static String getFileNameT1(Date txDate, String batchNo) {

		return WORDKING_DIR_T1 + "0960" + DateUtils.formatDate(txDate, "ddMMyyyy") + StringUtils.leftPad(batchNo, 24, "0");
	}

	public static String generateCaseNo() throws DatabaseException {
		String value = "";
		IB2CSequenceDao dao = (IB2CSequenceDao) AOPProxyFactory.getDao(IB2CSequenceDao.class, B2CSequenceDao.class);
		String caseNoSeq = StringUtils.leftPad(String.valueOf(dao.getCaseNoSeq() % 10000000), 7, "0");
		value = DateUtils.getSimpleISODateStr(new Date()).substring(2) + caseNoSeq;
		return value;
	}

	/** 系統參數代碼表 */
	private static Map<SystemParamEntityPk, String> systemParamMap = null;

	/**
	 * 載入系統參數
	 */
	synchronized private static void loadSystemParamMap() {

		if (systemParamMap != null) {
			return;
		}

		systemParamMap = new Hashtable<SystemParamEntityPk, String>();

		ISystemParamDao dao = CosmosDaoFactory.getSystemParamDao();

		try {

			// System.err.println("loadSystemParamMap");

			List<SystemParamEntity> entities = dao.findAll();

			for (SystemParamEntity entity : entities) {

				SystemParamEntityPk pk = new SystemParamEntityPk(entity.getCategory(), entity.getKey());

				String value = StringUtils.trimToEmpty(entity.getValue());

				// 加入密碼 DECRYPT 的功能
				if (1 == entity.getPasswordFlag()) {
					value = DESUtils.decrypt(value);
				}

				systemParamMap.put(pk, value);

			}
		}
		catch (DatabaseException e) {
			throw new RuntimeException("cannot load SystemParam ", e);
		}
		catch (CryptException e) {
			throw new RuntimeException("cannot load SystemParam ", e);
		}

	}

	public static Map<SystemParamEntityPk, String> getSystemParamMap() {

		if (null == systemParamMap) {
			loadSystemParamMap();
		}
		return systemParamMap;
	}

	/**
	 * 取得參數值
	 * 
	 * @param param
	 * @return
	 */
	public static String getSystemParamValue(ISystemParam param) {

		SystemParamEntityPk pk = new SystemParamEntityPk(param.getCategory().getCode(), param.getKey());

		return getSystemParamMap().get(pk);
	}

}
