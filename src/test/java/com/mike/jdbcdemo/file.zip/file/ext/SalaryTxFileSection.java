/*
 * ===========================================================================
 * IBM Confidential
 * AIS Source Materials
 * 
 * 
 * (C) Copyright IBM Corp. 2018.
 *
 * ===========================================================================
 */
package com.cosmos.file.ext;

import com.cosmos.file.bo.FileField;
import com.cosmos.file.bo.FileSection;
import com.cosmos.file.def.IFileDefinition;
import com.cosmos.file.def.SalaryTxFileDefinition;
import com.cosmos.type.FieldGroup;
import com.ibm.tw.commons.util.StringUtils;

/**
 * <p>
 * 整批多扣多入Tx格式
 * </p>
 * 
 * @author Bear
 * @version 1.0, 2018/4/10
 * @see
 * @since
 */
public class SalaryTxFileSection {

	/** 檔案區段 */
	private FileSection fileSection;

	public SalaryTxFileSection() {
		fileSection = new FileSection();
		fileSection.setFieldGroup(FieldGroup.TX);
	}

	public SalaryTxFileSection(FileSection fileSection) {
		this.fileSection = fileSection;
	}

	public FileSection getFileSection() {
		return fileSection;
	}

	// 轉入帳號
	public String getPayeeAccountNo() {
		return getValue(SalaryTxFileDefinition.payeeAccountNo);
	}

	public void setPayeeAccountNo(String value) {
		setValue(SalaryTxFileDefinition.payeeAccountNo, value);
	}

	/**
	 * 收款人統編
	 * 
	 * @return
	 */
	public String getPayeeUid() {
		return getValue(SalaryTxFileDefinition.payeeUid);

	}

	public void setPayeeUid(String value) {
		setValue(SalaryTxFileDefinition.payeeUid, value);
	}

	/**
	 * 交易日期
	 * 
	 * @return
	 */
	public String getTxDate() {
		return getValue(SalaryTxFileDefinition.txDate);

	}

	public void setTxDate(String value) {
		setValue(SalaryTxFileDefinition.txDate, value);
	}

	// 交易金額
	public String getTxAmt() {
		return getValue(SalaryTxFileDefinition.txAmt);
	}

	public void setTxAmt(String value) {
		setValue(SalaryTxFileDefinition.txAmt, value);
	}

	// 交易類型
	public String getTranstype() {
		return getValue(SalaryTxFileDefinition.transtype);
	}

	public void setTranstype(String value) {
		setValue(SalaryTxFileDefinition.transtype, value);
	}

	/**
	 * 付款款人統編
	 * 
	 * @return
	 */
	public String getPayerUid() {
		return getValue(SalaryTxFileDefinition.payerUid);

	}

	public void setPayerUid(String value) {
		setValue(SalaryTxFileDefinition.payerUid, value);
	}

	/**
	 * 收款款人戶名
	 * 
	 * @return
	 */
	public String getPayeeName() {
		return getValue(SalaryTxFileDefinition.payeeName);

	}

	public void setPayeeName(String value) {
		setValue(SalaryTxFileDefinition.payeeName, value);
	}
	
	// ========================================================
	// 以下可共用

	/**
	 * 
	 * @param fileDefinition
	 * @return
	 */
	private String getValue(IFileDefinition fileDefinition) {

		FileField fileField = fileSection.getField(fileDefinition.getId());
		if (fileField == null) {
			return null;
		}
		else {
			return StringUtils.trim(fileField.getValue());
		}
	}

	/**
	 * 
	 * @param fileDefinition
	 * @param value
	 */
	private void setValue(IFileDefinition fileDefinition, String value) {

		if (fileSection == null) {
			fileSection = new FileSection();
		}

		FileField field = fileSection.getField(fileDefinition.getId());
		if (field == null) {
			field = new FileField();
			field.setFieldId(fileDefinition.getId());
			field.setValue(value);
			fileSection.addField(field);
		}
		else {
			field.setValue(value);
		}
	}

	// 以上可共用
	// ========================================================
}
