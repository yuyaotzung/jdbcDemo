/*
 * ===========================================================================
 * IBM Confidential
 * AIS Source Materials
 * 
 * 
 * (C) Copyright IBM Corp. 2011.
 *
 * ===========================================================================
 */
package com.cosmos.file;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.cosmos.persistence.CosmosDaoFactory;
import com.cosmos.persistence.b2c.dao.IFileFormatDao;
import com.cosmos.persistence.b2c.dao.IFileFormatDetailDao;
import com.cosmos.persistence.b2c.dao.IFileFormatFieldDao;
import com.cosmos.persistence.b2c.entity.FileFormatDetailEntity;
import com.cosmos.persistence.b2c.entity.FileFormatEntity;
import com.cosmos.persistence.b2c.entity.FileFormatFieldEntity;
import com.cosmos.tx.FlowDoc;
import com.cosmos.type.FieldGroup;
import com.cosmos.type.TaskType;
import com.cosmos.uaa.ILoginUser;
import com.cosmos.util.LineSeparator;
import com.ibm.tw.commons.persistence.exception.DatabaseException;
import com.ibm.tw.commons.util.ConvertUtils;
import com.ibm.tw.commons.util.StringUtils;

/**
 * <p>
 * 檔案匯入格式
 * </p>
 * 
 * @author Leo
 * @version 1.0, 2011/5/7
 * @see
 * @since
 */
public abstract class FileFormat<D extends FlowDoc> {

	/** 編碼類型 */
	public static String ENCODING = "MS950";

	/** 檔案格式主檔資料 */
	protected FileFormatEntity master = null;

	/** 檔案格式明細檔 (依FieldGroup分群) */
	protected Map<FieldGroup, List<FileFormatDetailEntity>> detailGroup = new HashMap<FieldGroup, List<FileFormatDetailEntity>>();

	/** 檔案格式定義檔 */
	protected Map<String, FileFormatFieldEntity> fields = new HashMap<String, FileFormatFieldEntity>();

	/** 文件是否已經存在資料庫 */
	protected boolean loaded = false;

	protected Log logger = LogFactory.getLog(FileFormat.class);

	/**
	 * 取得所屬交易
	 * 
	 * @return
	 */
	public abstract TaskType getTaskType();

	/**
	 * 根據檔案格式鍵值載入資料
	 * 
	 * Constructor
	 * 
	 * @param fileFormatKey
	 * @throws DatabaseException
	 */
	public FileFormat(String fileFormatKey) throws DatabaseException {
		load(fileFormatKey);

		this.loaded = true;
	}

	/**
	 * 初始化檔案格式資料
	 * 
	 * Constructor
	 * 
	 * @param loginUser
	 * @param taskId
	 * @param txBatchType
	 */
	public FileFormat(ILoginUser loginUser, String taskId, int txBatchType) {

		init(loginUser, taskId, txBatchType);

		this.loaded = false;
	}

	/**
	 * 初始化流程文件共同資料
	 * 
	 * @throws DatabaseException
	 * 
	 */
	protected void initMaster(ILoginUser loginUser, String taskId, int txBatchType) {

		master = new FileFormatEntity();

		// 公司統編
		master.setCompanyKey(loginUser.getCompanyKey());

		// 交易代號
		master.setTaskId(taskId);

		// 整批格式
		master.setTxBatchType(txBatchType);
	}

	/**
	 * 儲存流程文件
	 * 
	 * @throws DatabaseException
	 */
	public void save() throws DatabaseException {

		System.err.println(getClass() + " => is loaded = " + loaded);

		// 修改
		if (loaded) {
			update();
		}
		// 新增
		else {
			insert();
		}

		this.loaded = true;
	}

	/**
	 * 載入交易主檔
	 * 
	 * @param flowDocId
	 * @throws DatabaseException
	 */
	protected void loadMaster(long fileFormatKey) throws DatabaseException {

		IFileFormatDao dao = CosmosDaoFactory.getFileFormatDao();

		this.master = dao.findByKey(fileFormatKey);

	}

	/**
	 * 移除交易主檔
	 * 
	 * @throws DatabaseException
	 */
	protected void removeMaster() throws DatabaseException {

		IFileFormatDao dao = CosmosDaoFactory.getFileFormatDao();

		dao.remove(master);
	}

	/**
	 * 新增交易主檔
	 * 
	 * @return
	 * @throws DatabaseException
	 */
	protected void insertMaster() throws DatabaseException {

		IFileFormatDao dao = CosmosDaoFactory.getFileFormatDao();

		this.master = dao.insert(master);
	}

	/**
	 * 修改交易主檔
	 * 
	 * @throws DatabaseException
	 */
	protected void updateMaster() throws DatabaseException {

		IFileFormatDao dao = CosmosDaoFactory.getFileFormatDao();

		this.master = dao.update(master);
	}

	/**
	 * 初始化流程文件共同資料
	 * 
	 * @throws DatabaseException
	 * 
	 */
	public void init(ILoginUser loginUser, String taskId, int txBatchType) {

		initMaster(loginUser, taskId, txBatchType);

		detailGroup = new HashMap<FieldGroup, List<FileFormatDetailEntity>>();

		fields = new HashMap<String, FileFormatFieldEntity>();

	}

	/**
	 * <p>
	 * 根據案件序號載入文件
	 * </p>
	 * 
	 * @throws DatabaseException
	 */
	public void load(String fileFormatKey) throws DatabaseException {

		long key = ConvertUtils.str2Long(fileFormatKey);

		// 載入主檔 (FileFormatEntity)
		loadMaster(key);

		// 載入明細檔 (FileFormatDetailEntity)
		loadDetails();

		// 載入定義檔 (FileFormatFieldEntity)
//		loadFieldMap(details);
	}

	/**
	 * 分群明細檔
	 * 
	 * @throws DatabaseException
	 */
	private void loadDetails() throws DatabaseException {

		detailGroup.clear();

		IFileFormatDetailDao dao = CosmosDaoFactory.getFileFormatDetailDao();

		List<FileFormatDetailEntity> details = dao.findByMasterKey(master.getFileFormatKey());
		
		for (FileFormatDetailEntity detail : details) {

			addFileFormatDetailEntity(detail);
		}
	}

	/**
	 * 加入FileFormatDetailEntity
	 * 
	 * @param detail
	 * @param fieldGroup
	 * @throws DatabaseException 
	 */
	public void addFileFormatDetailEntity(FileFormatDetailEntity detail) throws DatabaseException {
		
		// 載入定義
		FileFormatFieldEntity field = loadField(detail);
		
		FieldGroup fieldGroup = FieldGroup.valueOf(field.getFieldGroup());
		
		// 取得對應detail list
		List<FileFormatDetailEntity> detailList = detailGroup.get(fieldGroup);

		if (detailList == null) {
			detailList = new ArrayList<FileFormatDetailEntity>();
		}

		// 加入detail
		detailList.add(detail);

		detailGroup.put(fieldGroup, detailList);
	}
	
//	/**
//	 * 載入定義檔
//	 * 
//	 * @throws DatabaseException
//	 */
//	private void loadFieldMap(List<FileFormatDetailEntity> details) throws DatabaseException {
//
//		int taskType = getTaskType().getCode();
//
//		fields.clear();
//
//		IFileFormatFieldDao dao = CosmosDaoFactory.getFileFormatFieldDao();
//
//		for (FileFormatDetailEntity detail : details) {
//
//			String fieldId = detail.getFieldId();
//
//			FileFormatFieldEntity field = dao.findByFieldId(fieldId, taskType);
//
//			fields.put(fieldId, field);
//		}
//	}

	/**
	 * 載入定義
	 * 
	 * @param detail
	 * @throws DatabaseException
	 */
	private FileFormatFieldEntity loadField(FileFormatDetailEntity detail) throws DatabaseException {
		
		int taskType = getTaskType().getCode();
		
		String fieldId = detail.getFieldId();
		logger.info("fieldId="+fieldId);
		FileFormatFieldEntity field = fields.get(fieldId);
		
		if (field == null) {
			
			IFileFormatFieldDao dao = CosmosDaoFactory.getFileFormatFieldDao();
			
			field = dao.findByFieldId(fieldId, taskType);

			fields.put(fieldId, field);
		}
		
		return field;
	}
	
	/**
	 * <p>
	 * 根據文件代碼刪除文件
	 * </p>
	 * 
	 * @param docId
	 * @throws DatabaseException
	 */
	public void remove() throws DatabaseException {

		long fileFormatKey = master.getFileFormatKey();

		if (fileFormatKey == 0) {
			logger.info("no fileFormatKey");
			return;
		}

		// 移除明細檔 (FileFormatDetailEntity)
		removeDetails();

		// 移除主檔 (FileFormatEntity)
		removeMaster();
	}

	/**
	 * 移除交易明細檔
	 * 
	 * @return
	 * @throws DatabaseException
	 */
	private void removeDetails() throws DatabaseException {

		IFileFormatDetailDao dao = CosmosDaoFactory.getFileFormatDetailDao();

		for (List<FileFormatDetailEntity> detailList : detailGroup.values()) {
			dao.remove(detailList);
		}
	}

	/**
	 * 新增
	 * 
	 * @throws DatabaseException
	 */
	protected void insert() throws DatabaseException {
		// 新增主檔 (FileFormatEntity)
		insertMaster();

		for (List<FileFormatDetailEntity> detailList : detailGroup.values()) {
			// 新增明細檔 (FileFormatDetailEntity)
			for (FileFormatDetailEntity detail : detailList) {

				// 檔案格式鍵值（主檔）
				detail.setFileFormatKey(master.getFileFormatKey());

				IFileFormatDetailDao dao = CosmosDaoFactory.getFileFormatDetailDao();

				dao.insert(detail);
			}
		}
	}

	/**
	 * 更新
	 * 
	 * @throws DatabaseException
	 */
	protected void update() throws DatabaseException {
		// 新增主檔 (FileFormatEntity)
		updateMaster();

		for (List<FileFormatDetailEntity> detailList : detailGroup.values()) {
			// 新增明細檔 (FileFormatDetailEntity)
			for (FileFormatDetailEntity detail : detailList) {

				// 檔案格式鍵值（主檔）
				detail.setFileFormatKey(master.getFileFormatKey());

				IFileFormatDetailDao dao = CosmosDaoFactory.getFileFormatDetailDao();

				dao.update(detail);
			}
		}
	}
	
	public String getFormatName() {
		return StringUtils.trimToEmpty(master.getFormatName());
	}

	public void setFormatName(String formatName) {
		master.setFormatName(formatName);
	}

	public boolean isLoaded() {
		return loaded;
	}

	public void setLoaded(boolean loaded) {
		this.loaded = loaded;
	}
	
	/**
	 * 將上傳檔案依照換行符號切分
	 * 
	 * @param fileContent
	 * @return
	 */
	protected List<byte[]> getFileRecords(byte[] fileContent) {
		List<byte[]> fileRecords = null;
		if (contains(fileContent, LineSeparator.Windows.getBytes())) {
			fileRecords = split(fileContent, LineSeparator.Windows.getBytes());
		}
		else if (contains(fileContent, LineSeparator.Macintosh.getBytes())) {
			fileRecords = split(fileContent, LineSeparator.Macintosh.getBytes());
		}
		else if (contains(fileContent, LineSeparator.Unix.getBytes())) {
			fileRecords = split(fileContent, LineSeparator.Unix.getBytes());
		}
		else {
			fileRecords = new ArrayList<byte[]>();
			fileRecords.add(fileContent);
		}
		return fileRecords;
	}
	
	/**
	 * 將byte陣列依據separator切成多個byte陣列
	 * @param array
	 * @param separator
	 * @return
	 */
	private List<byte[]> split(byte[] array, byte[] separator) {
		List<byte[]> list = new ArrayList<byte[]>();
		int index = indexOf(array, separator);
		while(index >= 0) {
			byte[] subArray = subArray(array, 0, index);
			array = subArray(array, index + separator.length);
			index = indexOf(array, separator);
			
			list.add(subArray);
		}
		
		if (array.length > 0) {
			list.add(array);
		}
		return list;
	}
	
	/**
	 * 搜尋目標陣列在byte陣列中出現的index
	 * 
	 * 若不包含則回傳-1
	 * 
	 * @param array
	 * @param search
	 * @return
	 */
	private int indexOf(byte[] array, byte[] search) {
		for(int i = search.length; i <= array.length; i++) {
			byte[] subArray = subArray(array, i - search.length, i);
			if (equals(subArray, search)) {
				return i - search.length;
			}
		}
		return -1;
	}
	
	/**
	 * 搜尋byte陣列是否包含目標陣列
	 * 
	 * @param array
	 * @param search
	 * @return
	 */
	private boolean contains(byte[] array, byte[] search) {
		return indexOf(array, search) != -1;
	}
	
	/**
	 * 取得byte陣列的子陣列
	 * 
	 * @param array
	 * @param start
	 * @return
	 */
	protected byte[] subArray(byte[] array, int start) {
		return subArray(array, start, array.length);
	}
	
	/**
	 * 取得byte陣列的子陣列
	 * 
	 * @param array
	 * @param start
	 * @param end
	 * @return
	 */
	protected byte[] subArray(byte[] array, int start, int end) {
		int length = end - start;
		
		if (length <= 0) {
			return new byte[0];
		}
		
		byte[] subArray = new byte[length];
		for(int i = 0; i < length; i++) {
			subArray[i] = array[i + start];
		}
		return subArray;
	}
	
	/**
	 * 比較兩byte陣列是否相同
	 * 
	 * @param array1
	 * @param array2
	 * @return
	 */
	private boolean equals(byte[] array1, byte[] array2) {
		if (array1.length != array2.length) {
			return false;
		}
		for (int i = 0; i < array1.length; i++) {
			if (array1[i] != array2[i]) {
				return false;
			}
		}
		return true;
	}

	/**
	 * 計算格式長度
	 * 
	 * @param detailList
	 * @return
	 */
	protected int getLength(List<FileFormatDetailEntity> detailList) {
		// 計算格式長度
		int length = 0;
		for (FileFormatDetailEntity field : detailList) {
			length += field.getLength();
		}
		return length;
	}
	
	/**
	 * 產生新的流程文件
	 * 
	 * @param loginUser
	 * @return
	 * @throws DatabaseException
	 */
	abstract protected D getNewDoc(ILoginUser loginUser) throws DatabaseException;
	
//	/**
//	 * 解析檔案
//	 * 
//	 * @param fileContent
//	 * @return
//	 * @throws ActionException
//	 * @throws DatabaseException
//	 */
//	abstract public List<D> parse(byte[] fileContent, <? extends ILoginUser> loginUser) throws ActionException, DatabaseException;
}
