/*
 * ===========================================================================
 * IBM Confidential
 * AIS Source Materials
 * 
 * 
 * (C) Copyright IBM Corp. 2011.
 *
 * ===========================================================================
 */
package com.cosmos.file.ext;

import com.cosmos.file.bo.FileField;
import com.cosmos.file.bo.FileSection;
import com.ibm.tw.commons.util.StringUtils;

/**
 * <p>
 * 證券款複委託檔案上傳
 * </p>
 * 
 * @author BearChen
 * @version 1.0, 2011/6/27
 * @see
 * @since
 */
public class TSBFileSection {

	/** 檔案區段 */
	private FileSection fileSection;

	public TSBFileSection(FileSection fileSection) {
		this.fileSection = fileSection;
	}

	/**
	 * 客戶銀行付款帳號
	 * 
	 * @return
	 */
	public String getPayerAccountNo() {
		FileField fileField = fileSection.getField("payerAccountNo");
		if (fileField == null) {
			return null;
		}
		else {

			String payerAccount = StringUtils.trim(fileField.getValue());

			if (StringUtils.length(payerAccount) == 12) {

				payerAccount = StringUtils.leftPad(payerAccount, 14, "0");

			}

			return payerAccount;
		}
	}
	
	/**
	 * 客戶上傳付款帳號
	 * 
	 * @return
	 */
	public String getPayerAccountNoOri() {

		FileField fileField = fileSection.getField("payerAccountNo");
		if (fileField == null) {
			return null;
		}
		else {
			return StringUtils.trim(fileField.getValue());
		}
	}

	/**
	 * 客戶付款統編
	 * 
	 * @return
	 */
	public String getPayerUid() {
		FileField fileField = fileSection.getField("payerUid");
		if (fileField == null) {
			return null;
		}
		else {
			return StringUtils.trim(fileField.getValue());
		}
	}

	/**
	 * 交易日期
	 * 
	 * @return
	 */
	public String getTxDate() {
		FileField fileField = fileSection.getField("txDate");
		if (fileField == null) {
			return null;
		}
		else {
			return fileField.getValue();
		}
	}

	/**
	 * 帳號轉帳類別代號 1為入帳 2為扣帳
	 * 
	 * @return
	 */
	public String getPayeeAccountTypeId() {
		FileField fileField = fileSection.getField("payeeAccountTypeId");
		if (fileField == null) {
			return null;
		}
		else {
			return fileField.getValue();
		}
	}

	/**
	 * 交易金額
	 * 
	 * @return
	 */
	public String getTxAmt() {
		FileField fileField = fileSection.getField("txAmt");
		if (fileField == null) {
			return null;
		}
		else {
			return fileField.getValue();
		}
	}

	/**
	 * 券商統編
	 * 
	 * @return
	 */
	public String getPayeeUid() {
		FileField fileField = fileSection.getField("payeeUid");
		if (fileField == null) {
			return null;
		}
		else {
			return StringUtils.trim(fileField.getValue());
		}
	}

	/**
	 * 證券戶號
	 * 
	 * @return
	 */
	public String getPayeeAccountNo() {
		FileField fileField = fileSection.getField("payeeAccountNo");
		if (fileField == null) {
			return null;
		}
		else {
			return StringUtils.trim(fileField.getValue());
		}
	}

	/**
	 * 證券商專戶凱基帳號
	 * 
	 * @return
	 */
	public String getTsbOwnerId() {
		FileField fileField = fileSection.getField("tsbOwnerId");
		if (fileField == null) {
			return null;
		}
		else {

			String payeeAccount = StringUtils.trim(fileField.getValue());

			if (StringUtils.length(payeeAccount) == 12) {

				payeeAccount = StringUtils.leftPad(payeeAccount, 14, "0");

			}

			return payeeAccount;
		}
		
	}
	
	/**
	 * 客戶上傳收款帳號
	 * 
	 * @return
	 */
	public String getTsbOwnerIdOri() {

		FileField fileField = fileSection.getField("tsbOwnerId");
		if (fileField == null) {
			return null;
		}
		else {
			return StringUtils.trim(fileField.getValue());
		}
	}

	/**
	 * 備註
	 * 
	 * @return
	 */
	public String getMemo() {
		FileField fileField = fileSection.getField("memo");
		if (fileField == null) {
			return null;
		}
		else {
			return StringUtils.trim(fileField.getValue());
		}
	}

	/**
	 * 券商代號
	 * 
	 * @return
	 */
	public String getSecno() {
		FileField fileField = fileSection.getField("secno");
		if (fileField == null) {
			return null;
		}
		else {
			return StringUtils.trim(fileField.getValue());
		}
	}

}
